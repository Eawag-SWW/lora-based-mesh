/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		mcu_pinout.h
 *
 * \description	All pin definitions are done within this file, no other
 * 				definitions should be used to enable fast transferring to
 * 				different hardwares
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		Summer 17
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _MCU_PINOUT_H
#define _MCU_PINOUT_H

/* -- includes --------------------------------------------------------------*/
#include "device_config.h"

/* -- makros ----------------------------------------------------------------*/
#define HW_VERS_1		1
#define HW_VERS_2		2

#define HW_VERSION		HW_VERS_2

#if HW_VERSION == HW_VERS_1			//-----------------------------------------
/*
 * 	User Button
 */
#define UBUTTON_PIN								GPIO_PIN_15
#define UBUTTON_PORT							GPIOA

/*
 * 	Debug UART Pins (UART 4)
 */
#define DEB_UART_TX_PIN GPIO_PIN_10
#define DEB_UART_RX_PIN GPIO_PIN_11
#define DEB_UART_PORT	GPIOC

/*
 * 	LED
 */
#define LED1_PIN 	GPIO_PIN_8
#define LED2_PIN	GPIO_PIN_9
#define LED_PORT	GPIOB

/*
 * 	Debug interface
 */
#define TMS_Pin 									GPIO_PIN_13
#define TMS_GPIO_Port 								GPIOA
#define TCK_Pin 									GPIO_PIN_14
#define TCK_GPIO_Port 								GPIOA
#define SWO_Pin 									GPIO_PIN_3
#define SWO_GPIO_Port 								GPIOB

/*
 * 		SX1276 Pins
 */
// SPI

#if SETUP_TESTBENCH == 0
#define RADIO_SPI_INSTANCE							SPI1
#define RADIO_MOSI                                  PA_7
#define RADIO_MISO                                  PA_6
#define RADIO_SCLK                                  PA_5
#define RADIO_NSS                                   PA_4

#define RADIO_RXTX_EXT								PC_4
#define RADIO_RESET                                 PC_9

#define RADIO_DIO_0                                 PC_7
#define RADIO_DIO_1                                 PC_6			//ToDo: Choose the right pin
#define RADIO_DIO_2                                 PB_2
#define RADIO_DIO_3                                 PB_1
#define RADIO_DIO_4                                 PB_0
#define RADIO_DIO_5                                 PC_5

#define RADIO_ANT_SWITCH_HF                         PC_4
#define RADIO_ANT_SWITCH_LF                         PC_4

#else
#define RADIO_SPI_INSTANCE							SPI1
#define RADIO_MOSI                                  PB_15
#define RADIO_MISO                                  PB_14
#define RADIO_SCLK                                  PB_13
#define RADIO_NSS                                   PB_12

#define RADIO_RXTX_EXT								PC_4
#define RADIO_RESET                                 PC_0

#define RADIO_DIO_0                                 PA_3
#define RADIO_DIO_1                                 PC_6			//ToDo: Choose the right pin
#define RADIO_DIO_2                                 PB_2
#define RADIO_DIO_3                                 PB_1
#define RADIO_DIO_4                                 PB_0
#define RADIO_DIO_5                                 PC_5

#define RADIO_ANT_SWITCH_HF                         PC_4
#define RADIO_ANT_SWITCH_LF                         PC_4

#endif
/*
 * 	IM880B Pins
 */
#define IM880_USART_INSTANCE						USART1
#define IM880_USART_TX_PIN							GPIO_PIN_10
#define IM880_USART_RX_PIN							GPIO_PIN_9
#define IM880_USART_PORT							GPIOA

#define IM880_WKUP_PIN								GPIO_PIN_8
#define IM880_WKUP_PORT								GPIOA

/*
 * 	Oscillator pins
 */
#define OSC_LSE_IN_PIN								GPIO_PIN_14
#define OSC_LSE_OUT_PIN								GPIO_PIN_15
#define OSC_LSE_PORT								GPIOC

#define OSC_HSE_IN_PIN                              GPIO_PIN_0
#define OSC_HSE_OUT_PIN                             GPIO_PIN_1
#define OSC_HSE_PORT								GPIOH

/*
 * 	Sensor Interface
 */

// LDO
#define SI_LDO_PORT									GPIOC
#define SI_LDO_EN_PIN								GPIO_PIN_13

// SPI
#define SI_SPI_INSTANCE								SPI2
#define SI_SPI_MOSI_PIN								GPIO_PIN_15
#define SI_SPI_MISO_PIN								GPIO_PIN_14
#define SI_SPI_SCK_PIN								GPIO_PIN_13
#define SI_SPI_NSS_PIN								GPIO_PIN_12
#define SI_SPI_PORT									GPIOB

// USART
#define SI_UART_INSTANCE							USART2
#define SI_UART_TX_PIN								GPIO_PIN_2
#define SI_UART_RX_PIN								GPIO_PIN_3
#define SI_UART_RTS_PIN								GPIO_PIN_1
#define SI_UART_CTS_PIN								GPIO_PIN_0
#define SI_UART_PORT								GPIOA

// I2C
#define SI_I2C_INSTANCE								I2C3
#define SI_I2C_SDA_PIN								GPIO_PIN_1
#define SI_I2C_SCL_PIN								GPIO_PIN_0
#define SI_I2C_PORT									GPIOC

// ADC
#define SI_ADC_INSTANCE								ADC1
#define SI_ADC_IN1_PIN								GPIO_PIN_2
#define SI_ADC_IN2_PIN								GPIO_PIN_3
#define SI_ADC_PORT									GPIOC

// OneWire
#define SI_1WIRE_PIN								GPIO_PIN_2		// TODO: uses same pin as debug port!
#define SI_1WIRE_PORT								GPIOC			// TODO: uses same pin as debug port!

/*
 * 	SD Card
 */
#define SDCARD_SDMMC_INSTANCE						SDMMC1
#define SDCARD_CMD_PIN								GPIO_PIN_2
#define SDCARD_CMD_PORT								GPIOD

#define SDCARD_CK_PIN								GPIO_PIN_12
#define SDCARD_D0_PIN								GPIO_PIN_8
#define SDCARD_CK_D0_PORT							GPIOC

#define SDCARD_CDET_PIN								GPIO_PIN_12
#define SDCARD_CDET_PORT							GPIO_A

/*
 * 	DCF77
 */
#define DCF77_USART_INSTANCE						USART3
#define DCF77_USART_TX_PIN							GPIO_PIN_10
#define DCF77_USART_RX_PIN							GPIO_PIN_11
#define DCF77_USART_PORT							GPIOB

/*
 * 	GPS
 */
#define GPS_USART_INSTANCE							USART3
#define GPS_USART_TX_PIN							GPIO_PIN_10
#define GPS_USART_RX_PIN							GPIO_PIN_11
#define GPS_USART_PORT								GPIOB

/*
 * 	Power switches
 */
#define PS_TIMESOURCE_PIN							GPIO_PIN_11
#define PS_TIMESOURCE_PORT							GPIOA
#define PS_SENSI_PIN								GPIO_PIN_4
#define PS_SENSI_PORT								GPIOB
#define PS_SX_PIN									GPIO_PIN_5
#define PS_SX_PORT									GPIOB
#define PS_IM880_PIN								GPIO_PIN_6
#define PS_IM880_PORT								GPIOB
#define PS_SDCARD_PIN								GPIO_PIN_7
#define PS_SDCARD_PORT								GPIOB

#elif HW_VERSION == HW_VERS_2	//-----------------------------------------

/*
 * 	User Button
 */
#define UBUTTON_PIN									GPIO_PIN_15
#define UBUTTON_PORT								GPIOA

/*
 * 	Debug UART Pins (UART 4)
 */
#define DEB_UART_TX_PIN 							GPIO_PIN_10
#define DEB_UART_RX_PIN 							GPIO_PIN_11
#define DEB_UART_PORT								GPIOC

/*
 * 	LED
 */
#define LED1_PIN 									GPIO_PIN_8
#define LED2_PIN									GPIO_PIN_9
#define LED_PORT									GPIOB

/*
 * 	Debug interface
 */
#define TMS_Pin 									GPIO_PIN_13
#define TMS_GPIO_Port 								GPIOA
#define TCK_Pin 									GPIO_PIN_14
#define TCK_GPIO_Port 								GPIOA
#define SWO_Pin 									GPIO_PIN_3
#define SWO_GPIO_Port 								GPIOB

/*
 * 		SX1276 Pins
 */
// SPI

#if SETUP_TESTBENCH == 0
#define RADIO_SPI_INSTANCE							SPI1
#define RADIO_MOSI                                  PA_7
#define RADIO_MISO                                  PA_6
#define RADIO_SCLK                                  PA_5
#define RADIO_NSS                                   PA_4

#define RADIO_RXTX_EXT								PC_4
#define RADIO_RESET                                 PC_9

#define RADIO_DIO_0                                 PC_7
#define RADIO_DIO_1                                 PC_6			//ToDo: Choose the right pin
#define RADIO_DIO_2                                 PB_2
#define RADIO_DIO_3                                 PB_1
#define RADIO_DIO_4                                 PB_0
#define RADIO_DIO_5                                 PC_5

#define RADIO_ANT_SWITCH_HF                         PC_4
#define RADIO_ANT_SWITCH_LF                         PC_4

#else
#define RADIO_SPI_INSTANCE							SPI1
#define RADIO_MOSI                                  PB_15
#define RADIO_MISO                                  PB_14
#define RADIO_SCLK                                  PB_13
#define RADIO_NSS                                   PB_12

#define RADIO_RXTX_EXT								PC_4
#define RADIO_RESET                                 PC_0

#define RADIO_DIO_0                                 PA_3
#define RADIO_DIO_1                                 PC_6			//ToDo: Choose the right pin
#define RADIO_DIO_2                                 PB_2
#define RADIO_DIO_3                                 PB_1
#define RADIO_DIO_4                                 PB_0
#define RADIO_DIO_5                                 PC_5

#define RADIO_ANT_SWITCH_HF                         PC_4
#define RADIO_ANT_SWITCH_LF                         PC_4

#endif
/*
 * 	IM880B Pins
 */
#define IM880_USART_INSTANCE						USART1
#define IM880_USART_TX_PIN							GPIO_PIN_10
#define IM880_USART_RX_PIN							GPIO_PIN_9
#define IM880_USART_PORT							GPIOA

#define IM880_WKUP_PIN								GPIO_PIN_8
#define IM880_WKUP_PORT								GPIOA

/*
 * 	Oscillator pins
 */
#define OSC_LSE_IN_PIN								GPIO_PIN_14
#define OSC_LSE_OUT_PIN								GPIO_PIN_15
#define OSC_LSE_PORT								GPIOC

#define OSC_HSE_IN_PIN                              GPIO_PIN_0
#define OSC_HSE_OUT_PIN                             GPIO_PIN_1
#define OSC_HSE_PORT								GPIOH

/*
 * 	Sensor Interface
 */

// LDO
#define SI_LDO_PORT									GPIOC
#define SI_LDO_EN_PIN								GPIO_PIN_13

// SPI
#define SI_SPI_INSTANCE								SPI2
#define SI_SPI_MOSI_PIN								GPIO_PIN_15
#define SI_SPI_MISO_PIN								GPIO_PIN_14
#define SI_SPI_SCK_PIN								GPIO_PIN_13
#define SI_SPI_NSS_PIN								GPIO_PIN_12
#define SI_SPI_PORT									GPIOB

// USART
#define SI_UART_INSTANCE							USART2
#define SI_UART_TX_PIN								GPIO_PIN_2
#define SI_UART_RX_PIN								GPIO_PIN_3
#define SI_UART_PORT								GPIOA

// I2C
#define SI_I2C_INSTANCE								I2C3
#define SI_I2C_SDA_PIN								GPIO_PIN_1
#define SI_I2C_SCL_PIN								GPIO_PIN_0
#define SI_I2C_PORT									GPIOC

// ADC
#define SI_ADC_INSTANCE								ADC1
#define SI_ADC_IN5_PIN								GPIO_PIN_0
#define SI_ADC_IN6_PIN								GPIO_PIN_1
#define SI_ADC_PORT									GPIOA

// Enable
#define SI_EN_SERIAL_PIN							GPIO_PIN_2
#define SI_EN_SERIAL_PORT							GPIOD

// OneWire
#define SI_1WIRE_PIN								GPIO_PIN_0		// ADC_IN3, Pin 5 at header X6
#define SI_1WIRE_PORT								GPIOA			// TODO: check if PA0 can be used for 1wire

/*
 * 	Battery measurment
 */
#define V_BAT_PIN									GPIO_PIN_2
#define V_BAT_PORT									GPIOC
#define EN_BAT_MEAS_PIN								GPIO_PIN_3
#define EN_BAT_MEAS_PORT							GPIOC

/*
 * 	SD Card
 */
#ifdef USE_SDMMC
#define SDCARD_SDMMC_INSTANCE						SDMMC1
#define SDCARD_CMD_PIN								GPIO_PIN_2
#define SDCARD_CMD_PORT								GPIOD

#define SDCARD_CK_PIN								GPIO_PIN_12
#define SDCARD_D0_PIN								GPIO_PIN_8
#define SDCARD_CK_D0_PORT							GPIOC

#define SDCARD_CDET_PIN								GPIO_PIN_12
#define SDCARD_CDET_PORT							GPIO_A
#endif

// SPI Ports shared with sensor interface
#define SDCARD_MOSI_PIN								SI_SPI_MOSI_PIN
#define SDCARD_MISO_PIN								SI_SPI_MISO_PIN
#define	SDCARD_SCK_PIN								SI_SPI_SCK_PIN
#define SCCARD_SPI_PORT								SI_SPI_PORT

#define SDCARD_SS_PIN								GPIO_PIN_8
#define SDCARD_SS_PORT								GPIOC

/*
 * 	DCF77
 */
#define DCF77_USART_INSTANCE						USART3
#define DCF77_USART_TX_PIN							GPIO_PIN_10
#define DCF77_USART_RX_PIN							GPIO_PIN_11
#define DCF77_USART_PORT							GPIOB

/*
 * 	GPS
 */
#define GPS_USART_INSTANCE							USART3
#define GPS_USART_TX_PIN							GPIO_PIN_10
#define GPS_USART_RX_PIN							GPIO_PIN_11
#define GPS_USART_PORT								GPIOB

/*
 * 	Power switches
 */
#define PS_PSSYNC_PIN								GPIO_PIN_12
#define PS_PSSYNC_PORT								GPIOA
#define PS_TIMESOURCE_PIN							GPIO_PIN_11
#define PS_TIMESOURCE_PORT							GPIOA
#define PS_SENSI_PIN								GPIO_PIN_4
#define PS_SENSI_PORT								GPIOB
#define PS_SX_PIN									GPIO_PIN_5
#define PS_SX_PORT									GPIOB
#define PS_IM880_PIN								GPIO_PIN_6
#define PS_IM880_PORT								GPIOB
#define PS_SDCARD_PIN								GPIO_PIN_7
#define PS_SDCARD_PORT								GPIOB


#else
#warning "define hardware version"
#endif

#endif	//_MCU_PINOUT_H

