/*
 / _____)             _              | |
( (____  _____ ____ _| |_ _____  ____| |__
 \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 _____) ) ____| | | || |_| ____( (___| | | |
(______/|_____)_|_|_| \__)_____)\____)_| |_|
    (C)2013 Semtech

Description: Helper functions implementation

License: Revised BSD License, see LICENSE.TXT file include in the project

Maintainer: Miguel Luis and Gregory Cristian
*/
#ifndef __UTILITIES_H__
#define __UTILITIES_H__

//#define FALSE 		(uint8_t)0
//#define TRUE		(uint8_t)1

#include "stdint.h"
#include "cmsis_os.h"
#include "integer.h"


/*
 * 	\brief	Returns byte 3 of a 32-bit value
 * 	\param	val: 32-bit value
 * 	\return	byte 3 of 32-bit value
 */
#define B3_32TO8(val)	((((uint8_t)(val >> 24)) & 0xFF))

/*
 * 	\brief	Returns byte 2 of a 32-bit value
 * 	\param	val: 32-bit value
 * 	\return	byte 2 of 32-bit value
 */
#define B2_32TO8(val)	((((uint8_t)(val >> 16)) & 0xFF))

/*
 * 	\brief	Returns byte 1 of a 32-bit value
 * 	\param	val: 32-bit value
 * 	\return	byte 1 of 32-bit value
 */
#define B1_32TO8(val)	((((uint8_t)(val >>  8)) & 0xFF))

/*
 * 	\brief	Returns byte 0 of a 32-bit value
 * 	\param	val: 32-bit value
 * 	\return	byte 0 of 32-bit value
 */
#define B0_32TO8(val)	((((uint8_t)(val      )) & 0xFF))

/*
 * 	\brief	Returns byte 1 of a 16-bit value
 * 	\param	val: 16-bit value
 * 	\return	byte 1 of 16-bit value
 */
#define B1_16TO8(val)	((((uint8_t)(val >> 8 )) & 0xFF))

/*
 * 	\brief	Returns byte 0 of a 16-bit value
 * 	\param	val: 16-bit value
 * 	\return	byte 0 of 16-bit value
 */
#define B0_16TO8(val)	((((uint8_t)(val	  )) & 0xFF))

/*!
 * \brief Returns the minimum value betwen a and b
 *
 * \param [IN] a 1st value
 * \param [IN] b 2nd value
 * \retval minValue Minimum value
 */
#define MIN( a, b ) ( ( ( a ) < ( b ) ) ? ( a ) : ( b ) )

/*!
 * \brief Returns the maximum value betwen a and b
 *
 * \param [IN] a 1st value
 * \param [IN] b 2nd value
 * \retval maxValue Maximum value
 */
#define MAX( a, b ) ( ( ( a ) > ( b ) ) ? ( a ) : ( b ) )

/*!
 * \brief Returns 2 raised to the power of n
 *
 * \param [IN] n power value
 * \retval result of raising 2 to the power n
 */
#define POW2( n ) ( 1 << n )

/*!
 * \brief Initializes the pseudo ramdom generator initial value
 *
 * \param [IN] seed Pseudo ramdom generator initial value
 */
void srand1( uint32_t seed );

/*!
 * \brief Computes a random number between min and max
 *
 * \param [IN] min range minimum value
 * \param [IN] max range maximum value
 * \retval random random value in range min..max
 */
int32_t randr( int32_t min, int32_t max );

/*!
 * \brief Copies size elements of src array to dst array
 * 
 * \remark STM32 Standard memcpy function only works on pointers that are aligned
 *
 * \param [OUT] dst  Destination array
 * \param [IN]  src  Source array
 * \param [IN]  size Number of bytes to be copied
 */
void memcpy1( uint8_t *dst, const uint8_t *src, uint16_t size );

/*!
 * \brief Copies size elements of src array to dst array reversing the byte order
 *
 * \param [OUT] dst  Destination array
 * \param [IN]  src  Source array
 * \param [IN]  size Number of bytes to be copied
 */
void memcpyr( uint8_t *dst, const uint8_t *src, uint16_t size );

/*!
 * \brief Set size elements of dst array with value 
 * 
 * \remark STM32 Standard memset function only works on pointers that are aligned
 *
 * \param [OUT] dst   Destination array
 * \param [IN]  value Default value
 * \param [IN]  size  Number of bytes to be copied
 */
void memset1( uint8_t *dst, uint8_t value, uint16_t size );

/*!
 * \brief Converts a nibble to an hexadecimal character
 * 
 * \param [IN] a   Nibble to be converted
 * \retval hexChar Converted hexadecimal character
 */
int8_t Nibble2HexChar( uint8_t a );

/*
 * \brief Checks if a specified flag is set
 * \param value: value which should be checked
 * \param flag:	 flag which should be checked
 * \retval 1 if flag is set, 0 otherwise
 */
uint8_t is_flag_set( uint32_t value, uint32_t flag );

/**
 *  \brief  Checks if a signal is set or not
 *  \param  *evt		pointer to the event
 *  \param	event_mask 	desired signal
 *  \return	returns 1 if signal is set, 0 otherwise
 */
uint8_t check_is_signal_set( osEvent *evt, uint32_t event_mask );


/**
 * 	\brief	Converts two uint8_t values into one uint16_t value
 * 			Pointer must point to the highbyte value (MSB),
 * 			the LSB value has to be the next byte
 * 	\param	*phighbyte is pointer to the high-byte value
 * 	\return	16-bit uint16_t value
 */
uint16_t convert_to_uint16( uint8_t *phighbyte );

/**
 * 	\brief	Converts four uint8_t values into one uint32_t value
 * 			Pointer must point to the MSB
 * 	\param	*msb is pointer to the msb
 * 	\return	32-bit uint32_t value
 */
uint32_t convert_to_uint32( uint8_t* msb );

/**
 *  \brief  converts a BCD value to a binary value
 *  		BCD means binary coded decimal
 */
uint8_t bcd_to_byte ( uint8_t bcd );

/**
 *  \brief  converts a byte to a BCD value
 *  		BCD means binary coded decimal
 */
uint8_t byte_to_bcd ( uint8_t byte );

/*
 * 	\brief 	converts an ascii character to a dezimal value
 * 	\ch		character (must be between 48 and 57)
 * 	\ret	returns dezmial value on sucess, -1 on error
 */
int8_t char2dez( uint8_t ch );

/*
 * 	\brief	Converts battery voltage in millivolts to a 4 bit value
 * 	\param	vbat	measured battery voltage in millivolts
 * 	\return	Returns 4 byte battery voltage value from 1.6 to 3.1 volt
 * 	        in 0.1V steps
 *
 * 			return value
 * 		  	^
 * 		  15|                   -------
 * 			|                  /
 * 			|                 /
 * 			|                /
 * 			|               /
 * 			|              /
 * 			|			  /
 * 		   0_____________/______________________>vbat
 * 		   0           1600  3100
 */
uint8_t convert_vbat( uint16_t vbat);

#endif // __UTILITIES_H__
