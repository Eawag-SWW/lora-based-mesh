/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		device_config.h
 *
 * \description	All necessary settings can be done within this file
 * 				The user can choose the device type, device address and
 * 				LoRaWAN parameters. Additionally, some low power features
 * 				can be enabled/disabled.
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		27.08.2019
 *
 *****************************************************************************/

/* re-definition guard */
#ifndef _DEVICE_CONFIG_H
#define _DEVICE_CONFIG_H

/* -- includes --------------------------------------------------------------*/
#include "stdint.h"

/* -- makros ----------------------------------------------------------------*/
/**
 * Release version code.
 */
#define CODE_VERSION "2.0.6"

/**
 * 	Uncomment one of the two following lines to manually define
 * 	the device type. WARNING: Do not uncomment both lines at the same time
 */
#define DEV_IS_REPEATER
//#define DEV_IS_NODE

/**
 * 	Define whether node tries to wait a random number of cycles to send a join request
 */
#define USE_RANDOM_JOIN_WAIT
/**
 * 	Define maximum number of cycles a node waits to send next join request.
 */
#define RANDOM_JOIN_WAIT_MAX 4

/**
 * 	Define the type of sensor, which is attached to the device
 * 	Choose one of the following possibilities (see sensors.h)
 * 	    - NO_SENSOR
 * 	    - MB7389
 * 	    - MB7369
 * 	    - DEC5TE
 * 	    - DS18B20
 */
#define SENSOR_TYPE 	NO_SENSOR

/*
 * 	Configuration if debugger is enabled in stop mode
 * 	if the debugger is not activated, the connection to the target
 * 	will be lost when the MCU enters stop mode
 */
#define USE_DBG_IN_STOPMODE		0	/**< 0: debugger not activated			 */
									/**< 1: debugger activated 			 	 */

/*
 * 	Configuration if log to sd card is enabled
 * 	either the debug log, the sensor log or both can be enabled/disabled
 */
#define SD_LOG_NONE				0		// do not change
#define SD_LOG_SENS				1		// do not change
#define SD_LOG_DBG				2		// do not change
#define SD_LOG_SENS_DBG			3		// do not change
#define SD_LOG					SD_LOG_SENS_DBG
/*<
 * 	SD_LOG_NONE: No data is logged to sd card
 * 	SD_LOG_SENS: Only sensor data is logged to sd card
 * 	SD_LOG_DBG: Only debug data is logged to sd card
 * 	SD_LOG_SENS_DBG: Debug and sensor data is logged to sd card
 */

/* Do not change */
#ifdef DEV_IS_NODE
#define USE_LORAWAN				0	/**< 0: LoRaWAN disabled				 */
#endif
#ifdef DEV_IS_REPEATER
#define USE_LORAWAN				1	/**< 1: LoRaWAN enabled					 */
#endif



/*
 * 	Configuration if device enters low-power mode or not
 */
#define USE_LOWPOWER			1	/**< 0: lowpower mode disabled*/
/**< 1: lowpower mode enabled*/

/*
 * 	Configuration of time source
 */
#define TIMESOURCE_NONE			0		// do not change
#define TIMESOURCE_GPS			1		// do not change
#define TIMESOURCE_DCF77		2		// do not change
#define TIMESOURCE				TIMESOURCE_NONE
								/*<
								 * 	TIMESOURCE_NONE: No timesource used
								 * 	TIMESOURCE_GPS: GPS used as timesource
								 * 	TIMESOURCE_DCF77: DCF77 used as timesource
								 */

/**
 *	Configuration if device should be connected to testbench
 *	Testbench affords some different PINOUT and other settings
 */
#define SETUP_TESTBENCH			0	/*< 0: connection NOT for testbench*/
/*< 1: connection for testbench*/

#define NETWORK_MODE_MESH		1
#define NETWORK_MODE_STAR		0
#define NETWORK_MODE			NETWORK_MODE_STAR

#if SETUP_TESTBENCH == 1
#warning Testbench setup is activated
#endif

/*
 * 	Configuration of the follwing LoRaWAN parameters:
 * 		- Device address
 * 		- Network Session Key
 * 		- Application Session Key
 * 		- Used LoRaWAN MAC port
 */
#ifdef DEV_IS_REPEATER
	#define NWK_SESSION_KEY "00000000000000000000000000000000"
	#define APP_SESSION_KEY "00000000000000000000000000000000"
	#define DEVICE_ADDR_LORAWAN						0x00000000
	#define LORAWAN_MAC_DATA_PORT					((uint8_t)2)
	#define DEVICE_ADDR_LORAMESH 						0x0001
#else
	#define NWK_SESSION_KEY "00000000000000000000000000000000"
	#define APP_SESSION_KEY "00000000000000000000000000000000"
	#define DEVICE_ADDR_LORAWAN					0x00000000
	#define LORAWAN_MAC_DATA_PORT				((uint8_t)52)
	#define DEVICE_ADDR_LORAMESH 2
#endif

#endif	//_DEVICE_CONFIG_H

