/*
 / _____)             _              | |
( (____  _____ ____ _| |_ _____  ____| |__
 \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 _____) ) ____| | | || |_| ____( (___| | | |
(______/|_____)_|_|_| \__)_____)\____)_| |_|
    (C)2013 Semtech

Description: Delay functions implementation

License: Revised BSD License, see LICENSE.TXT file include in the project

Maintainer: Miguel Luis and Gregory Cristian
*/
#include "board.h"

void delay_1ms ( void );

void Delay( float s )
{
	DelayMs( s * 1000.0f );
}

void DelayMs( uint32_t ms )
{
//	while( ms ){
//		delay_1ms();
//		ms--;
//	}
	//HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, GPIO_PIN_SET);
	HAL_Delay( ms );
	//HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, GPIO_PIN_RESET);
}


/**
 *  \brief  Delay of 1 ms using a while loop
 */
void delay_1ms ( void )
{
	uint32_t num_ticks = HAL_RCC_GetHCLKFreq() / 1000;
	num_ticks = (num_ticks * 14) / 125;
	while(num_ticks){
		num_ticks --;
	}
}

