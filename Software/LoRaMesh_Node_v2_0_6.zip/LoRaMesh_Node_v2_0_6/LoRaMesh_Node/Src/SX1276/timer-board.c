/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		timer-board.c
 *
 * \description	<add description>
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		21.12.2016
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "timer-board.h"
#include "board.h"

/* -- makros ----------------------------------------------------------------*/
#define TIMER_TICK_MS 		1
#define TIMER_TICK_PER_MS   1

#define NO_ERROR			0
#define ERROR				1


#define MCU_WAKEUPTIME		1	// assumption 1 ms TODO: optimize wakuep time

/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */

static void timer_board_init ( void );

static void timer_board_deinit ( void );
 
/* internal variable definitions ------------------------------------------- */ 
static TIM_TypeDef *timer = TIM2;			// use timer 2 WARNING:
											// when using other timer,
											// IRQ handler has to be modified
static uint8_t timer_is_initialized = FALSE;
//static uint32_t latest_start_cnt = 0;
//static uint32_t ellapsed_time = 0;
/*!
 * Flag used to indicates a the MCU has waken-up from an external IRQ
 */
//volatile uint8_t NonScheduledWakeUp = 0;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint8_t timer_board_set_timeout( uint32_t timeout)
{
	if( timer_is_initialized == FALSE) {
		timer_board_init( );
	}
	timer->CR1 &=~ TIM_CR1_CEN;				// stop timer
	NVIC_DisableIRQ(TIM2_IRQn);
	if( timeout < 1){
		timer->CNT = 0;
	} else {
		timer->CNT = (timeout - 1);
	}
	timer->SR &=~ TIM_SR_UIF;
	NVIC_ClearPendingIRQ(TIM2_IRQn);
	NVIC_EnableIRQ(TIM2_IRQn);
	timer->CR1 |= TIM_CR1_CEN;
	return 0;
}

/*
 * See header file
 */
void timer_board_stop( void )
{
	timer->CR1 &=~ TIM_CR1_CEN;
	NVIC_DisableIRQ(TIM2_IRQn);
	timer_board_deinit();
}

/*
 * See header file
 */
uint32_t timer_board_getAdjustedTimeoutValue (uint32_t timeout)
{
	// TODO: Implement adjusted timeout
    return  timeout;
}

/*
 * See header file
 */
uint32_t timer_board_get_cntval ( void )
{
	if((timer->CR1 & TIM_CR1_CEN) == TIM_CR1_CEN){
		return timer->CNT;
	} else
		return TIMER_ERROR;

}



void TIM2_IRQHandler ( void )
{
	if((timer->SR & TIM_SR_UIF) == TIM_SR_UIF) {	// update event occured
		timer->CR1 &=~ TIM_CR1_CEN;
		timer->SR  &=~ TIM_SR_UIF;
		//ellapsed_time += (latest_start_cnt + 1);
		TimerIrqHandler();
		NVIC_ClearPendingIRQ(TIM2_IRQn);
	}
}

/* internal functions definitions ------------------------------------------ */
/**
 * 	\brief	Initializes the TIM2 module
 * 			A flag is checked before to ensure that initialization is only
 * 			done when necessary.
 */
static void timer_board_init ( void )
{
	if( timer_is_initialized == FALSE) {
		__HAL_RCC_TIM2_CLK_ENABLE();
		while(!__HAL_RCC_TIM2_IS_CLK_ENABLED());
		timer->CR1 = 0x0000;	// reset value
		timer->CR1 |= (	TIM_CR1_CKD_1	|	// clock division by 4
						TIM_CR1_DIR 	|	// direction down
						TIM_CR1_OPM);		// one pulse mode
		timer->CR2 = 0x0000;
		timer->DIER |= TIM_DIER_UIE;		// enable update interrupt
		timer->PSC = (uint16_t)40000;		// leads to 1ms ticks
		timer->ARR = 0xFFFFFFFF;
		timer->EGR |= TIM_EGR_UG;			// update event

		timer->SR &=~ TIM_SR_UIF;			// clear interrupt flag

		NVIC_SetPriority(TIM2_IRQn, 11);		// configure interrupts
		NVIC_ClearPendingIRQ(TIM2_IRQn);
		NVIC_EnableIRQ(TIM2_IRQn);
		timer_is_initialized = TRUE;
	} else {

	}
}

/**
 *  \brief  Switches of the TIM2 module
 */
static void timer_board_deinit ( void )
{

	__HAL_RCC_TIM2_CLK_DISABLE();
	timer_is_initialized = FALSE;
}
