/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		lowpower.h
 *
 * \description	Handles low power modes of the MCU
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _LOWPOWER_H
#define _LOWPOWER_H

/* -- includes --------------------------------------------------------------*/
#include "stdint.h"

/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/
typedef enum	{	LP_OK = 0,
					LP_ERROR = 1
}lp_errors_t;


typedef enum {		RUN_MODE = 0,
					SLEEP_MODE,
					LP_RUN_MODE,
					LP_SLEEP_MODE,
					STOP0_MODE,
					STOP1_MODE,
					STOP2_MODE,
					STANDBY_MODE,
					SHUTDOWN_MODE
} lp_modes_t;


typedef struct lp_clients	{
								uint8_t 	(*deinit)( void );
								uint8_t 	(*reinit)( void );
								lp_modes_t	(*get_lpmode)(void);
}lp_clients_s;

/* public function declarations -------------------------------------------- */
/**
 *  \brief  Enables low-power functionality
 */
void lp_enable_low_power( void );

/**
 *  \brief  Disables low-power functionality
 */
void lp_disable_low_power( void );

/**
 *  \brief	This function has to be called from RTOS, during initialization
 *  		of the tickless idle mode (before idle hook).
 *  		The pointer to the ticks value is necessary, that the RTOS
 *  		does low-power-handling
 */
void lp_presleep_processing( uint32_t *ticks );

/**
 *  \brief	This function has to be called from RTOS, after exiting
 *  		the tickless idle mode (before idle hook).
 *  		The pointer to the ticks value is necessary, that the RTOS
 *  		does low-power-handling
 */
void lp_postsleep_processing( uint32_t *ticks );

/**
 * 	\brief	Register client to low power handler
 * 	\param	*newclient: pointer to new client which shoudl be registered
 * 	\return	return error codes
 */
lp_errors_t lp_register_client( lp_clients_s *newclient );

/**
 * 	\brief	Prepares low power mode by deinitialization of clients
 * 			and switching off all power stages
 */
void lp_prepare_lowpower( void );

/**
 * 	\brief	Exits low power mode by reinitialization of clients
 * 			and switching off all power stages
 */
void lp_exit_lowpower( void );

#endif	//_LOWPOWER_H

