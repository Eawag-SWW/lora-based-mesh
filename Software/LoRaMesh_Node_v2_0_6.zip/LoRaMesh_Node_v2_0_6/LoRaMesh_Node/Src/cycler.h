/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		cycler.h
 *
 * \description	This module handles the timing behaviour of a device by
 * 				calling differnet task at the specified time.
 * 				This module is basesd on code of D. Ast
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _CYCLER_H
#define _CYCLER_H

/* -- includes --------------------------------------------------------------*/
#include <stdint.h>

/* -- makros ----------------------------------------------------------------*/
#define CY_UPDATE_EVENT_NEWCYLE 0
#define CY_UPDATE_EVENT_NEWSTATE 1

/* -- type definitions-------------------------------------------------------*/

typedef uint8_t alarm_id;


typedef struct CyTask {
	/**< slot in the cycle for task											*/
	uint16_t slot;
	/**< subslot used for the task when set to 0, the task is processed
	 *	 immediatley, otherwiese the task execution is delayed by
	 *	 (subslot * subslot_duration)										*/
	uint8_t subslot;
	/**< state of the task (used by cycler)									*/
	uint8_t state;
	/**< type of the task (see task_type_t)									*/
	uint8_t type;
	/**< wakeup offset, which defines if a task should be started
	 * earlier than it's slot starts										*/
	uint16_t wakeup_offset_ms;
	/**< points to the next entry in the buffer (used by the cycler module) */
	struct CyTask *next;
} TCyTask;



typedef void (*TaskHandler)( TCyTask *task, uint32_t t2Stamp );

typedef void (*BeforeIssueHook)( TCyTask *task, uint16_t *inset );

typedef void (*NewCycleHook)( uint8_t *changed );

/* public function declarations -------------------------------------------- */
/**
 *  \brief  Initializes cycler module
 */
void cyInit( void );

/**
 * 	\brief	Resets cycler module
 */
void cyReset( void );

/*
 * 	\brief	Sets the start time of the scheduler relative to the current time
 * 			The first task will take place at the desired start
 * 			time
 * 	\param	ms_offset	desired time-offset in milliseconds
 * 	\ret	returns 0 on success, nonzero otherwise
 */
uint8_t cySetStartTimeRel ( uint32_t ms_offset );

/*
 * 	\brief	Sets the start time of the scheduler as absolute value
 * 			The first task will take place at the desired start
 * 			time
 * 	\param	startime	desired time as UTC time
 * 	\param	start_ms	desired milliseconds
 * 	\ret	returns 0 on success, nonzero otherwise
 */
uint8_t cySetStartTimeAbs ( uint32_t starttime, uint16_t start_ms );

/**
 * 	\brief	Sets the cycle start time to the next possible start time
 * 			(according to current system time)
 * 	\param	starttime:	desired start-time
 * 	\param	start_ms:	desired start-time millisecond offset
 * 	\return	Returns 0 on success, nonzero otherwise
 */
uint8_t cySetNextPossibleStart( uint32_t starttime, uint16_t start_ms );

/*
 * 	\brief	Get current RTC-time (systemtime)
 * 	\param	*time:		buffer to store 32-bit utc value
 * 	\param	*time_ms:	buffer to store current ms value
 */
uint8_t cyGetRTCTime( uint32_t *time, uint16_t *time_ms );

/*
 * 	\brief	Updates current system time and cycle start time
 * 	\param	time:	32bit UTC update value
 * 	\param	time_ms:millisecond update value
 */
uint8_t cyUpdateStartRTCTime( uint32_t time, uint16_t time_ms );

/*
 * 	\brief	Updates RTC time
 * 	\param	time:	32bit UTC update value
 * 	\param	time_ms:millisecond update value
 */
uint8_t cyUpdateRTCTime	( uint32_t time, uint16_t time_ms );

/*
 *	\brief	Schedules next task
 */
void cySchedule( void );

/*
 * 	\brief	Dispatches scheduled task
 */
void cyDispatch( void );
/**
 * 	\brief	Registers a new task to the cycler module
 * 	\param	*prototype:		pointer to task prototype struct
 * 							the prototype must be initalized by calling
 * 							cyInitPrototype-function
 * 	\return	returns 0 on sueccess, nonzero on error
 */
uint8_t cyRegisterTask( TCyTask *prototype ) ;

/*
 * 	\brief	Removes task from the cyclers list
 * 	\param	slot of the task to be deleted
 */
void cyRemoveTask( uint16_t slot ) ;

/*
 * 	\brief	Gets task which is placed at a given slot
 * 	\param	slot of the desired task
 * 	\return	Task struct containing values of the desired task
 */
TCyTask *cyGetTask( uint16_t slot );

/*
 * 	\brief	Gets first task of the cycler
 * 	\return	Task struct containing values of the first task
 */
TCyTask *cyGetFirstTask( void );

/*
 * 	\brief	Cleans the list and removes unused tasks
 */
void cyCleanup( void );
/**
 * 	\brief	Initalizes a task prototype struct with necessary values
 * 			This function must be called before registering the task
 * 	\param	*prototype:	pointer to task struct to be registered
 */
void cyInitPrototype( TCyTask *prototype );

/*
 * 	\brief	Dumps all registered tasks (with printf)
 */
void cyDumpTasks( void );

/*
 * 	\brief	Registers a task handler which is called when dispatching
 * 	\param	taskHandler:	handler to be registered
 */
void cyRegisterTaskHandler( TaskHandler taskHandler );

/*
 * 	\brief	Registers a hook function which is called each time
 * 			before a task is processed
 * 	\param	beforeIssueHook:	desired function to be registered
 */
void cyRegisterBeforeIssueHook( BeforeIssueHook beforeIssueHook );

/*
 * 	\brief	Registers a hook function which is called each time
 * 			a new cycle starts
 * 	\param	hook:	desired function to be registered
 */
void cyRegisterNewCycleHook( NewCycleHook hook );

#endif		//_CYCLER_H

