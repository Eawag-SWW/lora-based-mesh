/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		subslot_handler.h
 *
 * \description	Handles subslots for child nodes
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		18.09.2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _SUBSLOT_HANDLER
#define _SUBSLOT_HANDLER

/* -- includes --------------------------------------------------------------*/
#include "stdint.h"

/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/


/* public function declarations -------------------------------------------- */

/**
 *  \brief  Initializes the subslot handler with desired amount of subslots
 *  \param  n_subslots:	desired amount of subslots
 *  \return 0 on succes, nonzero on error
 */
uint8_t subslot_handler_init( uint8_t n_subslots );

/**
 *  \brief  Resets all subslots
 *  \return 0 on succes, nonzero on error
 */
uint8_t subslot_handler_reset( void );

/**
 *  \brief	Register a specified subslot for a given node
 *  \param  subslot_nr:	desired subslot number
 *  \param	node_addr:	address of node for which the subslot is reserved
 *  \return 0 on succes, nonzero on error
 */
uint8_t subslot_handler_register_subslot(	uint8_t subslot_nr,
											uint16_t node_addr);

/*
 * 	\brief	Searches a free subslot and registers a node on this subslot
 * 	\param	node_addr:	address of the node for which the subslot is reserved
 * 	\return	returns the slot number on success, 0xFF on error
 */
uint8_t subslot_handler_get_reg_free_subslot( uint16_t node_addr);

/*
 * 	\brief	Deregisters a window for a given node
 * 	\param	node_addr: address of the node
 * 	\return	returns 0 on success, nonzero on error
 */
uint8_t subslot_handler_deregister_subslot( uint16_t node_addr );

/**
 * 	\brief	Increments timeout counter for all registered nodes
 */
void subslot_handler_increment_all_timeouts( void );

/**
 * 	\brief	Resets the timeout counter for a given node
 * 	\param	naddr	address of the node whose counter should be reset
 * 	\return returns 0 when the node was found and counter was reset
 * 			nonzero if the node could'nt be found in the subslot table
 */
uint8_t subslot_handler_reset_timeout_for_node( uint16_t naddr );

/**
 * 	\brief	Returns the timeout counter for a given node
 * 	\param	naddr	address of the node
 * 	\return	returns the counter on success, 0xFF on error
 */
uint8_t subslot_handler_get_timeout_cnt_for_node( uint16_t naddr);

/**
 * 	\brief	Returns addresses of all node whose timeout counters
 * 			have expired a treshold
 * 			ATTENTION: Buffers have to be allocated by calling
 * 					   module. Nullpointers will cause errors.
 * 	\param	threshold	expiration threshold
 * 	\param	*numnodes	pointer to buffer where number of expired
 * 						nodes can be stored
 * 	\param	*naddresses	pointer to buffer where addresses of
 * 						expired node can be stored
 */
uint8_t subslot_handler_get_expired_timeouts( 	uint8_t threshold,
												uint8_t *numnodes,
												uint16_t *naddresses);

#endif	//_SUBSLOT_HANDLER

