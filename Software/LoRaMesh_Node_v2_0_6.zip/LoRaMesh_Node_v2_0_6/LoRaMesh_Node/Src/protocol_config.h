/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		protocol_config.h
 *
 * \description	Configuration of the whole network by defining parameters
 * 				in the ptkSetConfigXXXSetup functions
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _PROTOCOL_CONFIG_H
#define _PROTOCOL_CONFIG_H

/* -- includes --------------------------------------------------------------*/
#include <stdint.h>

/* -- makros ----------------------------------------------------------------*/
#define PTK_CONFIG_LIVE 0
#define PTK_CONFIG_TEST 1

/* -- type definitions-------------------------------------------------------*/

typedef struct PtkConfig {

	uint16_t slot_duration_ms;		/**< Slot duration in milliseconds		 */

	uint16_t subslot_duration_ms;	/**< Duration of subslots in milliseconds*/

	uint16_t N_sync_slots;		/**< number of reserved slots
									 used for synchronization				 */

	uint16_t N_jreq_slots;		/**< number of reserved slots used for
									 join requests							 */
	uint16_t N_approve_slots;	/**< number of reserved slots used for
									 approve messages						 */
	uint16_t N_uplink_slots;		/**< number of uplink slots				 */

	uint16_t N_downlink_slots;	/**< number of downlink slots				 */

	uint16_t N_wan_slots;		/**< number of slots reserved for
									 LoRaWAN communication					 */
	uint16_t N_guard_slots;		/**< number of slots the subnetwork is in
									 idle state								 */

	uint32_t N_cycle;			/**< number of total slots per cycle		 */

	uint8_t max_netw_nodes;		/**< maximum number of participating nodes in
									 one sub-network						 */

	uint32_t cycle_duration_s;	/**< Cycle duration in seconds				 */

	uint16_t fw_duration_ms;	/**< Duration of a forwarding window		 */

	/**< Maximum amount of uplink timeouts before note exits the network	 */
	uint8_t  max_ul_timeout;
	/**< Maximum join timeout before node starts to search antoher join agent*/
	uint8_t  max_join_timeout;
} TPtkConfig;

typedef enum {	PTK_MODE_TEST = 0,
				PTK_MODE_NORMAL
} ptk_modes_t;
/* public function declarations -------------------------------------------- */

/**
 *  \brief  Sets protocol configuration according to desired mode
 *  \param	mode:	desired mode to be setup
 *  \return 0 on success, nonzero on error
 */
uint8_t ptk_set_config( ptk_modes_t mode );

/**
 *  \brief  Returns configured number of synchronization slots
 *  \return number of sync slots
 */
uint16_t ptk_get_nsync ( void );

/**
 * 	\brief	Returns configured number of approve slots
 * 	\return	number of approve slots
 */
uint16_t ptk_get_napprove ( void );

/**
 * 	\brief	Returns number of join slots
 * 	\return	number of join slots
 */
uint16_t ptk_get_njoin ( void );

/**
 * 	\brief	Returns number of uplink slots
 * 	\return	number of join slots
 */
uint16_t ptk_get_nuplink ( void );

/**
 * 	\brief	Returns number of downlink slots
 * 	\return	number of join slots
 */
uint16_t ptk_get_ndownlink ( void );

/**
 *  \brief  Returns configured slot duration in milliseconds
 *  \return slot duration in milliseonds
 */
uint16_t ptk_get_slot_duration_ms( void );

/**
 *  \brief  Returns configured cycle duration in seconds
 *  \return cycle duration in seconds
 */
uint32_t ptk_get_cycle_duration_s( void );

/**
 * 	\brief	Returns configured maximum amount of nodes per subnetwork
 * 	\return Maximum amount of nodes per subnetwork
 */
uint8_t ptk_get_num_network_nodes ( void );

/**
 * 	\brief	Returns duration of the forwarding window
 * 	\return duration of the forwarding window in milliseconds
 */
uint16_t ptk_get_fw_duration_ms( void );

/**
 * 	\brief	Returns duration of a subslot
 * 	\return duration of a subslot in milliseconds
 */
uint16_t ptk_get_subslot_duration_ms( void );

/**
 * 	\brief	Returns maximum uplink timeouts
 * 	\return maximum uplink timeouts
 */
uint8_t ptk_get_max_ul_timeouts( void );

/**
 * 	\brief	Returns maximum join timeouts
 * 	\return maximum join timeouts
 */
uint8_t ptk_get_max_join_timeouts( void );
/**
 * 	\brief	Gets the necessary rx offset for sync process
 * 	\return	returns rx offset for sync process
 */
uint16_t ptk_get_sync_rx_offset( void );

/**
 * 	\brief	Returns expected join request timeout
 * 			according to used spreading factor
 * 	\return	join request timeout in milliseconds
 */
uint32_t ptk_get_jreq_timeout( void );

/**
 * 	\brief	Returns expected acknowledge timeout
 * 			according to used spreading factor
 * 	\return	acknowledge timeout in milliseconds
 */
uint32_t ptk_get_ack_timeout( void );

/**
 * 	\brief	Returns expected beacon timeout
 * 			according to used spreading factor
 * 	\return	beacon timeout in milliseconds
 */
uint32_t ptk_get_beacon_timeout( void );

#endif	//_PROTOCOL_CONFIG_H

