/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		lowpower.c
 *
 * \description	Handles low power modes of the MCU
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "device_config.h"
#include "lowpower.h"
#include "stm32l4xx.h"
#include "mcu_hal.h"
#include "stdlib.h"
#include "power_switches/power_switches.h"
#include "ldo.h"
#include "cmsis_os.h"
#include "string.h"
/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */
static lp_errors_t deinit_clients( void );
static lp_errors_t reinit_clients( void );
 
/* internal variable definitions ------------------------------------------- */ 
static uint8_t low_power_enabled = 0;
static lp_clients_s *clients = NULL;
static uint8_t num_clients = 0;

/* public function definitions --------------------------------------------- */
/*
 * See header file
 */
void lp_enable_low_power( void )
{
	low_power_enabled = 1;
}

/*
 * See header file
 */
void lp_disable_low_power( void )
{
	low_power_enabled = 0;
}

/*
 * See header file
 */
void lp_presleep_processing( uint32_t *ticks )
{
#if USE_LOWPOWER == 1
	if( low_power_enabled ){
		__HAL_RCC_DMA2_CLK_DISABLE( );
		HAL_NVIC_DisableIRQ( TIM1_UP_TIM16_IRQn);
		HAL_NVIC_ClearPendingIRQ( TIM1_UP_TIM16_IRQn);
		SysTick->CTRL &=~ (1 << SysTick_CTRL_ENABLE_Pos);
		ldo_main_enable_powersafe( );
		*ticks = 0;
		HAL_PWREx_EnterSTOP2Mode( PWR_STOPENTRY_WFI);

#if USE_DBG_IN_STOPMODE == 1
	HAL_DBGMCU_EnableDBGStopMode( );

#else
	HAL_DBGMCU_DisableDBGStopMode( );
#endif

	} else {
		*ticks = 0;
	}
#else
	*ticks = 0;
#endif
}

/*
 * See header file
 */
void lp_postsleep_processing( uint32_t *ticks )
{
#if USE_LOWPOWER == 1
	if( low_power_enabled ){
		MCU_Init( );	// reinitialize MCU
		ldo_main_disable_powersafe( );
		HAL_NVIC_EnableIRQ( TIM1_UP_TIM16_IRQn);
		SysTick->CTRL |= (1 << SysTick_CTRL_ENABLE_Pos);
		__HAL_RCC_DMA2_CLK_ENABLE( );
	}
#endif
}

/*
 * See header file
 */
void lp_prepare_lowpower( void )
{
#if USE_LOWPOWER == 1
	deinit_clients( );
	power_switch_control_enter_lowpower( );
#endif
}

/*
 * See header file
 */
void lp_exit_lowpower( void )
{
#if USE_LOWPOWER == 1
	power_switch_control_exit_lowpower( );
	reinit_clients( );
#endif
}

/*
 * See header file
 */
lp_errors_t lp_register_client( lp_clients_s *newclient )
{
	lp_clients_s *old = NULL;
	if( newclient == NULL ){
		return LP_ERROR;
	}
	if( clients == NULL ){	// first entry
		clients = pvPortMalloc( sizeof( lp_clients_s ));
		if( clients == NULL ){
			return LP_ERROR;
		}
	} else {
		old = clients;
		clients = pvPortMalloc((num_clients + 1) * sizeof( lp_clients_s ));
		if( clients == NULL ){
			return LP_ERROR;
		}
		memcpy( clients, old, num_clients * sizeof( lp_clients_s ));
		vPortFree( old );
	}
	(clients + num_clients)->deinit = newclient->deinit;
	(clients + num_clients)->reinit = newclient->reinit;
	(clients + num_clients)->get_lpmode = newclient->get_lpmode;
	num_clients++;
	return LP_OK;
}

/* internal functions definitions ------------------------------------------ */
/**
 *  \brief  De-initializes registered clients
 *  \return Error code
 */

static lp_errors_t deinit_clients( void )
{
	uint8_t i = 0;
	lp_errors_t err = LP_OK;
	if( clients == NULL ){
		return LP_OK; // no clients available
	}
	for(i=0; i<num_clients; i++)
	{
		if( (clients + i)->deinit != NULL){
			(clients + i)->deinit();
		} else {
			err = LP_ERROR;
		}
	}
	return err;
}

/**
 *  \brief  Re-initializes registered clients
 *  \return Error code
 */
static lp_errors_t reinit_clients( void )
{
	uint8_t i = 0;
	lp_errors_t err = LP_OK;
	if( clients == NULL ){
		return LP_OK;	// no clients available
	}
	for( i=0; i<num_clients; i++){
		if( (clients + i)->reinit != NULL ){
			(clients + i)->reinit();
		} else {
			err = LP_ERROR;
		}
	}
	return err;
}
