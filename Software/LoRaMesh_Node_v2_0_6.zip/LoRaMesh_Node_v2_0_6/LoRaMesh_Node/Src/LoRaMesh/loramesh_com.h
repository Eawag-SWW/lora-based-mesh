/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		loramesh_com.h
 *
 * \description	LoRaMesh abstraction layer which handles communication with
 * 				the radio module
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _LORAMESH_COM_H
#define _LORAMESH_COM_H

/* -- includes --------------------------------------------------------------*/
#include "stdint.h"
#include "loramesh_pkt.h"
/* -- makros ----------------------------------------------------------------*/

/* -- type definitions-------------------------------------------------------*/

typedef enum { 	COM_OK = 0,
				COM_ERROR,
				COM_ERROR_NULLPOINTER,
				COM_ERROR_LEN_ERROR,
				COM_ERROR_BUSY
}loramesh_com_errors_t;


typedef enum { 	COM_EVT_NO_EVENT = 0,
				COM_EVT_TX_DONE,
				COM_EVT_TX_TIMEOUT,
				COM_EVT_RX_DONE,
				COM_EVT_RX_TIMEOUT
} lora_com_event_t;

typedef struct {
				uint32_t lora_channel;
				int8_t   lora_output_power;
				uint32_t lora_bandwidth;
				uint32_t lora_spreading_factor;
				uint32_t lora_coding_rate;
				uint32_t lora_timeout;
} lora_params_t;


/*!
 * \brief Radio driver callback functions
 */
typedef struct
{
    /*!
     * \brief  Tx Done callback prototype.
     */
    void    ( *send_done )( loramesh_pkt_type_t last_ptype );
    /*!
     * \brief  Tx Timeout callback prototype.
     */
    void    ( *send_timeout )( loramesh_pkt_type_t last_pkttype );
    /*!
     * \brief Rx Done callback prototype.
     *
     * \param [IN] payload Received buffer pointer
     * \param [IN] size    Received buffer size
     * \param [IN] rssi    RSSI value computed while receiving the frame [dBm]
     * \param [IN] snr     Raw SNR value given by the radio hardware
     *                     FSK : N/A ( set to 0 )
     *                     LoRa: SNR value in dB
     */
    void    ( *receive_done )( loramesh_pkt_s *packet, int16_t rssi, int8_t snr );
    /*!
     * \brief  Rx Timeout callback prototype.
     */
    void    ( *receive_timeout )( void );
    /*!
     * \brief Rx Error callback prototype.
     */
    void    ( *receive_error )( void );
    /*!
     * \brief  FHSS Change Channel callback prototype.
     *
     * \param [IN] currentChannel   Index number of the current channel
     */
    //void ( *FhssChangeChannel )( uint8_t currentChannel );

    /*!
     * \brief CAD Done callback prototype.
     *
     * \param [IN] channelDetected    Channel Activity detected during the CAD
     */
    //void ( *CadDone ) ( bool channelActivityDetected );
}loramesh_com_callbacks_t;

/* public function declarations -------------------------------------------- */

/**
 *  \brief  Initializes the LoRaMesh communication
 *  		sets up the radio with default parameters
 *  		sets callback functions
 *  \param  *cb:	poiner to callback functions
 *  \return returns an error code on failure
 */
loramesh_com_errors_t loramesh_com_init ( loramesh_com_callbacks_t *cb);

/**
 * 	\brief	Sets the transmission parameters of the LoRa communication
 * 	\param	*params		pointer to parameter to be set
 * 	\return returns an error code on failure
 */
loramesh_com_errors_t loramesh_com_set_tx_params (lora_params_t *params);	//TODO: can maybe moved into module

/**
 * 	\brief	Sets the reception parameters of the LoRa communication
 * 	\param	*params		pointer to parameter to be set
 * 	\return returns an error code on failure
 */
loramesh_com_errors_t loramesh_com_set_rx_params (lora_params_t *params);	//TODO: can maybe moved into module

/**
 * 	\brief	Sends a data packet via LoRa transceiver
 * 	\param	*packet		pointer to packet data to be sent
 * 	\return returns an error code on failure
 */
loramesh_com_errors_t loramesh_com_send ( loramesh_pkt_s *packet);

/**
 * 	\brief	Start receiving packets from LoRa transceiver
 * 	\param	*params		pointer to parameter to be set
 * 	\return returns an error code on failure
 */
loramesh_com_errors_t loramesh_com_receive ( void );

/**
 * 	\brief	Sets the radio in sleep mode
 * 	\return returns an error code on failure
 */
loramesh_com_errors_t loramesh_com_set_sleep( void );


// TODO: description
loramesh_com_errors_t loramesh_com_de_init( void );
/**
 * 	\brief	Resets an re-initializes the radio
 * 	\return returns an error code on failure
 */
loramesh_com_errors_t loramesh_com_re_init ( void );

/**
 * 	\brief	Returns current spreading factor
 * 	\return current spreading facotr
 */
uint8_t loramesh_com_get_current_sf( void ) ;

/**
 * 	\brief	Returns the TOA of a packet in us
 *	\param	len	packet length
 * 	\return time on air of a packet
 */
uint32_t loramesh_com_get_toa( uint8_t len );

#endif

