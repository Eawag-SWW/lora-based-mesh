/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		loramesh_pkt.h
 *
 * \description	Defines the LoRaMesh packet structure
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		04.09.2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _LORAMESH_PKT
#define _LORAMESH_PKT

/* -- includes --------------------------------------------------------------*/
#include "stdint.h"

/* -- makros ----------------------------------------------------------------*/
#define LORA_MAX_PKT_LENGTH			64			// TODO: Change length

#define LORAMESH_MAX_PL		(LORA_MAX_PKT_LENGTH - LORAMESH_HDDR_LEN)

#define	LORAMESH_HDDR_LEN 			5
#define LORAMESH_PL_HDDR_LEN		4

#define LORAMESH_BEACON_PL_LEN		7
#define LORAMESH_JREQ_PL_LEN		0
#define LORAMESH_JRESP_PL_LEN		6
#define LORAMESH_NEWNODE_PL_LEN		4
#define LORAMESH_DHEADER_LEN		4
#define LORAMESH_CONF_PL_LEN		1

/* -- type definitions-------------------------------------------------------*/
typedef enum {	LORAMESH_PTYPE_BEACON = 	(uint8_t) 0x01,
				LORAMESH_PTYPE_JREQ = 		(uint8_t) 0x02,
				LORAMESH_PTYPE_JRES = 		(uint8_t) 0x03,
				LORAMESH_PTYPE_NEWNODE = 	(uint8_t) 0x04,
				LORAMESH_PTYPE_RMNODE = 	(uint8_t) 0x05,
				LORAMESH_PTYPE_DATA = 		(uint8_t) 0x06,
				LORAMESH_PTYPE_CONF = 		(uint8_t) 0x07
} loramesh_pkt_type_t;

typedef enum {	LORAMESH_FLSTT_MD			= ((uint8_t) 0x01),
				LORAMESH_FLSTT_PIGGIBACKED 	= ((uint8_t) 0x02)
} loramesh_stt_flags_t;

typedef enum {	LORAMESH_NACK		= ((uint8_t) 0x00),
				LORAMESH_ACK		= ((uint8_t) 0xFF)
} loramesh_conf_t;

typedef struct loramesh_header {
		uint16_t dest_addr;
		uint16_t src_addr;
		loramesh_pkt_type_t type;
} loramesh_header_s;


typedef struct loramesh_data_header{
		uint8_t payload_len;
		uint16_t pkt_num;
		uint8_t status;
} loramesh_data_header_s;

typedef struct loramesh_remove_header{
		uint8_t num_nodes;
} loramesh_remove_header_s;

typedef struct loramesh_pkt{
		loramesh_header_s header;
		loramesh_data_header_s data_header;
		loramesh_remove_header_s rm_header;
		uint8_t *payload;
} loramesh_pkt_s;

/* public function declarations -------------------------------------------- */


#endif	//_LORAMESH_PKT

