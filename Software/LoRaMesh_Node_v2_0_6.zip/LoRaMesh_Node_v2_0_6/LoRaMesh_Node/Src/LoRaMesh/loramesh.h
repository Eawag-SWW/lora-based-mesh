/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		loramesh.c
 *
 * \description	LoRaMesh communication layer implementation
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		14.02.2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _LORAMESH_H
#define _LORAMESH_H

/* -- includes --------------------------------------------------------------*/
//#include "loramesh_com.h"
#include "loramesh_pkt.h"
#include "stdint.h"

/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/

/** @defgroup LORA_MESH_ERRORS LORA MESH ERROS
 *  @{
 */
typedef enum {  LORAMESH_OK = 0,
				LORAMESH_ERROR,
				LORAMESH_ERROR_NULLPOINTER,
				LORAMESH_ERROR_LEN
}loramesh_errors_t;

/** @defgroup LORA_RX_CALLBACK_PARAM	LoRaMesh callback receive parameters
 *  @{
 */
typedef struct { 	uint32_t utc_time;
					uint16_t source_address;
					int16_t	 rssi;
					uint8_t  num_hops;
					uint8_t fw_window;
					uint8_t subnet_id;
}loramesh_sync_s;

typedef struct { 	uint8_t payload_len;
					uint16_t pkt_num;
					uint8_t status;
}loramesh_dheader_s;

typedef struct { 	uint16_t source_address;
					loramesh_dheader_s data_header;
					uint8_t  data[LORAMESH_MAX_PL];
}loramesh_rx_data_s;


typedef struct { 	uint16_t source_address;
					uint8_t confirmation;
					uint8_t forwarding_window;
					uint8_t uplink_slot_nr;
					uint8_t downlink_slot_nr;
					uint8_t parent_slot;
					uint8_t subslot_nr;
}loramesh_joinresp_s;
/** @defgroup LORA_RX_CALLBACKS	LoRaMesh callback functions
 *  @{
 */
typedef struct { void (*cb_beacon_received) (loramesh_sync_s *sync);
				 void (*cb_tx_done)( void );
				 void (*cb_rx_done)( loramesh_rx_data_s *rx_data );
				 void (*cb_rx_error)( void );
				 void (*cb_tx_error)( void );
				 void (*cb_join_req_received) (uint16_t source_addr);
				 void (*cb_join_resp_received)(loramesh_joinresp_s *resp);
				 void (*cb_confirmation_received)( loramesh_conf_t confirmation  );
}loramesh_callbacks_s;


/* public function declarations -------------------------------------------- */
/**
 *  \brief  Initializes the communication interface for loramesh
 *  		Sets the radio up with default parameters
 *  \param  none
 *  \return Return an error code see
 *			see @ref LORA_MESH_ERRORS
 */
loramesh_errors_t loramesh_init ( uint16_t own_address,
								  loramesh_callbacks_s *callbacks);

/**
 *  \brief  Start receiving on mesh layer
 *  \param  timeout:	receiver timeout in miliseconds
 *  \return Return an error code see
 *			see @ref LORA_MESH_ERRORS
 */
loramesh_errors_t loramesh_receive ( void );


/**
 *  \brief  Sends data over the LoRaMesh-network
 *  \param  dest_addr:	destination address
 *  \param	data_len:	length of the data packet in bytes
 *  \param	*data		pointer to data buffer
 *  \return Return an error code see
 *			see @ref LORA_MESH_ERRORS
 */
loramesh_errors_t loramesh_send_data (	uint16_t dest_addr,
										uint8_t data_len,
										uint8_t *data		);

/**
 *  \brief  Sends out a beacon packet over the LoRaMesh network
 *  \param  systime:	 actual system time as 32-bit UTC time
 *  \param 	forw_window: index of the forwareding window the beacon is sent
 *  \param	nhops:		 number of hops to outsending node is away from GW
 *  \param	subnet_id:	 identification number of the subnet-id
 *  \return Return an error code see
 *			see @ref LORA_MESH_ERRORS
 */
loramesh_errors_t loramesh_send_beacon ( uint32_t systime, uint8_t forw_window,
										 uint8_t nhops, uint8_t subnet_id );


/**
 *  \brief  Sends out a join response packet over the LoRaMesh network
 *  \param  dest_addr	desired destination address
 *  \return Return an error code see
 *			see @ref LORA_MESH_ERRORS
 */
loramesh_errors_t loramesh_send_join_request(	uint16_t dest_addr );

/**
 *  \brief  Sends out a join response packet over the LoRaMesh network
 *  \param  dest_addr		desired destination address
 *  \param	confirmation	ACK or NACK
 *  \param	forw_window		beacon forwarding window for joinee
 *  \param	slot_number_ul	uplink slot number for joinee
 *  \param	slot_number_dl	downlink slot number for joinee
 *  \param	slot_parent		receive slot of parent node of the joinee
 *  \param	subslot			subslot number for joinee
 *  \return Return an error code see
 *			see @ref LORA_MESH_ERRORS
 */
loramesh_errors_t loramesh_send_join_response( 	uint16_t dest_addr,
												uint8_t confirmation,
												uint8_t forw_window,
												uint8_t slot_number_ul,
												uint8_t slot_number_dl,
												uint8_t slot_parent,
												uint8_t subslot);

/**
 *  \brief  Sends out a confirmation packet to desired destination address
 *  \return Return an error code see
 *			see @ref LORA_MESH_ERRORS
 */
loramesh_errors_t loramesh_send_confirmation( uint16_t dest_addr, loramesh_conf_t conf );

/**
 *  \brief  Stops the radio ( sleep mode )
 *  \return Return an error code see
 *			see @ref LORA_MESH_ERRORS
 */
loramesh_errors_t loramesh_radio_stop( void );

/**
 * 	\brief	Resets the LoRaMesh radio
 * 	\return	error code
 */
loramesh_errors_t loramesh_radio_reset ( void );

/*
 * 	\brief	Returns current spreading factor
 */
uint8_t loramesh_get_sf ( void ) ;

/*
 * 	\brief	Calculates the TOA of a synchronization packet
 * 	\return	TOA of a sync packet in milliseconds
 */
uint32_t loramesh_get_toa_sync ( void );

/*
 * 	\brief	Calculates the TOA of a confimration packet
 * 	\return	TOA of a confirmation packet in milliseconds
 */
uint32_t loramesh_get_toa_conf( void );

/*
 * 	\brief	Calculates the TOA of a data packet
 * 	\param	payload_len: legnth of the data payload
 * 	\return	TOA of a data packet in milliseconds
 */
uint32_t loramesh_get_toa_data( uint8_t payload_len );
#endif	//_LORAMESH_H

