/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		loramesh.c
 *
 * \description	LoRaMesh communication layer implementation
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		14.02.2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "loramesh.h"
#include "loramesh_pkt.h"
#include "loramesh_com.h"
#include "board.h"
#include "string.h"
#include "network_config.h"
#include "utilities.h"
#include "lowpower.h"

/* -- makros ----------------------------------------------------------------*/

/* -- type definitions-------------------------------------------------------*/
/** LoRa Mesh status														 */
typedef enum {  STT_INIT = 0,
				STT_TX,
				STT_RX
}loramesh_states_t;

/* internal function declarations ------------------------------------------ */
/** callback functions for handling events from lower layer 				 */
void on_send_done ( loramesh_pkt_type_t last_pkttype );
void on_send_timeout ( loramesh_pkt_type_t last_pkttype );
void on_receive_done( loramesh_pkt_s *pkt, int16_t rssi, int8_t snr);
void on_receive_timeout( void );
void on_receive_error( void );

/** functions used for low power handler (le_handler)						 */
static uint8_t loramesh_deinit( void );
static uint8_t loramesh_reinit( void );
static lp_modes_t loramesh_get_lpmode( void );

/* internal variable definitions ------------------------------------------- */
static uint16_t curr_address = 0x00;			/** current device address	 */
static loramesh_com_callbacks_t com_callbacks;  /** callback pointers
													for getting events from
													lower layer				 */
static loramesh_pkt_s tx_packet;				/** tx packet buffer		 */
static loramesh_rx_data_s 	rx_data;			/** buffet to store latest
													received data			 */
static loramesh_sync_s 		sync_data;			/** buffer to store latest
													synchronization data	 */
static loramesh_joinresp_s  jresp_data;			/** buffer to store latest
													join response data		 */
static loramesh_callbacks_s callbacks;			/** callback pointer for
													forwarding events to
													upper layer				 */
static uint16_t tx_packet_cnt = 0;				/** tx packet counter		 */

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
loramesh_errors_t loramesh_init ( uint16_t own_address,
								  loramesh_callbacks_s *cb_functions)
{
	lp_clients_s lpclient;
	if( cb_functions == NULL ){
		return LORAMESH_ERROR_NULLPOINTER;
	}
	if(		(own_address == LORAMESH_BROADCAST_ADDR0) ||
			(own_address == LORAMESH_BROADCAST_ADDR1)){
		return LORAMESH_ERROR;
	}

	callbacks.cb_beacon_received = cb_functions->cb_beacon_received;
	callbacks.cb_rx_done = cb_functions->cb_rx_done;
	callbacks.cb_rx_error = cb_functions->cb_rx_error;
	callbacks.cb_tx_done = cb_functions->cb_tx_done;
	callbacks.cb_tx_error = cb_functions->cb_tx_error;
	callbacks.cb_join_req_received = cb_functions->cb_join_req_received;
	callbacks.cb_join_resp_received = cb_functions->cb_join_resp_received;
	callbacks.cb_confirmation_received = cb_functions->cb_confirmation_received;


	curr_address = own_address;
	com_callbacks.receive_done = on_receive_done;
	com_callbacks.receive_error = on_receive_error;
	com_callbacks.receive_timeout = on_receive_timeout;
	com_callbacks.send_done = on_send_done;
	com_callbacks.send_timeout = on_send_timeout;
	loramesh_com_init(&com_callbacks);

	lpclient.deinit = loramesh_deinit;
	lpclient.reinit = loramesh_reinit;
	lpclient.get_lpmode = loramesh_get_lpmode;
	lp_register_client( &lpclient );
	return LORAMESH_OK;
}

/*
 * See header file
 */
loramesh_errors_t loramesh_radio_reset ( void )
{
	if( loramesh_com_init( &com_callbacks ) != COM_OK ) {
		return LORAMESH_ERROR;
	} else {
		return LORAMESH_OK;
	}
}

/*
 * See header file
 */
loramesh_errors_t loramesh_receive ( void )
{
	if(loramesh_com_receive( ) != COM_OK){
		return LORAMESH_ERROR;
	}
	return LORAMESH_OK;
}

/*
 * See header file
 */
loramesh_errors_t loramesh_send_data (	uint16_t dest_addr,
										uint8_t  data_len,
										uint8_t  *data		)
{
	//TODO: actualize function
	uint8_t i = 0;
	if( data == NULL ){
		return LORAMESH_ERROR_NULLPOINTER;
	}

	tx_packet.header.dest_addr = dest_addr;
	tx_packet.header.src_addr = curr_address;
	tx_packet.header.type = LORAMESH_PTYPE_DATA;

	tx_packet.data_header.payload_len = data_len;
	tx_packet.data_header.pkt_num = tx_packet_cnt;
	tx_packet.data_header.status = 0;

	tx_packet.payload = pvPortMalloc( data_len );

	if( tx_packet.payload == NULL ){
		return LORAMESH_ERROR_NULLPOINTER;
	}

	for( i=0; i<data_len; i++){
		if( (( tx_packet.payload + i ) == NULL) || (data + i) == NULL ){
			vPortFree( tx_packet.payload );
			return 2;
		}
		*( tx_packet.payload + i ) = *( data + i );
	}
	loramesh_com_send( &tx_packet );
	vPortFree( tx_packet.payload );

	return LORAMESH_OK;
}

/*
 * See header file
 */
loramesh_errors_t loramesh_send_confirmation( 	uint16_t dest_addr,
												loramesh_conf_t conf )
{
	uint8_t tmp = conf;
	tx_packet.header.dest_addr = dest_addr;
	tx_packet.header.src_addr = curr_address;
	tx_packet.header.type = LORAMESH_PTYPE_CONF;
	tx_packet.payload[0] = tmp;
	loramesh_com_send( &tx_packet );
	return LORAMESH_OK;
}

/*
 * See header file
 */
loramesh_errors_t loramesh_send_beacon ( uint32_t systime, uint8_t forw_window,
										 uint8_t nhops, uint8_t subnet_id )
{
	tx_packet.header.dest_addr = LORAMESH_BROADCAST_ADDR0;
	tx_packet.header.src_addr = curr_address;
	tx_packet.header.type = LORAMESH_PTYPE_BEACON;
	tx_packet.payload = pvPortMalloc( LORAMESH_BEACON_PL_LEN );
	if( tx_packet.payload == NULL ){
		return LORAMESH_ERROR_NULLPOINTER;
	}
	tx_packet.payload[0] = B3_32TO8( systime );
	tx_packet.payload[1] = B2_32TO8( systime );
	tx_packet.payload[2] = B1_32TO8( systime );
	tx_packet.payload[3] = B0_32TO8( systime );
	tx_packet.payload[4] = forw_window;
	tx_packet.payload[5] = nhops;
	tx_packet.payload[6] = subnet_id;
	loramesh_com_send( &tx_packet );
	vPortFree( tx_packet.payload );
	return LORAMESH_OK;
}

/*
 * See header file
 */
loramesh_errors_t loramesh_send_join_response( 	uint16_t dest_addr,
												uint8_t confirmation,
												uint8_t forw_window,
												uint8_t slot_number_ul,
												uint8_t slot_number_dl,
												uint8_t slot_parent,
												uint8_t subslot)
{
	tx_packet.header.dest_addr = dest_addr;
	tx_packet.header.src_addr = curr_address;
	tx_packet.header.type = LORAMESH_PTYPE_JRES;
	tx_packet.payload = pvPortMalloc( LORAMESH_JRESP_PL_LEN );
	if( tx_packet.payload == NULL ){
		return LORAMESH_ERROR_NULLPOINTER;
	}
	tx_packet.payload[0] = confirmation;
	tx_packet.payload[1] = forw_window;
	tx_packet.payload[2] = slot_number_ul;
	tx_packet.payload[3] = slot_number_dl;
	tx_packet.payload[4] = slot_parent;
	tx_packet.payload[5] = subslot;
	loramesh_com_send( &tx_packet );
	vPortFree(tx_packet.payload);
	return LORAMESH_OK;
}

/*
 * See header file
 */
loramesh_errors_t loramesh_send_join_request(	uint16_t dest_addr )
{
	tx_packet.header.dest_addr = dest_addr;
	tx_packet.header.src_addr = curr_address;
	tx_packet.header.type = LORAMESH_PTYPE_JREQ;
	loramesh_com_send( &tx_packet );
	return LORAMESH_OK;
}

/*
 * See header file
 */
loramesh_errors_t loramesh_radio_stop( void )
{
	if( loramesh_com_set_sleep( ) != COM_OK ) {
		HAL_Delay( 2 );	// delay could be optimized
		return LORAMESH_ERROR;
	} else {
		return LORAMESH_OK;
	}
}

/*
 * See header file
 */
uint8_t loramesh_get_sf ( void )
{
	return loramesh_com_get_current_sf( );
}

/*
 * 	See header file
 */
uint32_t loramesh_get_toa_sync ( void )
{
	return loramesh_com_get_toa( LORAMESH_BEACON_PL_LEN + LORAMESH_HDDR_LEN );
}

/*
 * See header file
 */
uint32_t loramesh_get_toa_conf( void )
{
	return loramesh_com_get_toa( LORAMESH_CONF_PL_LEN + LORAMESH_HDDR_LEN );
}

/*
 * See header file
 */
uint32_t loramesh_get_toa_data( uint8_t payload_len )
{
	return loramesh_com_get_toa( LORAMESH_HDDR_LEN + LORAMESH_DHEADER_LEN + payload_len );
}

/* internal functions definitions ------------------------------------------ */

/**
 * 	\brief	reinitializes the communication layer
 */
static uint8_t loramesh_reinit ( void )
{
	if( loramesh_com_re_init( ) != COM_OK ) {
		return LORAMESH_ERROR;
	}
	return LORAMESH_OK;

}

/**
 * 	\brief deinitalizes the communication layer
 */
static uint8_t loramesh_deinit( void )
{
	if( loramesh_com_de_init( ) == COM_OK){
		return 0;
	} else {
		return 1;
	}
}

/**
 * 	\brief	defines lowerst possible lowpower mode
 * 			( used for le_handler)
 */
static lp_modes_t loramesh_get_lpmode( void )
{
	return STOP2_MODE;	//TODO: maybe other modes
}

/**
 *  \brief  Communication callback function (called by loramesh_com layer)
 */
void on_send_done ( loramesh_pkt_type_t last_pkttype )
{
	if( last_pkttype == LORAMESH_PTYPE_DATA ){
		if( tx_packet_cnt < UINT16_MAX ){
			tx_packet_cnt++;
		} else {
			tx_packet_cnt = 0;
		}
	}
	callbacks.cb_tx_done();
}

/**
 *  \brief  Communication callback function (called by loramesh_com layer)
 */
void on_send_timeout ( loramesh_pkt_type_t last_pkttype )
{
	callbacks.cb_tx_error();
}

/**
 *  \brief  Communication callback function (called by loramesh_com layer)
 */
void on_receive_done( loramesh_pkt_s *pkt, int16_t rssi, int8_t snr)
{
	switch( pkt->header.type) {
	case ( LORAMESH_PTYPE_BEACON ):
		sync_data.source_address = pkt->header.src_addr;
		sync_data.rssi = rssi;
		sync_data.utc_time  = (((uint32_t)*(pkt->payload)) << 24) & 0xFF000000;
		sync_data.utc_time |= (((uint32_t)*(pkt->payload + 1)) << 16) & 0x00FF0000;
		sync_data.utc_time |= (((uint32_t)*(pkt->payload + 2)) <<  8) & 0x0000FF00;
		sync_data.utc_time |= (((uint32_t)*(pkt->payload + 3))) & 0x000000FF;
		sync_data.fw_window =  *(pkt->payload + 4);
		sync_data.num_hops = *(pkt->payload + 5 );
		sync_data.subnet_id = *(pkt->payload + 6);
		callbacks.cb_beacon_received( &sync_data);
		break;
	case ( LORAMESH_PTYPE_DATA ):
		if( pkt->header.dest_addr == curr_address ) {
			rx_data.source_address = pkt->header.src_addr;
			rx_data.data_header.payload_len = pkt->data_header.payload_len;
			rx_data.data_header.pkt_num = pkt->data_header.pkt_num;
			rx_data.data_header.status = pkt->data_header.status;
			memcpy(	rx_data.data, pkt->payload, pkt->data_header.payload_len);
			callbacks.cb_rx_done( &rx_data);
		}
		break;
	case ( LORAMESH_PTYPE_JREQ ):
		if( pkt->header.dest_addr == curr_address ) {
			callbacks.cb_join_req_received( pkt->header.src_addr );
		}
		break;
	case ( LORAMESH_PTYPE_JRES ):
		if( pkt->header.dest_addr == curr_address ) {
			jresp_data.source_address = pkt->header.src_addr;
			jresp_data.confirmation = *(pkt->payload);
			jresp_data.forwarding_window = *(pkt->payload + 1);
			jresp_data.uplink_slot_nr = *(pkt->payload + 2);
			jresp_data.downlink_slot_nr = *(pkt->payload + 3);
			jresp_data.parent_slot = *(pkt->payload + 4);
			jresp_data.subslot_nr = *(pkt->payload + 5);
			callbacks.cb_join_resp_received( &jresp_data );
		}
		break;
	case ( LORAMESH_PTYPE_CONF ):
		if( pkt->header.dest_addr == curr_address ) {
			if( *pkt->payload == LORAMESH_ACK) {
				// TODO: check packet number
				callbacks.cb_confirmation_received( *(pkt->payload) );
			}
		}
		break;
	case ( LORAMESH_PTYPE_NEWNODE ):
			//TODO: handle newnod packet
			break;
	case( LORAMESH_PTYPE_RMNODE ):
			//TODO: handle removenode packet
			break;
	default:
		break;
	}
}

/**
 *  \brief  Communication callback function (called by loramesh_com layer)
 */
void on_receive_timeout( void )
{
	callbacks.cb_rx_error();
}

/**
 *  \brief  Communication callback function (called by loramesh_com layer)
 */
void on_receive_error( void )
{
	callbacks.cb_rx_error();
}

