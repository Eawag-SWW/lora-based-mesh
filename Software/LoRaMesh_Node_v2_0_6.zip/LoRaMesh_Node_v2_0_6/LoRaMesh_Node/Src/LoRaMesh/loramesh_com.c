/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		loramesh_com.c
 *
 * \description	LoRaMesh abstraction layer which handles communication with
 * 				the radio module
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "board.h"
#include "loramesh_com.h"
#include "loramesh.h"
#include "utilities.h"

/* -- makros ----------------------------------------------------------------*/
/** LoRa parameters used for LoRaMesh communication
 *  (for detailed description please refer to SX1276 datasheet)
 */

#define MODEM					MODEM_LORA	/** Modem type of radio
												MODEM_FSK:	FSK transmission
												MODEM_LORA:	LoRa transmission*/

#define DEFAULT_OUTPUT_POWER	14			/** Output power in dBm			 */
#define DEFAULT_BANDWIDTH		0     		/** Used bandwith
												0: 125 kHz,
												1: 250 kHz,
												2: 500 kHz,
												3: Reserved					 */
#define DEFAULT_SF				9/*10*/		/** Used LoRa spreading factor
												SF 7..10 are permitted		 */
#define DEFAULT_CR				1     		/** Used coding rate
												1: 4/5,
                                            	2: 4/6,
                                            	3: 4/7,
                                              	4: 4/8						 */

#define LORA_DEFAULT_CHANNEL	870000000	/** Used channel for LoRaMesh
												in Hz						 */

#define LORA_PREAM_LENGTH		8			/** Preamble length in symbols	 */
#define LORA_SYMB_TIMEOUT		5			/** Symbol timeout in symbols	 */
#define LORA_FIX_LENGTH_ON		false		/** Fixed or variable packets
												false: variable packets
												true:  fixed packet lengths	 */
#define LORA_CRC_ON				true		/** CRC on/off
												true: CRC is ON
												false: CRC is OFF			 */
#define LORA_IQ_INVERSION_ON	false		/** LoRa IQ-Inversion
												false: IQ not inverted
												true: IQ inverted			 */
#define LORA_FH_ON				false		/** LoRa frequency hop
												false: freq. hopping disabled
												true: freq. hopping enabled	 */
#define LORA_FH_PERIOD			0			/** frequency hopping period	 */
#define LORA_TX_TIMEOUT			3000		/** Lora tx timeout				 */
// TODO: define TX timeout
#define LORA_BW_AFC				0			/** LoRa automatic frequency
												correction					 */
#define LORA_RX_CONT_ON			true		/** RX continous / RX single
												true: RX continous
												fals: RX single				 */

//** Used timeouts by loramesh_com layer softare							 */
#define DEFAULT_TX_TIMEOUT		1000		/** default TX timeout in ms	 */
#define DEFAULT_RX_TIMEOUT		3000		/** default RX timeout in ms     */

#if DEFAULT_SF > 10
#error Use spreading factors from 7 to 10 to ensure communication with 1s slots
#endif

/* -- type definitions-------------------------------------------------------*/
typedef enum { UP_TO_DATE = 0,	/*< parameters are up to date				 */
			   CHANGED = 1		/*< parameters have changed since last rx/tx */
}param_stt_t;

/* internal function declarations ------------------------------------------ */
static void on_tx_done ( void );
static void on_tx_timeout ( void );
static void on_rx_done ( uint8_t *payload, uint16_t size,
							int16_t rssi, int8_t snr);
static void on_rx_timeout ( void );
static void on_rx_error ( void );
static void on_fhss_change_channel ( uint8_t currentChannel  );
static void on_cad_done ( bool channelActivityDetected );
static loramesh_com_errors_t set_tx_config ( void );
static loramesh_com_errors_t set_rx_config ( void );
static uint8_t packet2string ( uint8_t *buffer, loramesh_pkt_s *packet);
static uint8_t string2packet ( loramesh_pkt_s *packet, uint8_t *buffer);
static uint8_t get_payload_len_on_ptye( loramesh_pkt_type_t type );

/* internal variable definitions ------------------------------------------- */ 
static 	RadioEvents_t RadioEvents;			/** stores events from radio	 */
static  lora_params_t lora_tx_parameter;	/** stores current tx parameters */
static  lora_params_t lora_rx_parameter;	/** stores current rx parameters */
/** stores callback functions for forwarding events to upper layer			 */
static  loramesh_com_callbacks_t callbacks;
/** flags indicate if parameters have changed or not						 */
static volatile param_stt_t tx_param_changed = CHANGED;
static volatile param_stt_t rx_param_changed = CHANGED;
static uint8_t tx_buffer[LORA_MAX_PKT_LENGTH];  /**< tx buffer				 */
static loramesh_pkt_type_t latest_ptype = 0xFF;
static uint8_t rx_payload_buff[255];	/** rx buffer					     */

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
loramesh_com_errors_t loramesh_com_init ( loramesh_com_callbacks_t *cb)
{
	if( cb == NULL) {
		return COM_ERROR_NULLPOINTER;
	}
	callbacks.receive_done = cb->receive_done;
	callbacks.receive_error = cb->receive_error;
	callbacks.receive_timeout = cb->receive_timeout;
	callbacks.send_done = cb->send_done;
	callbacks.send_timeout = cb->send_timeout;
	RadioEvents.TxDone = on_tx_done;
	RadioEvents.TxTimeout = on_tx_timeout;
	RadioEvents.RxDone = on_rx_done;
	RadioEvents.RxTimeout = on_rx_timeout;
	RadioEvents.RxError = on_rx_error;
	RadioEvents.FhssChangeChannel = on_fhss_change_channel;
	RadioEvents.CadDone = on_cad_done;
	Radio.Init( &RadioEvents );

	lora_tx_parameter.lora_channel = LORA_DEFAULT_CHANNEL;
	lora_tx_parameter.lora_output_power = DEFAULT_OUTPUT_POWER;
	lora_tx_parameter.lora_bandwidth = DEFAULT_BANDWIDTH;
	lora_tx_parameter.lora_coding_rate = DEFAULT_CR;
	lora_tx_parameter.lora_spreading_factor = DEFAULT_SF;
	lora_tx_parameter.lora_timeout = DEFAULT_TX_TIMEOUT;

	lora_rx_parameter.lora_channel = LORA_DEFAULT_CHANNEL;
	lora_rx_parameter.lora_output_power = 0;				// not used in RX
	lora_rx_parameter.lora_bandwidth = DEFAULT_BANDWIDTH;
	lora_rx_parameter.lora_coding_rate = DEFAULT_CR;
	lora_rx_parameter.lora_spreading_factor = DEFAULT_SF;
	lora_rx_parameter.lora_timeout = DEFAULT_RX_TIMEOUT;

	Radio.SetChannel( LORA_DEFAULT_CHANNEL );
	set_tx_config( );
	set_rx_config( );

	Radio.Sleep();
	return COM_OK;
}

/*
 * See header file
 */
loramesh_com_errors_t loramesh_com_send ( loramesh_pkt_s *packet)
{
	uint8_t len = 0;
	if( packet == NULL ){
		return LORAMESH_ERROR_NULLPOINTER;
	}

	if( (len = packet2string( tx_buffer, packet )) == 0 ){
		// TODO: Error handling
		return COM_ERROR_LEN_ERROR;
	}
	Radio.Send( tx_buffer, len);
	latest_ptype = packet->header.type;

	return LORAMESH_OK;
}

/*
 * See header file
 */
loramesh_com_errors_t loramesh_com_receive ( void )
{
	Radio.Rx( 0 );
	return COM_OK;
}

/*
 * See header file
 */
loramesh_com_errors_t loramesh_com_set_sleep( void )
{
	// TODO: check radio state
	Radio.Sleep( );
	return COM_OK;
}

/*
 * See header file
 */
loramesh_com_errors_t loramesh_com_set_tx_params (lora_params_t *params)
{
	if( Radio.GetStatus() != RF_IDLE){
		return COM_ERROR_BUSY;
	}
	uint8_t changed = 0;
	if(lora_tx_parameter.lora_channel != params->lora_channel){
		lora_tx_parameter.lora_channel = params->lora_channel;
		changed = 1;
	}
	if(lora_tx_parameter.lora_bandwidth != params->lora_bandwidth) {
		lora_tx_parameter.lora_bandwidth = params->lora_bandwidth;
		changed = 1;
	}
	if(lora_tx_parameter.lora_coding_rate != params->lora_coding_rate) {
		lora_tx_parameter.lora_coding_rate = params->lora_coding_rate;
		changed = 1;
	}
	if(lora_tx_parameter.lora_output_power != params->lora_output_power) {
		lora_tx_parameter.lora_output_power = params->lora_output_power;
		changed = 1;
	}
	if(lora_tx_parameter.lora_spreading_factor != params->lora_spreading_factor){
		lora_tx_parameter.lora_spreading_factor = params->lora_spreading_factor;
		changed = 1;
	}
	if(lora_tx_parameter.lora_timeout != params->lora_timeout) {
		lora_tx_parameter.lora_timeout = params->lora_timeout;
		changed = 1;
	}
	if( changed ) {
		tx_param_changed = CHANGED;
		//set_tx_config( &lora_tx_parameter);
	}
	return COM_OK;
}

/*
 * See header file
 */
loramesh_com_errors_t loramesh_com_set_rx_params (lora_params_t *params)
{
	if( Radio.GetStatus() != RF_IDLE){
		return COM_ERROR_BUSY;
	}
	uint8_t changed = 0;
	if(lora_rx_parameter.lora_channel != params->lora_channel){
		lora_rx_parameter.lora_channel = params->lora_channel;
		changed = 1;
	}
	if(lora_rx_parameter.lora_bandwidth != params->lora_bandwidth) {
		lora_rx_parameter.lora_bandwidth = params->lora_bandwidth;
		changed = 1;
	}
	if(lora_rx_parameter.lora_coding_rate != params->lora_coding_rate) {
		lora_rx_parameter.lora_coding_rate = params->lora_coding_rate;
		changed = 1;
	}
//	if(act->lora_output_power != new->lora_output_power) {
//		act->lora_output_power = new->lora_output_power;
//		changed = 1;
//	}
	if(lora_rx_parameter.lora_spreading_factor != params->lora_spreading_factor){
		lora_rx_parameter.lora_spreading_factor = params->lora_spreading_factor;
		changed = 1;
	}
//	if(act->lora_timeout != new->lora_timeout) {
//		act->lora_timeout = new->lora_timeout;
//		changed = 1;
//	}
	if( changed ) {
		rx_param_changed = CHANGED;
		//set_rx_config( &lora_rx_parameter);
	}
	return COM_OK;
}

/*
 * See header file
 */
loramesh_com_errors_t loramesh_com_de_init( void )
{
	Radio.DeInit();
	return COM_OK;
}

/*
 * See header file
 */
loramesh_com_errors_t loramesh_com_re_init ( void )
{
	Radio.Init( &RadioEvents );
	Radio.SetChannel( LORA_DEFAULT_CHANNEL );
	tx_param_changed = CHANGED;
	rx_param_changed = CHANGED;
	set_tx_config( );
	set_rx_config( );
	Radio.Sleep();
	return COM_OK;
}

/*
 * See header file
 */
uint8_t loramesh_com_get_current_sf( void )
{
	return (uint8_t)DEFAULT_SF;
}

/*
 * See header file
 */
uint32_t loramesh_com_get_toa( uint8_t len )
{
	return Radio.TimeOnAir( MODEM_LORA, len  );
}

/* internal functions definitions ------------------------------------------ */

/**
 * 	\brief	Writes tx configuration to the radio module
 * 	\return	error code
 */
static loramesh_com_errors_t set_tx_config ( void )
{
	if(tx_param_changed != UP_TO_DATE) {
		Radio.SetChannel (lora_tx_parameter.lora_channel);
		Radio.SetTxConfig (	MODEM, lora_tx_parameter.lora_output_power, 0,
							lora_tx_parameter.lora_bandwidth,
							lora_tx_parameter.lora_spreading_factor,
							lora_tx_parameter.lora_coding_rate,
							LORA_PREAM_LENGTH,
							LORA_FIX_LENGTH_ON, LORA_CRC_ON, LORA_FH_ON,
							LORA_FH_PERIOD, LORA_IQ_INVERSION_ON,
							lora_tx_parameter.lora_timeout);
		tx_param_changed = UP_TO_DATE;
	}
	return COM_OK;
}

/**
 * 	\brief	Writes rx configuration to the radio module
 * 	\return	error code
 */
static loramesh_com_errors_t set_rx_config ( void )
{
	if(rx_param_changed != UP_TO_DATE){
		Radio.SetChannel( lora_rx_parameter.lora_channel);
		Radio.SetRxConfig ( MODEM, lora_rx_parameter.lora_bandwidth,
							lora_rx_parameter.lora_spreading_factor,
							lora_rx_parameter.lora_coding_rate,
							LORA_BW_AFC, LORA_PREAM_LENGTH, LORA_SYMB_TIMEOUT,
							LORA_FIX_LENGTH_ON, 0, LORA_CRC_ON, LORA_FH_ON,
							LORA_FH_PERIOD, LORA_IQ_INVERSION_ON, LORA_RX_CONT_ON);
	rx_param_changed = UP_TO_DATE;
	}
	return COM_OK;
}

/**
 *  \brief  Converts a packet struct into a string buffer
 *  \param	*buffer: 	pointer to buffer to store string
 *  \param  *packet:	pointer to packet which will be converted
 *  \return		returns the length of the generated string
 *  				0 -> error
 */
static uint8_t packet2string ( uint8_t *buffer, loramesh_pkt_s *packet)
{
	uint8_t i = 0;
	uint8_t rm_len = 0;
	uint8_t pl_len = 0;
	uint8_t tot_len = 0;

	if( buffer == NULL) {
		return 0;
	}
	if ( packet == NULL) {
		return 0;
	}

	// LoRaMesh header
	*(buffer + 0) = B1_16TO8(packet->header.dest_addr); 	//(uint8_t)((packet->dest_addr >> 8) & 0xFF);
	*(buffer + 1) = B0_16TO8(packet->header.dest_addr);	//(uint8_t)((packet->dest_addr) & 0xFF);
	*(buffer + 2) = B1_16TO8(packet->header.src_addr); 	//(uint8_t)((packet->src_addr >> 8) & 0xFF);
	*(buffer + 3) = B0_16TO8(packet->header.src_addr);		//(uint8_t)((packet->src_addr) & 0xFF);
	*(buffer + 4) = packet->header.type;


	switch( packet->header.type ){
	case( LORAMESH_PTYPE_DATA ):
		if( packet->payload == NULL){
			return 0;
		}
		tot_len = packet->data_header.payload_len + LORAMESH_HDDR_LEN + LORAMESH_DHEADER_LEN;
		if( tot_len > LORAMESH_MAX_PL ){
			return 0;
		}

		*(buffer + LORAMESH_HDDR_LEN + 0 ) = packet->data_header.payload_len;
		*(buffer + LORAMESH_HDDR_LEN + 1 ) = B1_16TO8(packet->data_header.pkt_num);
		*(buffer + LORAMESH_HDDR_LEN + 2 ) = B0_16TO8(packet->data_header.pkt_num);
		*(buffer + LORAMESH_HDDR_LEN + 3 ) = packet->data_header.status;

		for(i=0; i<packet->data_header.payload_len; i++){
			*(buffer + LORAMESH_HDDR_LEN + LORAMESH_DHEADER_LEN + i) = *(packet->payload + i);
		}
		break;
	case( LORAMESH_PTYPE_RMNODE ):
		if( packet->payload == NULL){
			return 0;
		}
		rm_len = 2*packet->rm_header.num_nodes;
		tot_len = LORAMESH_HDDR_LEN + 1 + rm_len;
		if( tot_len > LORAMESH_MAX_PL ){
			return 0;
		}

		*( buffer + LORAMESH_HDDR_LEN + 0 ) = packet->rm_header.num_nodes;
		for(i=0; i<rm_len; i++){
			*( buffer + LORAMESH_HDDR_LEN + 1 + i) = *(packet->payload + i);
		}
		break;
	default:
		pl_len = get_payload_len_on_ptye( packet->header.type );
		if( pl_len > 0 ){
			if( packet->payload == NULL){
				return 0;
			}
		}
		tot_len = pl_len + LORAMESH_HDDR_LEN;
		if( tot_len > LORAMESH_MAX_PL ){
			return 0;
		}
		for(i=0; i<pl_len; i++){
			*(buffer + LORAMESH_HDDR_LEN + i) = *(packet->payload + i);
		}
		break;
	}
	return tot_len;
}

/**
 *  \brief  Convert a datastring into a packet buffer
 *  \param	*packet:	pointer to packet buffer
 *  \param  *buffer:	pointer to data stream to be converted
 *  \return	returns 0 on success, nonzero on error
 */
static uint8_t string2packet ( loramesh_pkt_s *packet, uint8_t *buffer)
{
	//TODO: actualize function
	uint8_t i = 0;
	uint8_t pllen = 0;
	uint8_t ret = 0;
	uint8_t rmlen;

	if( buffer == NULL) {
		return 1;
	}
	if ( packet == NULL) {
		return 1;
	}

	if( packet->payload == NULL ){
		return 1;
	}
	// LoRaMesh header
	packet->header.dest_addr  = (((uint16_t) *buffer) << 8) & 0xFF00;
	packet->header.dest_addr |= (((uint16_t) *(buffer +  1)) & 0x00FF);
	packet->header.src_addr  = (((uint16_t) *(buffer + 2)) << 8) & 0xFF00;
	packet->header.src_addr |= ((uint16_t) *(buffer +  3)) & 0x00FF;
	packet->header.type = *(buffer + 4);

	switch( packet->header.type ){
	case (LORAMESH_PTYPE_DATA ):
		packet->data_header.payload_len = *(buffer + LORAMESH_HDDR_LEN);
		packet->data_header.pkt_num = convert_to_uint16( buffer + LORAMESH_HDDR_LEN + 1);
//		packet->data_header.pkt_num = (((uint16_t) *(buffer + LORAMESH_HDDR_LEN + 1)) << 8) & 0xFF00;
//		packet->data_header.pkt_num |= (((uint16_t) *(buffer + LORAMESH_HDDR_LEN + 2)) & 0xFF00);
		packet->data_header.status = *(buffer + LORAMESH_HDDR_LEN + 3);
		for( i=0; i<packet->data_header.payload_len; i++){
			*(packet->payload + i) = *(buffer + LORAMESH_HDDR_LEN + LORAMESH_DHEADER_LEN + i);
		}
		break;
	case( LORAMESH_PTYPE_RMNODE ):
		packet->rm_header.num_nodes = *(buffer + LORAMESH_HDDR_LEN );
		rmlen = packet->rm_header.num_nodes * 2;
		for( i=0; i<rmlen; i++){
			*(packet->payload + i) = *(buffer + LORAMESH_HDDR_LEN + 1 + i);
		}
		break;
	default:
		pllen = get_payload_len_on_ptye( packet->header.type );
		for( i=0; i<pllen; i++ ){
			*(packet->payload + i) = *(buffer + LORAMESH_HDDR_LEN + i );
		}
		break;
	}
	return ret;
}

/**
 * 	\brief 	Gets payload length based on packet type
 * 	\return	Returns packet length when packet type implies a fixed length
 * 			returns 0 when packet type is variable (e.g. data)
 */
static uint8_t get_payload_len_on_ptye( loramesh_pkt_type_t type )
{
	uint8_t len = 0;
	switch( type ){
	case( LORAMESH_PTYPE_BEACON ):
		len = LORAMESH_BEACON_PL_LEN;
			break;
	case( LORAMESH_PTYPE_CONF ):
		len = LORAMESH_CONF_PL_LEN;
			break;
	case( LORAMESH_PTYPE_DATA ):
		len = 0;
			break;
	case( LORAMESH_PTYPE_JREQ ):
		len = LORAMESH_JREQ_PL_LEN;
			break;
	case( LORAMESH_PTYPE_JRES ):
		len = LORAMESH_JRESP_PL_LEN;
			break;
	case( LORAMESH_PTYPE_NEWNODE ):
		len = LORAMESH_NEWNODE_PL_LEN;
			break;
	case( LORAMESH_PTYPE_RMNODE ):
		len = 0;
			break;
	default:
		len = 0;
		break;
	}
	return len;
}


/**
 *  \brief  Callback function for tx done
 */
static void on_tx_done ( void )
{
	Radio.Sleep();
	callbacks.send_done ( latest_ptype );
}

/**
 *  \brief  Callback function for tx timeout
 */
static void on_tx_timeout ( void )
{
	Radio.Sleep();
	callbacks.send_timeout( latest_ptype );
}

/**
 *  \brief  Callback function for rx done
 */
static void on_rx_done ( uint8_t *payload, uint16_t size,
							int16_t rssi, int8_t snr)
{
	loramesh_pkt_s pkt;
	pkt.payload = rx_payload_buff;
	if( string2packet( &pkt, payload ) == 0){
		Radio.Sleep();
		Radio.Rx( 0 );
		callbacks.receive_done( &pkt, rssi, snr);
	} else {
		Radio.Sleep();
		callbacks.receive_error();
	}
}

/**
 *  \brief  Callback function for rx timeout
 */
static void on_rx_timeout ( void )
{
	Radio.Sleep();
	callbacks.receive_timeout();
}

/**
 *  \brief  Callback function for rx error
 */
static void on_rx_error ( void )
{
	Radio.Sleep();
	callbacks.receive_error();
}

/**
 *  \brief  Callback function when fhss changed channel
 */
static void on_fhss_change_channel ( uint8_t currentChannel  )
{
	//TODO: implement
	Radio.Sleep();
}

/**
 *  \brief  Callback function for cad done
 */
static void on_cad_done ( bool channelActivityDectected )
{
	//TODO: implement
	Radio.Sleep();
}

