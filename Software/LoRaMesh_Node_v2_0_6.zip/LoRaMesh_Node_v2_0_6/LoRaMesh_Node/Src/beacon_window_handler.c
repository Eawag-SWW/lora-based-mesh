/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		beacon_handler.c
 *
 * \description	This module handles beacon windows for each device
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		18.09.2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "beacon_window_handler.h"
#include "stdlib.h"
#include "string.h"
#include "cmsis_os.h"
/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/
typedef enum{
				WINDOW_FREE = 0,
				WINDOW_USED = 1
}bw_states_t;

typedef struct beacon_window {
		bw_states_t state;
		uint16_t node_address;
} beacon_window_s;

/* internal function declarations ------------------------------------------ */

 
/* internal variable definitions ------------------------------------------- */ 
static beacon_window_s *windows;
static uint8_t num_windows;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint8_t beacon_window_handler_init( uint8_t n_windows )
{
	uint8_t i;
	if( n_windows <= 0 ){
		return 1;
	}

	windows = pvPortMalloc( n_windows * sizeof(beacon_window_s));
	if( windows == NULL ){
		num_windows = 0;
		return 2;
	}
	num_windows = n_windows;
	for(i=0; i<num_windows; i++){
		windows[i].node_address = 0x00;
		windows[i].state = WINDOW_FREE;
	}
	return 0;
}

/*
 * See header file
 */
uint8_t beacon_window_handler_register_window(	uint8_t win_number,
												uint16_t node_addr)
{
	if( windows == NULL ) {
		return 1;
	}
	if( windows[win_number].state != WINDOW_FREE ){
		return 1;	// window already used
	} else {
		windows[win_number].state = WINDOW_USED;
		windows[win_number].node_address = node_addr;
	}
	return 0;
}

/*
 * 	See header file
 */
uint8_t beacon_window_get_reg_free_window( uint16_t node_addr)
{
	uint8_t i = 0;
	if(windows == NULL){
		return 0xFF;
	}
	for(i=0; i<num_windows; i++){
		if(windows[i].state == WINDOW_FREE){
			windows[i].state = WINDOW_USED;
			windows[i].node_address = node_addr;
			return i;
		}
	}
	return 0xFF;
}

/*
 * 	See header file
 */
uint8_t beacon_window_deregister( uint16_t node_addr )
{
	uint8_t i = 0;
	for(i=0; i<num_windows; i++){
		if( windows[i].node_address == node_addr){
			windows[i].node_address = 0x0000;
			windows[i].state = WINDOW_FREE;
			return 0;
		}
	}
	return 1;
}

/* internal functions definitions ------------------------------------------ */



