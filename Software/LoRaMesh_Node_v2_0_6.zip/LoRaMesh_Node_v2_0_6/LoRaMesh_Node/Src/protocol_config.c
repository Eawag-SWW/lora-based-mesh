/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		protocol_config.c
 *
 * \description	Configuration of the whole network by defining parameters
 * 				in the ptkSetConfigXXXSetup functions
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "protocol_config.h"
#include "utilities.h"
#include "protocol_core.h"

/* -- makros ----------------------------------------------------------------*/
#define PTK_SLOTPART_APPROVE 0
#define PTK_SLOTPART_DOWNS 1
#define PTK_SLOTPART_UPS 2

/* -- type definitions-------------------------------------------------------*/

/* internal function declarations ------------------------------------------ */
static uint8_t ptkSetConfigTestSetup( void );
static uint8_t ptkCheckConfig( void );

/* internal variable definitions ------------------------------------------- */ 
static TPtkConfig ptkConfig;
static uint16_t fw_duration_LUT[4] = {58, 103, 171, 329};
static uint32_t jreq_timout_LUT[4] = {1000, 1000, 1000, 1000};	//TODO: evaluate timeouts
static uint32_t ack_timeout_LUT[4] = { 200,  200,  200,  300};
static uint32_t beacon_timeout_LUT[4] = {500, 500, 500,  500};
static uint16_t offset_rx_sync = 10;
static uint8_t sf;	// buffer to store current used spreading factor

/* public function definitions --------------------------------------------- */

/*
 *	See header file
 */
uint8_t ptk_set_config( ptk_modes_t mode )
{
	switch ( mode ) {
	case ( PTK_MODE_TEST ):
		return ptkSetConfigTestSetup( );
		break;
	case ( PTK_MODE_NORMAL ):
		return 1;
		break;
	default:
		return 1;
		break;
	}
}

/*
 * 	See header file
 */
uint16_t ptk_get_slot_duration_ms( void )
{
	return ptkConfig.slot_duration_ms;
}

/*
 * 	See header file
 */
uint32_t ptk_get_cycle_duration_s( void )
{
	return ptkConfig.cycle_duration_s;
}

/*
 *	See header file
 */
uint16_t ptk_get_nsync ( void )
{
	return ptkConfig.N_sync_slots;
}

/*
 * 	See header file
 */
uint16_t ptk_get_njoin ( void )
{
	return ptkConfig.N_jreq_slots;
}

/*
 * 	See header file
 */
uint16_t ptk_get_napprove ( void )
{
	return ptkConfig.N_approve_slots;
}

/*
 * 	See header file
 */
uint16_t ptk_get_nuplink ( void )
{
	return ptkConfig.N_uplink_slots;
}

/*
 * 	See header file
 */
uint16_t ptk_get_ndownlink( void )
{
	return ptkConfig.N_downlink_slots;
}

/*
 *	See header file
 */
uint8_t ptk_get_num_network_nodes ( void )
{
	return ptkConfig.max_netw_nodes;
}

/*
 *	See header file
 */
uint16_t ptk_get_fw_duration_ms( void )
{
	return ptkConfig.fw_duration_ms;
}

/*
 *	See header file
 */
uint16_t ptk_get_subslot_duration_ms( void )
{
	return ptkConfig.subslot_duration_ms;
}

/*
 *	See header file
 */
uint8_t ptk_get_max_ul_timeouts( void )
{
	return ptkConfig.max_ul_timeout;
}

/*
 *	See header file
 */
uint8_t ptk_get_max_join_timeouts( void )
{
	return ptkConfig.max_join_timeout;
}

/*
 * 	See header file
 */
uint16_t ptk_get_sync_rx_offset( void )
{
	return offset_rx_sync;
}

/*
 * 	See header file
 */
uint32_t ptk_get_jreq_timeout( void )
{
	return jreq_timout_LUT[sf - 7];
}

/*
 * 	See header file
 */
uint32_t ptk_get_ack_timeout( void )
{
	return ack_timeout_LUT[sf - 7];
}

/*
 * 	See header file
 */
uint32_t ptk_get_beacon_timeout( void )
{
	return beacon_timeout_LUT[sf - 7];
}

/* internal functions definitions ------------------------------------------ */

/*
 * 	\brief	Sets configuration to test setup
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t ptkSetConfigTestSetup( void )
{
	ptkConfig.slot_duration_ms = 2000;//3500;
	ptkConfig.subslot_duration_ms = 400;//700; //TODO: Set correct value

	ptkConfig.max_ul_timeout = 2;
	ptkConfig.max_join_timeout = 5;

	ptkConfig.N_sync_slots = 1;
	ptkConfig.N_jreq_slots = 1;
	ptkConfig.N_approve_slots = 1;
	ptkConfig.N_uplink_slots = 5;
	ptkConfig.N_downlink_slots = 5;
	ptkConfig.N_wan_slots = 2;
	ptkConfig.N_guard_slots = 135;
	//ptkConfig.N_guard_slots = 10;

	ptkConfig.max_netw_nodes = 5;

	ptkConfig.N_cycle =	ptkConfig.N_sync_slots + ptkConfig.N_jreq_slots +
						ptkConfig.N_approve_slots + ptkConfig.N_uplink_slots +
						ptkConfig.N_downlink_slots + ptkConfig.N_wan_slots +
						ptkConfig.N_guard_slots;
	ptkConfig.cycle_duration_s = ptkConfig.slot_duration_ms * ptkConfig.N_cycle;
	ptkConfig.cycle_duration_s = ptkConfig.cycle_duration_s / 1000;

	sf = loramesh_get_sf();
	if( sf<7 || sf>10 ){
		return 1;
	}

	ptkConfig.fw_duration_ms = fw_duration_LUT[sf - 7];

	return ptkCheckConfig( );
}

/**
 * 	\brief	Checks current setup
 * 	\return	returns 0 if setup is correct, nonzero otherwise
 */
static uint8_t ptkCheckConfig( void )
{
	if( ptkConfig.N_uplink_slots < ptkConfig.max_netw_nodes ) {
		return 2;
	}
	if( ptkConfig.N_downlink_slots < ptkConfig.max_netw_nodes ) {
		return 3;
	}
	return 0;
}




