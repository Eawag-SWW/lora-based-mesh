/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		log.c
 *
 * \description	Implementation of logging interface(es) for the current project
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		26.01.2018
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/

#include "power_switches/power_switches.h"
#include <log/log.h>
#include "utilities.h"
#include <mcu_pinout.h>
#include "rtc.h"
#include "device_config.h"
#include "sensors.h"
#include "string.h"
#include "delay_us.h"
/* -- makros ----------------------------------------------------------------*/
#define STRING_BUFFER_SIZE 64
/* -- type definitions-------------------------------------------------------*/

/* internal function declarations ------------------------------------------ */

/* internal variable definitions ------------------------------------------- */

FATFS sdCardFatFs;
FIL debugLogFile;
FIL sensorLogFile;
char logFilePath[4];
char debugLogFileName[] = "dbgLog.csv";
char sensorLogFileName[] = "sensLog.csv";

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
FRESULT log_status(void) {
	FRESULT res = FR_NOT_ENABLED;

#if SD_LOG != SD_LOG_NONE
	FILINFO fno;
	if (log_init() == FR_OK) {

#if SD_LOG & SD_LOG_DBG
		res = f_stat((TCHAR const*) debugLogFileName, &fno);
		if (res == FR_NO_FILE) {
			// Create or open file if it exists
			res = f_open(&debugLogFile, (TCHAR const*) debugLogFileName,
			FA_OPEN_APPEND | FA_WRITE);
			if (res != FR_OK) {
				return res;
			}

			// Close file
			res = f_close(&debugLogFile);
			if (res != FR_OK) {
				return res;
			}
		}
#endif

#if SD_LOG & SD_LOG_SENS
		res = f_stat((TCHAR const*) sensorLogFileName, &fno);
		if (res == FR_NO_FILE) {
			// Create or open file if it exists
			res = f_open(&sensorLogFile, (TCHAR const*) sensorLogFileName,
			FA_OPEN_APPEND | FA_WRITE);
			if (res != FR_OK) {
				return res;
			}

			// Close file
			res = f_close(&sensorLogFile);
			if (res != FR_OK) {
				return res;
			}
		}

#endif
	}
	log_deinit();

#endif
	return res;

}

/*
 * See header file
 */
FRESULT log_init(void) {
	FRESULT res;

// Init code for fatfs
	MX_FATFS_Init(); // TODO: does nothing at the moment

	power_switch_control(PS_SDCARD, PS_ON);
	//osDelay(100); // TODO: how long?
	DELAY_Init();
	Delay(100000);
	DELAY_DeInit();

// Try to mount sdcard
	res = f_mount(&sdCardFatFs, (TCHAR const*) logFilePath, 0);

	return res;
}

/*
 * See header file
 */
void log_deinit(void) {
	f_unmount((TCHAR const*) logFilePath);
	power_switch_control(PS_SDCARD, PS_OFF);
}

/*
 * See header file
 */
FRESULT debug_log_open(void) {
	FRESULT res = FR_NOT_ENABLED;

	res = f_open(&debugLogFile, (TCHAR const*) debugLogFileName,
	FA_OPEN_APPEND | FA_WRITE);

	return res;
}

/*
 * See header file
 */
FRESULT debug_log_close(void) {
	FRESULT res = FR_NOT_ENABLED;

	res = f_close(&debugLogFile);

	return res;
}

/*
 * See header file
 */
FRESULT debug_log_append(const TCHAR* str, ...) {
	va_list args;
	struct tm *time_s;
	rtc_utc_t rtc_utc_time;
	uint16_t rtc_ms;
	char dest[STRING_BUFFER_SIZE];

	// Print timestamp
	rtc_get_time_date(&rtc_utc_time, &rtc_ms);
	time_s = gmtime(&rtc_utc_time);
	if (f_printf(&debugLogFile, "%02u.%02u.%04u %02u:%02u:%02u;",
			time_s->tm_mday, time_s->tm_mon + 1, time_s->tm_year - 100 + 2000,
			time_s->tm_hour, time_s->tm_min, time_s->tm_sec) == -1) {
		return FR_DISK_ERR;
	}

	// Print string with arguments
	va_start(args, str);
	vsprintf(dest, str, args);
	va_end(args);
	if (f_printf(&debugLogFile, dest) == -1) {
		return FR_DISK_ERR;
	}

	return FR_OK;

}

// TODO: measure time needed to complete this function
/*
 * See header file
 */
FRESULT debug_log_append_line(const TCHAR* str, ...) {
	FRESULT res = FR_NOT_ENABLED;
#if SD_LOG & SD_LOG_DBG
	va_list args;
	char dest[STRING_BUFFER_SIZE];

	if (log_init() == FR_OK) {

		// Create or open file if it exists
		res = debug_log_open();
		if (res == FR_OK) {

			va_start(args, str);
			vsprintf(dest, str, args);
			va_end(args);

			// Append string
			debug_log_append(dest);

			// Close file
			res = debug_log_close();
		}
	}

	log_deinit();
#endif
	return res;
}

/*
 * See header file
 */
FRESULT debug_log_device_configuration(void) {
	FRESULT res = FR_NOT_ENABLED;
#if SD_LOG & SD_LOG_DBG

	if (log_init() == FR_OK) {

		// Create or open file if it exists
		res = debug_log_open();
		if (res == FR_OK) {

			// Append strings
			debug_log_append("Device configuration:\n");

			char str_code_version[64];
			strcpy(str_code_version, "- CODE_VERSION: ");
			strcat(str_code_version, CODE_VERSION);
			strcat(str_code_version, "\n");
			debug_log_append(str_code_version);

#ifdef DEV_IS_NODE
			debug_log_append("- DEVICE_TYPE: NODE\n");
#endif
#ifdef DEV_IS_REPEATER
			debug_log_append("- DEVICE_TYPE: REPEATER\n");
#endif

			debug_log_append("- DEVICE_ADDR_LORAMESH: 0x%04X \n",
			DEVICE_ADDR_LORAMESH);

			if (SENSOR_TYPE == NO_SENSOR) {
				debug_log_append("- SENSOR_TYPE: NO_SENSOR\n");
			} else if (SENSOR_TYPE == MB7389) {
				debug_log_append("- SENSOR_TYPE: MB7389\n");
			} else if (SENSOR_TYPE == MB7369) {
				debug_log_append("- SENSOR_TYPE: MB7369\n");
			} else if (SENSOR_TYPE == DS18B20) {
				debug_log_append("- SENSOR_TYPE: DS18B20\n");
			}

#if USE_DBG_IN_STOPMODE == 0
			debug_log_append("- USE_DBG_IN_STOPMODE: 0\n");
#else
			debug_log_append( "- USE_DBG_IN_STOPMODE: 1\n");
#endif

#if SD_LOG == SD_LOG_NONE
			debug_log_append( "- SD_LOG: NONE\n");
#elif SD_LOG == SD_LOG_SENS
			debug_log_append( "- SD_LOG: SD_LOG_SENS\n");
#elif SD_LOG == SD_LOG_DBG
			debug_log_append("- SD_LOG: SD_LOG_DBG\n");
#elif SD_LOG == SD_LOG_SENS_DBG
			debug_log_append("- SD_LOG: SD_LOG_SENS_DBG\n");
#endif

#if USE_LORAWAN == 0
			debug_log_append("- USE_LORAWAN: 0\n");
#else
			debug_log_append("- USE_LORAWAN: 1\n");
#endif

#if LORAWAN_PARAM == LORAWAN_PARAM_EAWAG
			debug_log_append("- LORAWAN_PARAM: EAWAG\n");
#elif LORAWAN_PARAM == LORAWAN_PARAM_INES
			debug_log_append( "- LORAWAN_PARAM: INES\n");
#endif

#if USE_LOWPOWER == 0
			debug_log_append( "- USE_LOWPOWER: 0\n");
#else
			debug_log_append("- USE_LOWPOWER: 1\n");
#endif

#if TIMESOURCE == TIMESOURCE_NONE
			debug_log_append("- TimesTIMESOURCEource: NONE\n");
#elif TIMESOURCE == TIMESOURCE_GPS
			debug_log_append("- TIMESOURCE: GPS\n");
#elif TIMESOURCE == TIMESOURCE_DCF77
			debug_log_append( "- TIMESOURCE: DCF77\n");
#endif

#if SETUP_TESTBENCH == 0
			debug_log_append("- SETUP_TESTBENCH: 0\n");
#else
			debug_log_append( "- SETUP_TESTBENCH: 1\n");
#endif

#if NETWORK_MODE == NETWORK_MODE_MESH
			debug_log_append( "- NETWORK_MODE: MESH\n");
#elif NETWORK_MODE == NETWORK_MODE_STAR
			debug_log_append("- NETWORK_MODE: STAR\n");
#endif

			// Close file
			res = debug_log_close();
		}
	}

	log_deinit();
#endif
	return res;
}

/*
 * See header file
 */
FRESULT sensor_log_append_line(uint8_t *sensorType, uint16_t *sensorValue,
		uint8_t size) {
	FRESULT res = FR_NOT_ENABLED;
#if SD_LOG & SD_LOG_SENS
	struct tm *time_s;
	rtc_utc_t rtc_utc_time;
	uint16_t rtc_ms;

	if (log_init() == FR_OK) {

// Create or open file if it exists
		res = f_open(&sensorLogFile, (TCHAR const*) sensorLogFileName,
		FA_OPEN_APPEND | FA_WRITE);

		if (res == FR_OK) {
			// Print timestamp
			rtc_get_time_date(&rtc_utc_time, &rtc_ms);
			time_s = gmtime(&rtc_utc_time);
			f_printf(&sensorLogFile, "%02u.%02u.%02u %02u:%02u:%02u",
					time_s->tm_mday, time_s->tm_mon + 1, time_s->tm_year - 100,
					time_s->tm_hour, time_s->tm_min, time_s->tm_sec);

			// Print senor type with corresponding sensor values
			for (uint8_t i = 0; i < size; i++) // TODO: sensor log value format
					{
				f_printf(&sensorLogFile, ";%d;%d", sensorType[i],
						sensorValue[i]);
			}

			// Append new line
			f_printf(&sensorLogFile, "\n");

			// Close file
			res = f_close(&sensorLogFile);
		}
	}
	log_deinit();
#endif
	return res;
}
