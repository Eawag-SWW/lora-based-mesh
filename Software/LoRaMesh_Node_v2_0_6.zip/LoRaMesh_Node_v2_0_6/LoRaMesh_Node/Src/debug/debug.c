/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		debug.c
 *
 * \description	Implementation of debug interface(es) for the current project
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		30.08.2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include <debug/debug.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include "utilities.h"
#include <mcu_pinout.h>
#include "mcu_hal.h"
#include "stm32l4xx.h"
/* -- makros ----------------------------------------------------------------*/
#define DBG_MAX_LENGTH 60

// define GPIO used for debug module here
#define DBG_GPIO_PORT	SI_ADC_PORT
#define DBG_GPIO1_PIN	SI_ADC_IN5_PIN
#define DBG_GPIO2_PIN	SI_ADC_IN6_PIN
/* -- type definitions-------------------------------------------------------*/
UART_HandleTypeDef huart4;
DMA_HandleTypeDef hdma_uart4_rx;
DMA_HandleTypeDef hdma_uart4_tx;

/* internal function declarations ------------------------------------------ */
static uint8_t dbgPrintInt( char *dest, int value, uint8_t max_size );
static uint8_t dbgPrintHex( char *dest, int value, uint8_t max_size );
static void dbgWrite( unsigned char* buffer, size_t* count );
static void debug_uart_init( void );
static void debug_uart_send_string( uint8_t *buff, uint32_t length);

/* internal variable definitions ------------------------------------------- */ 
static uint8_t uart_is_initialized = 0; 	/**< flag for init status of UART*/

static uint8_t tx_buffer[DBG_MAX_LENGTH];	/**< UART transmission buffer	 */
static uint8_t gpio_initialized = FALSE;	/**< flag for GPIO init state	 */

static char str[DBG_MAX_LENGTH];			/**< Buffer for resulting string */
/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
void dbgPrintf( char *text, ... )
{
	if( uart_is_initialized == 0 ){
		debug_uart_init( );
		uart_is_initialized = 1;
	}
	va_list vl;
	int32_t iValue;
	size_t str_idx;
	uint8_t txt_idx;
	uint8_t i = 0;

	if ( str == NULL ) {
		return;
	}

	va_start( vl, text );

	str_idx = 0;
	txt_idx = 0;
	while ( TRUE ) {
		if ( text[ txt_idx ] == 0 ) break;
		if ( txt_idx > 255 ) break;
		if ( str_idx >= DBG_MAX_LENGTH ) break;

		if ( (text[ txt_idx ] == '%') && (text[ txt_idx+1 ] == 'i') ) {
			iValue = va_arg( vl, int32_t );
			str_idx += dbgPrintInt( &str[ str_idx ], iValue, ( DBG_MAX_LENGTH - str_idx ) );
			txt_idx += 2;
			continue;
		}

		if ( (text[ txt_idx ] == '%') && (text[ txt_idx+1 ] == 'h') ) {
			iValue = va_arg( vl, uint32_t );
			str_idx += dbgPrintHex( &str[ str_idx ], iValue, ( DBG_MAX_LENGTH - str_idx ) );
			txt_idx += 2;
			continue;
		}

		str[ str_idx ] = text[ txt_idx ];
		str_idx++;
		txt_idx++;
	}

	va_end( vl );

	dbgWrite( (unsigned char*)str, &str_idx );

	for( i=0; i<DBG_MAX_LENGTH; i++){
		str[i] = (char)0;
	}
}

/*
 * See header file
 */
void debug_gpio_init( void )
{
	GPIO_InitTypeDef gp;

	if( DBG_GPIO_PORT == GPIOB ){
		if( __HAL_RCC_GPIOB_IS_CLK_DISABLED()){
			__HAL_RCC_GPIOB_CLK_ENABLE();
		}
	}
	if( DBG_GPIO_PORT == GPIOC ){
		if( __HAL_RCC_GPIOC_IS_CLK_DISABLED()){
			__HAL_RCC_GPIOC_CLK_ENABLE();
		}
	}

	gp.Mode = GPIO_MODE_OUTPUT_PP;
	gp.Pin = DBG_GPIO1_PIN | DBG_GPIO2_PIN;
	gp.Pull = GPIO_NOPULL;
	gp.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init( DBG_GPIO_PORT, &gp);

	HAL_GPIO_WritePin( DBG_GPIO_PORT, DBG_GPIO1_PIN | DBG_GPIO2_PIN, GPIO_PIN_RESET);

	gpio_initialized = TRUE;
}

/*
 * See header file
 */
void debug_gpio1_set( void )
{
	HAL_GPIO_WritePin( DBG_GPIO_PORT, DBG_GPIO1_PIN, GPIO_PIN_SET);
}

/*
 * See header file
 */
void debug_gpio1_reset( void )
{
	HAL_GPIO_WritePin( DBG_GPIO_PORT, DBG_GPIO1_PIN, GPIO_PIN_RESET);
}

/*
 * See header file
 */
void debug_gpio1_toggle( void )
{
	HAL_GPIO_TogglePin( DBG_GPIO_PORT, DBG_GPIO1_PIN );
}

/*
 * See header file
 */
void debug_gpio2_set( void )
{
	HAL_GPIO_WritePin( DBG_GPIO_PORT, DBG_GPIO2_PIN, GPIO_PIN_SET);
}

/*
 * See header file
 */
void debug_gpio2_reset( void )
{
	HAL_GPIO_WritePin( DBG_GPIO_PORT, DBG_GPIO2_PIN, GPIO_PIN_RESET);
}

/*
 * See header file
 */
void debug_gpio2_toggle( void )
{
	HAL_GPIO_TogglePin( DBG_GPIO_PORT, DBG_GPIO2_PIN );
}


/* internal functions definitions ------------------------------------------ */
/**
 *  \brief  Printout interger value to string
 *  \param  *dest:	Storage addess
 *  \param	value:	interger value
 *  \param	max_size: maximum allowed size of the string
 */
static uint8_t dbgPrintInt( char *dest, int value, uint8_t max_size )
{
	char number[ 10 ];
	uint8_t length;
	uint8_t i;
	itoa( value, number, 10 );
	length = 0;
	for ( i=0; i<10; i++ ) {
		if ( number[i] == 0 ) break;
		if ( max_size == 0 ) break;
		dest[ i ] = number[ i ];
		length++;
		max_size--;
	}
	return length;
}

/**
 *  \brief  Printout hex value to string
 *  \param  *dest:	Storage addess
 *  \param	value:	hex value
 *  \param	max_size: maximum allowed size of the string
 */
static uint8_t dbgPrintHex( char *dest, int value, uint8_t max_size )
{
	uint8_t h;
	uint8_t l;

	if ( max_size < 4 ) return 0;
	if ( value < 0 ) return 0;
	if ( value > 255 ) return 0;

	dest[0] = '0';
	dest[1] = 'x';

	h = value;
	l = value;

	h = ( h >> 4 );
	l = ( l & 0x0F );

	if ( h < 10 ) {
		dest[2] = ( h + 0x30 );
	} else {
		dest[2] = ( h + 0x37 );
	}

	if ( l < 10 ) {
		dest[3] = ( l + 0x30 );
	} else {
		dest[3] = ( l + 0x37 );
	}

	return 4;
}

/**
 *  \brief  Writes out a string over debug UART interface
 *  \param  *buffer: Buffer which contains the string
 *  \param	count: 	 Length of the string in bytes
 */
static void dbgWrite( unsigned char* buffer, size_t* count )
{
	debug_uart_send_string( buffer, (uint32_t) *count);
}

/**
 *  \brief  Writes out a string over debug UART interface
 *  \param  *buff: 	Buffer which contains the string
 *  \param	length: Length of the string in bytes
 */
static void debug_uart_send_string( uint8_t *buff, uint32_t length)
{
	HAL_StatusTypeDef stat;
	uint8_t i = 0;

	if( buff == NULL )
	{
		return;
	}

	for(i=0; i<length; i++)
	{
		tx_buffer[i] = *(buff + i);
	}

	//stat = HAL_UART_Transmit_DMA( &huart4, tx_buffer, length);
	stat = HAL_UART_Transmit( &huart4, tx_buffer, length, 20);
	if( stat != HAL_OK)
	{
		stat = stat;
	}
}

/**
 *  \brief  Initializes the debug UART interface
 */
void debug_uart_init( void )
{
	// initialize hardwar GPIOs
	GPIO_InitTypeDef GPIO_InitStruct;
	__HAL_RCC_UART4_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	GPIO_InitStruct.Pin = DEB_UART_TX_PIN|DEB_UART_RX_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF8_UART4;
	HAL_GPIO_Init(DEB_UART_PORT, &GPIO_InitStruct);

	// initialize uart 4 peripheral module
	huart4.Instance = UART4;
	huart4.Init.BaudRate = 115200;
	huart4.Init.WordLength = UART_WORDLENGTH_8B;
	huart4.Init.StopBits = UART_STOPBITS_1;
	huart4.Init.Parity = UART_PARITY_NONE;
	huart4.Init.Mode = UART_MODE_TX_RX;
	huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart4.Init.OverSampling = UART_OVERSAMPLING_16;
	huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart4) != HAL_OK)
	{
		MCU_Error_Handler();
	}

	// initalize uart channels
	hdma_uart4_rx.Instance = DMA2_Channel5;
	hdma_uart4_rx.Init.Request = DMA_REQUEST_2;
	hdma_uart4_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
	hdma_uart4_rx.Init.PeriphInc = DMA_PINC_DISABLE;
	hdma_uart4_rx.Init.MemInc = DMA_MINC_ENABLE;
	hdma_uart4_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	hdma_uart4_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	hdma_uart4_rx.Init.Mode = DMA_NORMAL;
	hdma_uart4_rx.Init.Priority = DMA_PRIORITY_LOW;
	if (HAL_DMA_Init(&hdma_uart4_rx) != HAL_OK)
	{
		MCU_Error_Handler();
	}

	__HAL_LINKDMA(&huart4,hdmarx,hdma_uart4_rx);

	hdma_uart4_tx.Instance = DMA2_Channel3;
	hdma_uart4_tx.Init.Request = DMA_REQUEST_2;
	hdma_uart4_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
	hdma_uart4_tx.Init.PeriphInc = DMA_PINC_DISABLE;
	hdma_uart4_tx.Init.MemInc = DMA_MINC_ENABLE;
	hdma_uart4_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	hdma_uart4_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	hdma_uart4_tx.Init.Mode = DMA_NORMAL;
	hdma_uart4_tx.Init.Priority = DMA_PRIORITY_LOW;
	if (HAL_DMA_Init(&hdma_uart4_tx) != HAL_OK)
	{
		MCU_Error_Handler();
	}

	__HAL_LINKDMA(&huart4,hdmatx,hdma_uart4_tx);

	HAL_NVIC_SetPriority(UART4_IRQn, 11, 0);
	HAL_NVIC_EnableIRQ( UART4_IRQn);
}


/* IRQ handlers ------------------------------------------------------------ */
/*
 * 	UART4 IRQ handler (debug UART)
 */
void UART4_IRQHandler( void)
{
	HAL_UART_IRQHandler( &huart4 );
}

/*
 * 	DMA TX complete IRQ handler
 */
void DMA2_Channel3_IRQHandler( void )
{
	HAL_DMA_IRQHandler(&hdma_uart4_tx);
}

/*
 * 	DMA RX complete IRQ handler
 */
void DMA2_Channel5_IRQHandler( void )
{
	HAL_DMA_IRQHandler(&hdma_uart4_rx);
}
