/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		DEC5TE.c
 *
 * \description	Sensor implementation for DEC5TE (temp. & moisture)
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include <DEC5TE.h>
#include "sensors_hal.h"
#include "stdlib.h"
#include "math.h"
#include "cmsis_os.h"

/* -- makros ----------------------------------------------------------------*/
#define NUM_AVERAGE			1		/** number of values for average calc.	 */
#define DEC5TE_TIMEOUT_MS  1000		/** timeout in ms						 */

/* -- type definitions-------------------------------------------------------*/
typedef struct {
				uint16_t dielectric_raw;	// dielectric in 100s
				uint16_t conductivity_raw;	// conductivit in 100s
				uint16_t temperature_10;	// temperature in 10s of degree
}sens_values_s;

/* internal function declarations ------------------------------------------ */
static uint8_t __calc_values (  uint8_t *raw, uint8_t raw_len,
								sens_values_s *values);
uint16_t __ascii_to_int ( uint8_t *pasci, uint8_t num_digits );

/* internal variable definitions ------------------------------------------- */ 


/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint8_t DEC5TE_init( void )
{
	if( sensor_hal_uart2_init( 1200, 0, 0 ) != 0 ) {
		return 1;
	}
	return 0;
}

/*
 * See header file
 */
uint8_t DEC5TE_deinit( void )
{
	sensor_hal_uart2_deinit( );
	return 0;
}

/*
 * See header file
 */
uint8_t DEC5TE_reinit( void )
{
	sensor_hal_uart2_reinit();
	return 0;
}

/*
 * See header file
 */
uint8_t DEC5TE_measure ( uint16_t *value, filter_t filter, uint8_t num_spl )
{
	uint32_t tickstart = 0;
	uint8_t ret = 0;
	uint8_t *pdata = NULL;
	sens_values_s measurements;

	sensor_hal_gpio_init_input( 3, GPIOA);
	tickstart = HAL_GetTick();
	while( 1 ){
		if( sensor_hal_gpio_input_read( 3, GPIOA ) == 1 ){
			HAL_Delay(1);
			if( sensor_hal_gpio_input_read(3, GPIOA) == 1 ) {
				sensor_hal_uart2_init( 1200, 0, 0 );
				HAL_Delay(2);
				break;
			}
		}
		if( HAL_GetTick() - tickstart > DEC5TE_TIMEOUT_MS ) {
			ret = 1;
			break;
		}
	}
	if( ret == 0 ) {
		pdata = (uint8_t*)pvPortMalloc( 30 );
		if( pdata == NULL ) {
			ret =  1;
		}
	}

	if( ret == 0 ) {
		sensor_hal_uart2_receive( pdata, 20, 180 );
	}
	sensor_hal_uart2_deinit( );

	__calc_values( pdata, 20, &measurements );

	*value = measurements.conductivity_raw;

	if( pdata != NULL ){
		vPortFree( pdata );
	}
	return ret;
}



/* internal functions definitions ------------------------------------------ */
/**
 * 	\brief	Calculates values according to raw data
 * 	\param	*raw:		pointer to raw data string
 * 	\param	raw_len:	length of raw data string in bytes
 * 	\param	*values:	pointer to buffer for storing calculated values
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t __calc_values (	uint8_t *raw, uint8_t raw_len,
								sens_values_s *values)
{
	uint8_t error = 0;
	uint8_t *ptemp = NULL;
	uint8_t r_ind = 0;
	uint8_t w_ind = 0;
	uint16_t temp;

	error = 1;
	for( r_ind=0; r_ind<raw_len; r_ind++) {
		if( *(raw+r_ind) == '\r') {
			// whole measurement values received
			error = 0;
		}
	}

	ptemp = pvPortMalloc( raw_len );
	if( ptemp == NULL ) {
		error = 1;
	}

	// get dielectric
	if( error == 0 ) {
		for(r_ind=0; r_ind<raw_len; r_ind++) {
			if(*(raw+r_ind) == ' ') {
				r_ind++;
				break;
			} else {
				*(ptemp + w_ind ) = *(raw + r_ind );
				w_ind++;
			}
		}
	}
	values->dielectric_raw = __ascii_to_int( ptemp, w_ind);
	// get conductivity
	w_ind = 0;
	if( error == 0 ) {
		for(; r_ind<raw_len; r_ind++) {
			if(*(raw+r_ind) == ' ') {
				r_ind++;
				break;
			} else {
				*(ptemp + w_ind ) = *(raw + r_ind );
				w_ind++;
			}
		}
	}
	values->conductivity_raw = __ascii_to_int( ptemp, w_ind);

	// get temperature
	w_ind = 0;
	if( error == 0 ) {
		for(; r_ind<raw_len; r_ind++) {
			if(*(raw+r_ind) == '\r') {
				break;
			} else {
				*(ptemp + w_ind ) = *(raw + r_ind);
				w_ind++;
			}
		}
	}
	temp = __ascii_to_int( ptemp, w_ind);
	temp -= 400;
	values->temperature_10 = temp;

	if(ptemp != NULL ) {
		vPortFree( ptemp );
	}

	return error;
}

/**
 * 	\brief	Converts ascii value to an integer
 * 	\param	*pasci:	pointer to ascii values
 * 	\param	num_digits	number of digits to be converted
 * 	\return	retursn converted integer value
 */
uint16_t __ascii_to_int ( uint8_t *pasci, uint8_t num_digits )
{
	uint16_t val = 0;
	uint8_t i;
	uint8_t *ptr;
	uint16_t mult;
	uint16_t temp;
	ptr = pasci;
	for( i=0; i<num_digits; i++ ) {
		mult = pow(10, num_digits - 1 - i );
		temp = (uint16_t)(*(ptr + i ) - 48 );
		val += ( temp * mult );
	}
	return val;
}
