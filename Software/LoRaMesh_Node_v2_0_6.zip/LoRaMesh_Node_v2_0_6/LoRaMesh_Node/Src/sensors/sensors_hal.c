/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		sensors_hal.c
 *
 * \description	Hardware Abstraction Layer for using sensors
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "sensors_hal.h"
#include "mcu_pinout.h"
#include "mcu_hal.h"
#include "stdio.h"
/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/
typedef enum {
				DEV_UART_IDLE = 0,
				DEV_UART_BUSY_RX = 1
}dev_states_t;

/* internal function declarations ------------------------------------------ */


/* internal variable definitions ------------------------------------------- */
static USART_TypeDef *uart = USART2;
static uint32_t rxcnt;
static uint8_t rxfinished;
static dev_states_t uart_state = DEV_UART_IDLE;
static uint8_t *pdata;
static uint32_t baudrate_bkup;
static uint8_t txinv_bkup;
static uint8_t rxinv_bkup;


/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint8_t sensor_hal_uart2_init ( uint32_t baudrate,
								uint8_t txinvert, uint8_t rxinvert )
{
	GPIO_InitTypeDef gpio;
	uint32_t per_freq;

	if( !__HAL_RCC_GPIOA_IS_CLK_ENABLED() ) {
		__HAL_RCC_GPIOA_CLK_ENABLE( );
	}
	if( !__HAL_RCC_USART2_IS_CLK_ENABLED( ) ) {
		__HAL_RCC_USART2_CLK_ENABLE( );
	}

	gpio.Pin = SI_UART_TX_PIN | SI_UART_RX_PIN;
	gpio.Mode = GPIO_MODE_AF_PP;
	gpio.Pull = GPIO_NOPULL;
	gpio.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	gpio.Alternate = GPIO_AF7_USART2;
	HAL_GPIO_Init( SI_UART_PORT, &gpio );

	uart->CR1 = 0x00000000;
	uart->CR1 |= ( USART_CR1_RXNEIE | USART_CR1_RE | USART_CR1_TE);
	uart->CR3 = ( USART_CR3_OVRDIS );
	if( txinvert ) {
		uart->CR2 |= USART_CR2_TXINV;
		txinv_bkup = txinvert;
	}
	if( rxinvert ) {
		uart->CR2 |= USART_CR2_RXINV;
		rxinv_bkup = rxinvert;
	}
	per_freq = HAL_RCCEx_GetPeriphCLKFreq( RCC_PERIPHCLK_USART2 );
	uart->BRR = ( per_freq / baudrate );
	baudrate_bkup = baudrate;

	HAL_NVIC_ClearPendingIRQ( USART2_IRQn );
	HAL_NVIC_SetPriority( USART2_IRQn, 0, 0);
	return 0;
}

/*
 * See header file
 */
uint8_t sensor_hal_uart2_reinit ( void )
{
	sensor_hal_uart2_init( baudrate_bkup, txinv_bkup, rxinv_bkup );
	return 0;
}

/*
 * See header file
 */
uint8_t sensor_hal_uart2_deinit ( void )
{
	GPIO_InitTypeDef gp;
	__HAL_RCC_USART2_CLK_DISABLE();
	gp.Pin = (SI_UART_TX_PIN | SI_UART_RX_PIN );
	gp.Mode = GPIO_MODE_INPUT;
	gp.Pull = GPIO_PULLDOWN;
	gp.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init( SI_UART_PORT, &gp);
	return 0;
}

/*
 * See header file
 */
void sensor_hal_gpio_init_pp ( uint8_t gpio_nr, GPIO_TypeDef *gpioport)
{
	GPIO_InitTypeDef gpioinit;
	mcu_enable_port_clock( gpioport);

	gpioinit.Pin = (1 << gpio_nr );
	gpioinit.Mode = GPIO_MODE_OUTPUT_PP;
	gpioinit.Pull = GPIO_NOPULL;
	gpioinit.Speed = GPIO_SPEED_FAST;
	HAL_GPIO_Init( gpioport, &gpioinit );
}

/*
 * See header file
 */
void sensor_hal_gpio_init_input ( uint8_t gpio_nr, GPIO_TypeDef *gpioport)
{
	GPIO_InitTypeDef gpioinit;
	mcu_enable_port_clock( gpioport );
	gpioinit.Pin = (1<<gpio_nr);
	gpioinit.Mode = GPIO_MODE_INPUT;
	gpioinit.Pull = GPIO_NOPULL;
	gpioinit.Speed = GPIO_SPEED_FAST;
	HAL_GPIO_Init( gpioport, &gpioinit );

}

/*
 * See header file
 */
uint8_t sensor_hal_gpio_input_read ( uint32_t gpio_nr, GPIO_TypeDef *gpioport)
{
	return (uint8_t)HAL_GPIO_ReadPin( gpioport, (1<<gpio_nr));
}

/*
 * See header file
 */
void sensor_hal_gpio_set( GPIO_TypeDef *gpioport, uint32_t gpio_nr )
{
	HAL_GPIO_WritePin( gpioport, gpio_nr, GPIO_PIN_SET );
}

/*
 * See header file
 */
void sensor_hal_gpio_reset( GPIO_TypeDef *gpioport, uint32_t gpio_nr )
{
	HAL_GPIO_WritePin( gpioport, gpio_nr, GPIO_PIN_RESET );
}

/*
 * See header file
 */
uint8_t sensor_hal_uart2_receive ( uint8_t *data, uint16_t num_data,
													uint32_t timeout )
{
	uint32_t starttick = 0;
	if( data == NULL ) {
		return 1;
	}
	pdata = data;
	rxcnt = num_data;
	rxfinished = 0;
	uart->RQR |= USART_RQR_RXFRQ;
	HAL_NVIC_ClearPendingIRQ( USART2_IRQn );
	HAL_NVIC_EnableIRQ( USART2_IRQn );
	uart->CR1 |= USART_CR1_UE;
	uart_state = DEV_UART_BUSY_RX;
	if( timeout == 0 ) {
		while ( !rxfinished ) {
		}
	} else {
		starttick = HAL_GetTick( );
		while ( !rxfinished ) {
			if( HAL_GetTick( ) - starttick > timeout ) {
				return 1;	// timeout error
			}
		}
	}
	return 0;	// success
}

/**
 *  \brief  IRQ Handler for UART module
 */
void USART2_IRQHandler( void )
{
	if( uart->ISR & USART_ISR_RXNE ) {
		*pdata  = uart->RDR;
		pdata++;
		rxcnt--;
		if( rxcnt < 1 ) {
			rxfinished = 1;
			HAL_NVIC_DisableIRQ( UART4_IRQn );
			uart_state = DEV_UART_IDLE;
			uart->CR1 &=~ USART_CR1_UE;
		}
	}
	uart->ISR = 0xFFFFFFFF;
}
