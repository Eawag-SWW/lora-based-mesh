/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		MB7369.c
 *
 * \description	Sensor implementation for DEC5TE (ultrasonic)
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "MB7369.h"
#include "sensors_hal.h"
#include "stdlib.h"
#include "filter_median.h"
#include "cmsis_os.h"
/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */
static uint16_t get_values ( uint8_t num_average );
static uint16_t get_single_sample( void );
/* internal variable definitions ------------------------------------------- */ 


/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint8_t MB7369_init( void )
{
	if( sensor_hal_uart2_init( 9600, 0, 1 ) != 0 ) {
		return 1;
	}
	//sensor_hal_gpio_init_pp( 13, GPIOC );
	return 0;
}

/*
 * See header file
 */
uint8_t MB7369_deinit( void )
{
	sensor_hal_uart2_deinit( );
	return 0;
}

/*
 * See header file
 */
uint8_t MB7369_reinit( void )
{
	sensor_hal_uart2_reinit();
	return 0;
}

/*
 * See header file
 */
uint8_t MB7369_measure ( uint16_t *value, filter_t filter, uint8_t num_spl )
{
	uint8_t i = 0;
	uint16_t val = 0;
	uint16_t *valbuf = NULL;

	MB7369_init( );
	HAL_Delay( 200 ); // TODO: choose correct delay

	switch( filter ){
	case FILTER_NONE:
		break;
	case FILTER_MEDIAN:
		valbuf = (uint16_t*)pvPortMalloc( num_spl * sizeof(uint16_t) );
		if( valbuf == NULL ){
			return 1;	// something went wrong
		}
		for( i=0; i<num_spl; i++){
			*(valbuf + i) = get_single_sample();
		}
		val = filter_median( valbuf, num_spl );
		vPortFree( valbuf );
		break;
	default:
		break;
	}
	*value = val;
	MB7369_deinit( );
	return 0;
}



/* internal functions definitions ------------------------------------------ */
/**
 * 	\brief	Get temperature value by averaging
 * 	\param	num_average:	number of values for average calculation
 * 	\return	returns measured value
 */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
static uint16_t get_values ( uint8_t num_average )
{
	uint8_t *pchar = NULL;
	uint16_t *pdata = NULL;
	uint16_t i = 0;
	uint16_t j = 0;
	uint32_t sum = 0;
	pchar = (uint8_t*)pvPortMalloc( num_average * 6 );
	pdata = (uint16_t*)pvPortMalloc( sizeof(uint16_t) * num_average );
	if( (pchar == NULL ) || (pdata == NULL ) ){
		return 0; // TODO: Error handling
	}
	if( sensor_hal_uart2_receive( pchar, num_average * 6, 2000 ) == HAL_OK ){ // TODO: dynamic timeout
		for( i=0; i<((num_average + 1) * 6); i++ ) {
			if( *(pchar+i) == 'R') {
				i++;
				*(pdata + j) = (*(pchar + i) - 48)	* 1000;
				i++;
				*(pdata + j) += (*(pchar + i) - 48)	*  100;
				i++;
				*(pdata + j) += (*(pchar + i) - 48)	*   10;
				i++;
				*(pdata + j) += (*(pchar + i) - 48);
				j++;
			}
		}
		vPortFree( pchar );
		if( j >= num_average ) // enough measurements received
		{
			for(i=0; i<num_average; i++ ) {
				sum+= *(pdata + i);
			}
			sum = sum/num_average;
		}
		return (uint16_t)sum;
	} else {
		return 0;
	}
}
#pragma GCC diagnostic pop

/**
 * 	\brief	Reads a single sample form the sensor
 * 	\return	single sample in millimeters
 */
static uint16_t get_single_sample( void )
{
	uint8_t *pchar = NULL;
	uint16_t temp = 0;
	pchar = (uint8_t*)pvPortMalloc( 6 );
	if( pchar == NULL ){
		return 0;
	}
	if( sensor_hal_uart2_receive( pchar, 6, 200 ) == HAL_OK){
		if( *pchar == 'R' ){
			temp =  ((uint16_t)(*(pchar + 1) - 48 )) * 1000;
			temp += ((uint16_t)(*(pchar + 2) - 48 )) *  100;
			temp += ((uint16_t)(*(pchar + 3) - 48 )) *   10;
			temp += ((uint16_t)(*(pchar + 4) - 48 )) *    1;
		}
	}
	vPortFree( pchar );
	return temp;
}
