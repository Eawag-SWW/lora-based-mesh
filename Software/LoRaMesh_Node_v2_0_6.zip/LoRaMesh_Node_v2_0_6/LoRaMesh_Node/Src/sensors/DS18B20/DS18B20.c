/**	
 * |----------------------------------------------------------------------
 * | Copyright (C) Tilen Majerle, 2014
 * | 
 * | This program is free software: you can redistribute it and/or modify
 * | it under the terms of the GNU General Public License as published by
 * | the Free Software Foundation, either version 3 of the License, or
 * | any later version.
 * |  
 * | This program is distributed in the hope that it will be useful,
 * | but WITHOUT ANY WARRANTY; without even the implied warranty of
 * | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * | GNU General Public License for more details.
 * | 
 * | You should have received a copy of the GNU General Public License
 * | along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * |----------------------------------------------------------------------
 */
#include "DS18B20.h"
#include "sensors_hal.h"
#include "stdlib.h"
#include "mcu_pinout.h"
#include "filter_median.h"
#include "stdbool.h"

#define EXPECTED_SENSORS 1 // TODO: maybe add to device_config.h

uint8_t deviceCount = 0;
bool initiateSearchROM = true;
uint8_t device[EXPECTED_SENSORS][8];
float temps[EXPECTED_SENSORS];
uint16_t tempsFilteredK[EXPECTED_SENSORS];

void DS18B20_Init(OneWire_t* OneWireStruct) {
	DELAY_Init();
	OneWire_Init(OneWireStruct, SI_1WIRE_PORT, SI_1WIRE_PIN);
}

void DS18B20_DeInit(OneWire_t* OneWireStruct) {
	OneWire_DeInit(OneWireStruct);
	DELAY_DeInit();
}

uint8_t DS18B20_measure(uint16_t *value, filter_t filter, uint8_t num_spl) {
	// OneWire working struct
	OneWire_t OneWire1;
	uint8_t deviceAvailable = 0, i, j;

	DS18B20_Init(&OneWire1);

	// Check if ROMs have already been searched
	if (initiateSearchROM) {

		deviceCount = 0;

		// Start searching for devices on bus
		deviceAvailable = OneWire_First(&OneWire1); // TODO: searching for ROM has to be performed only once.

		// If device(s) are found get the ROM and repeat for all devices on the bus
		while (deviceAvailable) {
			// Increase counter
			deviceCount++;

			// check if not more devices participate than expected
			if (deviceCount > EXPECTED_SENSORS) {
				deviceCount = EXPECTED_SENSORS;
				break;
			}

			// Get full ROM value, 8 bytes, give location of first byte where to save
			OneWire_GetFullROM(&OneWire1, device[deviceCount - 1]);

			// Get next device
			deviceAvailable = OneWire_Next(&OneWire1);
		}

		// Mark that ROMs have been searched (only if successful)
		if (deviceCount > 0) {
			initiateSearchROM = false;
		}
	}

	// If any devices on 1-wire
	if (deviceCount > 0) {

		// Is not needed as default resolution is already 12bits
		// Go through all connected devices and set resolution to 12bits
		/*for (i = 0; i < count; i++) {
		 // Set resolution to 12bits
		 DS18B20_SetResolution(&OneWire1, device[i],
		 DS18B20_Resolution_12bits);
		 }*/

		// create buffer for median filter
		uint16_t *valbuf[deviceCount];

		switch (filter) {
		case FILTER_NONE:

			// Start temperature conversion on all devices on one bus
			DS18B20_StartAll(&OneWire1);

			// Wait until all are done on one onewire port
			while (!DS18B20_AllDone(&OneWire1)) {

			}

			// Reset line TODO: why is this necessary??
			//OneWire_Reset(&OneWire1);

			// Read temperature from each device separately
			for (i = 0; i < deviceCount; i++) {
				// Read temperature from ROM address and store it to temps variable
				if (DS18B20_Read(&OneWire1, device[i], &temps[i])) {

				} else {
					// Device does not respond initiate new search for ROMs next measurement
					initiateSearchROM = true;
				}
			}
			*value = (uint16_t) ((temps[0] + 273.15) * 100); //so far only one sensor value is returned
			break;
		case FILTER_MEDIAN:

			for (i = 0; i < deviceCount; i++) {
				valbuf[i] = malloc(num_spl * sizeof(uint16_t));
			}
			if (valbuf[0] == NULL) {
				return 1;	// something went wrong
			}
			// Read temperature from all sensors num_spl times. By starting all sensors at once
			// the conversion time of n sensors is identical to the conversion time of only one sensor.
			// The read however has to be done successively
			for (i = 0; i < num_spl; i++) {
				// Start temperature conversion on all devices on one bus
				DS18B20_StartAll(&OneWire1);

				// Wait until all are done on one onewire port
				while (!DS18B20_AllDone(&OneWire1)) {

				}

				// Read temperature from each device separately
				for (j = 0; j < deviceCount; j++) {
					// Read temperature from ROM address and store it to buffer for median filter later
					if (DS18B20_Read(&OneWire1, device[j], &temps[j])) {
						*(valbuf[j] + i) =
								(uint16_t) ((temps[j] + 273.15) * 100);
					} else {
						// Device does not respond initiate new search for ROMs next measurement
						initiateSearchROM = true;
					}
				}
			}
			for (i = 0; i < deviceCount; i++) {
				tempsFilteredK[i] = filter_median(valbuf[i], num_spl);
				free(valbuf[i]);
			}

			*value = tempsFilteredK[0]; //TODO: so far only on sensor value is returned

			break;
		default:
			break;
		}

		// If measurement was successful deinit interface
		DS18B20_DeInit(&OneWire1);

	} else {
		// No device on 1-wire bus
		return 1;
	}

	// Measurement was successful
	return 0;
}

uint8_t DS18B20_Start(OneWire_t* OneWire, uint8_t *ROM) {
	// Check if device is DS18B20
	if (!DS18B20_Is(ROM)) {
		return 0;
	}

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Start temperature conversion
	OneWire_WriteByte(OneWire, DS18B20_CMD_CONVERTTEMP);

	return 1;
}

void DS18B20_StartAll(OneWire_t* OneWire) {
	// Reset pulse
	OneWire_Reset(OneWire);
	// Skip rom
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_SKIPROM);
	// Start conversion on all connected devices
	OneWire_WriteByte(OneWire, DS18B20_CMD_CONVERTTEMP);
}

uint8_t DS18B20_Read(OneWire_t* OneWire, uint8_t *ROM, float *destination) {
	uint16_t temperature;
	uint8_t resolution;
	int8_t digit, minus = 0;
	float decimal;
	uint8_t i = 0;
	uint8_t data[9];
	uint8_t crc;

	// Check if device is DS18B20
	if (!DS18B20_Is(ROM)) {
		return 0;
	}

	// Check if line is released, if it is, then conversion is complete
	if (!OneWire_ReadBit(OneWire)) {
		// Conversion is not finished yet
		return 0;
	}

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Read scratchpad command by onewire protocol
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_RSCRATCHPAD);

	// Get data
	for (i = 0; i < 9; i++) {
		// Read byte by byte
		data[i] = OneWire_ReadByte(OneWire);
	}

	// Calculate CRC
	crc = OneWire_CRC8(data, 8);

	// Check if CRC is ok
	if (crc != data[8]) {
		// CRC invalid
		return 0;
	}

	// First two bytes of scratchpad are temperature values
	temperature = data[0] | (data[1] << 8);

	// Reset line
	OneWire_Reset(OneWire);

	// Check if temperature is negative
	if (temperature & 0x8000) {
		// Two's complement, temperature is negative
		temperature = ~temperature + 1;
		minus = 1;
	}

	// Get sensor resolution
	resolution = ((data[4] & 0x60) >> 5) + 9;

	// Store temperature integer digits and decimal digits
	digit = temperature >> 4;
	digit |= ((temperature >> 8) & 0x7) << 4;

	// Store decimal digits
	switch (resolution) {
	case 9: {
		decimal = (temperature >> 3) & 0x01;
		decimal *= (float) DS18B20_DECIMAL_STEPS_9BIT;
	}
		break;
	case 10: {
		decimal = (temperature >> 2) & 0x03;
		decimal *= (float) DS18B20_DECIMAL_STEPS_10BIT;
	}
		break;
	case 11: {
		decimal = (temperature >> 1) & 0x07;
		decimal *= (float) DS18B20_DECIMAL_STEPS_11BIT;
	}
		break;
	case 12: {
		decimal = temperature & 0x0F;
		decimal *= (float) DS18B20_DECIMAL_STEPS_12BIT;
	}
		break;
	default: {
		decimal = 0xFF;
		digit = 0;
	}
	}

	// Check for negative part
	decimal = digit + decimal;
	if (minus) {
		decimal = 0 - decimal;
	}

	// Set to pointer
	*destination = decimal;

	// Return 1, temperature valid
	return 1;
}

uint8_t DS18B20_GetResolution(OneWire_t* OneWire, uint8_t *ROM) {
	uint8_t conf;

	if (!DS18B20_Is(ROM)) {
		return 0;
	}

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Read scratchpad command by onewire protocol
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_RSCRATCHPAD);

	// Ignore first 4 bytes
	OneWire_ReadByte(OneWire);
	OneWire_ReadByte(OneWire);
	OneWire_ReadByte(OneWire);
	OneWire_ReadByte(OneWire);

	// 5th byte of scratchpad is configuration register
	conf = OneWire_ReadByte(OneWire);

	// Return 9 - 12 value according to number of bits
	return ((conf & 0x60) >> 5) + 9;
}

uint8_t DS18B20_SetResolution(OneWire_t* OneWire, uint8_t *ROM,
		DS18B20_Resolution_t resolution) {
	uint8_t th, tl, conf;
	if (!DS18B20_Is(ROM)) {
		return 0;
	}

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Read scratchpad command by onewire protocol
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_RSCRATCHPAD);

	// Ignore first 2 bytes
	OneWire_ReadByte(OneWire);
	OneWire_ReadByte(OneWire);

	th = OneWire_ReadByte(OneWire);
	tl = OneWire_ReadByte(OneWire);
	conf = OneWire_ReadByte(OneWire);

	if (resolution == DS18B20_Resolution_9bits) {
		conf &= ~(1 << DS18B20_RESOLUTION_R1);
		conf &= ~(1 << DS18B20_RESOLUTION_R0);
	} else if (resolution == DS18B20_Resolution_10bits) {
		conf &= ~(1 << DS18B20_RESOLUTION_R1);
		conf |= 1 << DS18B20_RESOLUTION_R0;
	} else if (resolution == DS18B20_Resolution_11bits) {
		conf |= 1 << DS18B20_RESOLUTION_R1;
		conf &= ~(1 << DS18B20_RESOLUTION_R0);
	} else if (resolution == DS18B20_Resolution_12bits) {
		conf |= 1 << DS18B20_RESOLUTION_R1;
		conf |= 1 << DS18B20_RESOLUTION_R0;
	}

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Write scratchpad command by onewire protocol, only th, tl and conf register can be written
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_WSCRATCHPAD);

	// Write bytes
	OneWire_WriteByte(OneWire, th);
	OneWire_WriteByte(OneWire, tl);
	OneWire_WriteByte(OneWire, conf);

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Copy scratchpad to EEPROM of DS18B20
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_CPYSCRATCHPAD);

	return 1;
}

uint8_t DS18B20_Is(uint8_t *ROM) {
	// Checks if first byte is equal to DS18B20's family code
	if (*ROM == DS18B20_FAMILY_CODE) {
		return 1;
	}
	return 0;
}

uint8_t DS18B20_SetAlarmLowTemperature(OneWire_t* OneWire, uint8_t *ROM,
		int8_t temp) {
	uint8_t tl, th, conf;
	if (!DS18B20_Is(ROM)) {
		return 0;
	}
	if (temp > 125) {
		temp = 125;
	}
	if (temp < -55) {
		temp = -55;
	}
	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Read scratchpad command by onewire protocol
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_RSCRATCHPAD);

	// Ignore first 2 bytes
	OneWire_ReadByte(OneWire);
	OneWire_ReadByte(OneWire);

	th = OneWire_ReadByte(OneWire);
	tl = OneWire_ReadByte(OneWire);
	conf = OneWire_ReadByte(OneWire);

	tl = (uint8_t) temp;

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Write scratchpad command by onewire protocol, only th, tl and conf register can be written
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_WSCRATCHPAD);

	// Write bytes
	OneWire_WriteByte(OneWire, th);
	OneWire_WriteByte(OneWire, tl);
	OneWire_WriteByte(OneWire, conf);

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Copy scratchpad to EEPROM of DS18B20
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_CPYSCRATCHPAD);

	return 1;
}

uint8_t DS18B20_SetAlarmHighTemperature(OneWire_t* OneWire, uint8_t *ROM,
		int8_t temp) {
	uint8_t tl, th, conf;
	if (!DS18B20_Is(ROM)) {
		return 0;
	}
	if (temp > 125) {
		temp = 125;
	}
	if (temp < -55) {
		temp = -55;
	}
	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Read scratchpad command by onewire protocol
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_RSCRATCHPAD);

	// Ignore first 2 bytes
	OneWire_ReadByte(OneWire);
	OneWire_ReadByte(OneWire);

	th = OneWire_ReadByte(OneWire);
	tl = OneWire_ReadByte(OneWire);
	conf = OneWire_ReadByte(OneWire);

	th = (uint8_t) temp;

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Write scratchpad command by onewire protocol, only th, tl and conf register can be written
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_WSCRATCHPAD);

	// Write bytes
	OneWire_WriteByte(OneWire, th);
	OneWire_WriteByte(OneWire, tl);
	OneWire_WriteByte(OneWire, conf);

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Copy scratchpad to EEPROM of DS18B20
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_CPYSCRATCHPAD);

	return 1;
}

uint8_t DS18B20_DisableAlarmTemperature(OneWire_t* OneWire, uint8_t *ROM) {
	uint8_t tl, th, conf;
	if (!DS18B20_Is(ROM)) {
		return 0;
	}
	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Read scratchpad command by onewire protocol
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_RSCRATCHPAD);

	// Ignore first 2 bytes
	OneWire_ReadByte(OneWire);
	OneWire_ReadByte(OneWire);

	th = OneWire_ReadByte(OneWire);
	tl = OneWire_ReadByte(OneWire);
	conf = OneWire_ReadByte(OneWire);

	th = 125;
	tl = (uint8_t) -55;

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Write scratchpad command by onewire protocol, only th, tl and conf register can be written
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_WSCRATCHPAD);

	// Write bytes
	OneWire_WriteByte(OneWire, th);
	OneWire_WriteByte(OneWire, tl);
	OneWire_WriteByte(OneWire, conf);

	// Reset line
	OneWire_Reset(OneWire);
	// Select ROM number
	OneWire_SelectWithPointer(OneWire, ROM);
	// Copy scratchpad to EEPROM of DS18B20
	OneWire_WriteByte(OneWire, ONEWIRE_CMD_CPYSCRATCHPAD);

	return 1;
}

uint8_t DS18B20_AlarmSearch(OneWire_t* OneWire) {
	// Start alarm search
	return OneWire_Search(OneWire, DS18B20_CMD_ALARMSEARCH);
}

uint8_t DS18B20_AllDone(OneWire_t* OneWire) {
	// If read bit is low, then device is not finished yet with calculation temperature
	return OneWire_ReadBit(OneWire);
}

