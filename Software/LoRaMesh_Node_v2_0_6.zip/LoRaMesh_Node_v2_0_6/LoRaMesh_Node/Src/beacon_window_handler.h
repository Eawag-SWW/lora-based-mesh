/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		beacon_handler.h
 *
 * \description	This module handles beacon windows for each device
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		18.09.2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _BEAC_WIND_HANDLER
#define _BEAC_WIND_HANDLER

/* -- includes --------------------------------------------------------------*/
#include "stdint.h"

/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/


/* public function declarations -------------------------------------------- */

/**
 *  \brief  Initializes the beacon window handler with the amount of windows
 *  \param  n_windows:	desired amount of beacon windows
 *  \return 0 on succes, nonzero on error
 */
uint8_t beacon_window_handler_init( uint8_t n_windows );

/**
 *  \brief	Register a specified window for a given node
 *  \param  win_number:	desired window number
 *  \param	node_addr:	address of node for which the window is reserved
 *  \return 0 on succes, nonzero on error
 */
uint8_t beacon_window_handler_register_window(	uint8_t win_number,
												uint16_t node_addr);

/*
 * 	\brief	Searches a free window and registers a node on this window
 * 	\param	node_addr:	address of the node for which the window is reserved
 * 	\return	returns the slot number on success, 0xFF on error
 */
uint8_t beacon_window_get_reg_free_window( uint16_t node_addr);

/*
 * 	\brief	Deregisters a window for a given node
 * 	\param	node_addr: address of the node
 * 	\return	returns 0 on success, nonzero on error
 */
uint8_t beacon_window_deregister( uint16_t node_addr );


#endif	//_BEAC_WIND_HANDLER

