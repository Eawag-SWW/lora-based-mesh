/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  *
  * Copyright (c) 2017 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"
#include "leds.h"
#include "utilities.h"
#include "task_run.h"
#include "proc_join.h"
#include "proc_sync.h"
#include "proc_communication.h"
#include "timesource/timesource.h"
#include "device_config.h"
#include "user_diskio_spi.h"

#if TIMESOURCE == TIMESOURCE_DCF77
#include "dcf77.h"
#endif

/* Variables -----------------------------------------------------------------*/
osThreadId defaultTaskHandle;
osThreadId cyclerTaskHandle;
osThreadId runTaskHandle;
osThreadId sxTaskHandle;
osTimerId syncTimerHandle;
osTimerId commTimerHandle;
osTimerId timesrcTimerHandle;
osTimerId dcfTimerHandle;
osTimerId sdSpiTimerHandle;
osMessageQId osCyInDCFQueue;

/* Function prototypes -------------------------------------------------------*/

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Init FreeRTOS */

void MX_FREERTOS_Init(void) {
	// Init

	// Mutexes

	// Semaphores

	// RTOS Timers
	osTimerDef(synctimer, sync_timer_on_timeout);
	syncTimerHandle = osTimerCreate(osTimer(synctimer), osTimerOnce, NULL );
	osTimerDef(commtimer, commtimer_on_timeout);
	commTimerHandle = osTimerCreate(osTimer(commtimer), osTimerOnce, NULL );
	osTimerDef( timesrctimer, timesource_timer_on_timeout);
	timesrcTimerHandle = osTimerCreate(osTimer(timesrctimer), osTimerOnce, NULL );
	osTimerDef( sdspitimer, sdspi_timer_on_timeout);
	sdSpiTimerHandle = osTimerCreate(osTimer(sdspitimer), osTimerOnce, NULL );

#if TIMESOURCE == TIMESOURCE_DCF77
	osTimerDef(dcftimer, dcf_timer_on_timeout );
	dcfTimerHandle = osTimerCreate(osTimer(dcftimer), osTimerOnce, NULL );
#endif

	// start timers, add new ones, ...


	// Create the thread(s) */
	// definition and creation of defaultTask */
	osThreadDef(runTask, task_run, 1, 0, 1024 );
	runTaskHandle = osThreadCreate(osThread(runTask), NULL);

	// RTOS queues

}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
