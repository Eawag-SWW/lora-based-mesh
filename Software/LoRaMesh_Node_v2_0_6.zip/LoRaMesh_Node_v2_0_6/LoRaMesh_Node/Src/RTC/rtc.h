/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		rtc.h
 *
 * \description	Real Time Clock (RTC) module implementation
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		09.02.2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _RTC_H
#define _RTC_H

/* -- includes --------------------------------------------------------------*/
#include "stdint.h"
#include "time.h"

/* -- makros ----------------------------------------------------------------*/

/* -- type definitions-------------------------------------------------------*/
typedef time_t rtc_utc_t;

typedef enum { 	STOPPED = 1,
				RUNNING
}alarm_states_t;

typedef struct rtc_alarm_s {
								void (*alarm_cb)(void);
								time_t alarm_time;
								uint16_t alarm_ms;
								alarm_states_t state;
								struct rtc_alarm_s *next;
}rtc_alarm_t;

typedef enum rtc_return {
								RTC_OK = 0,
								RTC_ERROR
}rtc_ret_t;

/* public function declarations -------------------------------------------- */

/**
 *  \brief  Initializes the RTC module
 *  \param  (*callback):	pointer to callback function
 */
void rtc_init ( );

/**
 *  \brief  Sets current time and date of the RTC module
 *  \param  time	32-bit UTC time
 */
void rtc_set_time_date ( rtc_utc_t utc_time, uint16_t ms_offset);

/**
 *  \brief  Gets current time and date from the RTC module
 *  \param	*utc	pointer to utc variable for storing the result
 *  \param  *ms		pointer to ms variable for storing result
 */
void rtc_get_time_date ( rtc_utc_t *utc, uint16_t *ms );

/**
 *  \brief  Sets the RTC alarm to a desired time and date
 *  \param	alarmtime: desired alarmtime as 32-bit UTC time
 */
rtc_ret_t rtc_set_alarm ( rtc_alarm_t *alarm );

/**
 *  \brief  Removes a specific alarm from the list
 *  \param	*alarm: specifies the alarm to be removed
 */
void rtc_remove_alarm( rtc_alarm_t *alarm );
#endif //_RTC_H

