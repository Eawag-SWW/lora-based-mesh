/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		rtc.c
 *
 * \description	Real Time Clock (RTC) module implementation
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		09.02.2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "rtc.h"
#include "rtc_hal.h"
#include "cmsis_os.h"
#include "mcu_hal.h"
#include <stdbool.h>

/* -- makros ----------------------------------------------------------------*/
#define 	RTC_INIT_UTC_VALUE	1483228800		// 01.01.2017;00:00:00

#define 	SAFETY_OFFSET_MS	10				// safety offset in ms

/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */
static void utc_to_rtc_timedat ( rtc_timedate_s *timdat, rtc_utc_t *utc );
static void timedat_to_utc ( rtc_utc_t *utc, rtc_timedate_s *timdat);
static void rtc_hal_alrm_callback( void );
static void __set_alarm ( rtc_utc_t alarmtime, uint16_t millisecs );
static void __reset_alarm( void );
static uint8_t alarm_time_is_bigger( rtc_alarm_t *ref, rtc_alarm_t *comp );
static uint8_t insert_alarm_in_list( rtc_alarm_t *alarm);
static uint8_t alarm_time_is_later_then_systime( rtc_alarm_t *alarm );

/* internal variable definitions ------------------------------------------- */ 
static rtc_alarm_t *rtc_alarm_head = NULL;
static uint8_t alarm_id = 0;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
void rtc_init ( void )
{
	rtc_utc_t temp_utc = RTC_INIT_UTC_VALUE;
	rtc_timedate_s temp_timedat;
	rtc_hal_init( );
	temp_utc = RTC_INIT_UTC_VALUE;
	utc_to_rtc_timedat( &temp_timedat, &temp_utc);
	temp_timedat.time.milisecond = 0;
	rtc_hal_set_time_date( &temp_timedat);
	alarm_id = 0;
}

/*
 * See header file
 */
void rtc_set_time_date ( rtc_utc_t utc_time, uint16_t ms_offset)
{
	rtc_utc_t temp_utc = utc_time;
	rtc_timedate_s temp_timedat;
	utc_to_rtc_timedat ( &temp_timedat, &temp_utc );
	temp_timedat.time.milisecond = ms_offset;
	rtc_hal_set_time_date( &temp_timedat );
}

/*
 * See header file
 */
void rtc_get_time_date ( rtc_utc_t *utc, uint16_t *ms )
{
	rtc_timedate_s temp_timedat;
	rtc_hal_get_time_date( &temp_timedat );
	timedat_to_utc( utc, &temp_timedat );
	if( temp_timedat.time.milisecond > 1000){
		*utc = *utc - 1;
		*ms= (temp_timedat.time.milisecond - 1000);
	} else {
		*ms = temp_timedat.time.milisecond;
	}
	return;
}

/*
 * See header file
 */
rtc_ret_t rtc_set_alarm ( rtc_alarm_t *alarm )
{
	rtc_utc_t systime;
	uint16_t systime_ms;
	rtc_alarm_t *curr, *next;
	rtc_get_time_date( &systime, &systime_ms );

	if( alarm_time_is_later_then_systime( alarm )) {
		if((rtc_alarm_head != NULL) && (rtc_alarm_head->state == RUNNING)) {
			if( rtc_alarm_head == alarm ) {
				if((rtc_alarm_head->next != NULL) && (rtc_alarm_head->next->state == RUNNING)) {
					curr = rtc_alarm_head;
					next = curr->next;
					if( alarm_time_is_bigger( next, alarm)) {
						__set_alarm( rtc_alarm_head->alarm_time, rtc_alarm_head->alarm_ms);
						return RTC_OK;
					} else {
						rtc_alarm_head = next;
						__set_alarm(rtc_alarm_head->alarm_time, rtc_alarm_head->alarm_ms);
						if( insert_alarm_in_list( alarm ) == 0 ) {
							return RTC_OK;
						} else {
							return RTC_ERROR;
						}
					}
				} else {
					alarm->state = RUNNING;
					__set_alarm(rtc_alarm_head->alarm_time, rtc_alarm_head->alarm_ms);
					return RTC_OK;
				}
			} else {
				if( alarm_time_is_bigger(rtc_alarm_head, alarm)) {
					//alarm->id = alarm_id;
					alarm_id++;
					alarm->next = rtc_alarm_head;
					rtc_alarm_head = alarm;
					alarm->state = RUNNING;
					__set_alarm(rtc_alarm_head->alarm_time, rtc_alarm_head->alarm_ms);
					return RTC_OK;
				} else {
					if( insert_alarm_in_list( alarm ) == 0 ) {
						return RTC_OK;
					} else {
						return RTC_ERROR;
					}
				}
			}
		} else {						// insert alarm as head and start it
			//alarm->id = alarm_id;
			alarm_id++;
			alarm->next = NULL;
			alarm->state = RUNNING;
			rtc_alarm_head = alarm;
			__set_alarm( rtc_alarm_head->alarm_time, rtc_alarm_head->alarm_ms);
			return RTC_OK;
		}
	} else {
		return RTC_ERROR;
	}
}

/*
 * See header file
 */
void rtc_remove_alarm( rtc_alarm_t *alarm )
{
	rtc_alarm_t *prev = NULL;
	if( rtc_alarm_head == alarm ) {
		if( rtc_alarm_head->next == NULL ) {	// was the last alarm
			rtc_alarm_head->state = STOPPED;
			rtc_alarm_head = NULL;
			__reset_alarm( );
		} else if ( rtc_alarm_head->next->state != RUNNING ) {
			rtc_alarm_head->state = STOPPED;
			rtc_alarm_head = NULL;
			__reset_alarm( );
		} else {
			rtc_alarm_head = rtc_alarm_head->next;
			__set_alarm( rtc_alarm_head->alarm_time, rtc_alarm_head->alarm_ms );
		}
	} else {
		prev = rtc_alarm_head;
		while( 1 ) {
			if( prev->next == alarm ){
				if( alarm->next != NULL ) {
					prev->next = alarm->next;
					alarm->state = STOPPED;
					alarm = NULL;
				} else {
					alarm->state = STOPPED;
					alarm = NULL;
					prev->next = NULL;
				}
			} else {
				if( prev->next != NULL ) {
					prev = prev->next;
				} else {	// end of list reached
					break;
				}
			}
		}
		alarm->state = STOPPED;
		alarm = NULL;
	}
}

/*
 * See header file
 */
static void __set_alarm ( rtc_utc_t alarmtime, uint16_t millisecs )
{
	// TODO: handling of subseconds
	rtc_utc_t temp_utc = alarmtime;
	rtc_timedate_s temp_timedat;
	utc_to_rtc_timedat( &temp_timedat, &temp_utc );
	temp_timedat.time.milisecond = millisecs;
	rtc_hal_set_alarm( &temp_timedat, rtc_hal_alrm_callback );

}

static void __reset_alarm( void )
{
	rtc_hal_reset_alarm( );
}

/* internal functions definitions ------------------------------------------ */

/**
 *  \brief  Alarm callback function
 */
static void rtc_hal_alrm_callback( void )
{
	rtc_alarm_t *ellapsed;
	rtc_alarm_t *next;
	rtc_utc_t temptime = 0;
	uint16_t temptime_ms = 0;

	if( (rtc_alarm_head != NULL) && (rtc_alarm_head->state == RUNNING)){
		ellapsed = rtc_alarm_head;
		next = rtc_alarm_head->next;
		if( ellapsed->alarm_cb != NULL ){
			ellapsed->alarm_cb();
		} else {
			// TODO: Call ERROR
			MCU_Error_Handler( );
		}
		ellapsed->state = STOPPED;
		ellapsed->next = NULL;
		if((next != NULL) && (next->state == RUNNING) ) {
			rtc_get_time_date( &temptime, &temptime_ms );
			if( alarm_time_is_later_then_systime( next )){
				rtc_alarm_head = next;
				__set_alarm( rtc_alarm_head->alarm_time, rtc_alarm_head->alarm_ms);

			} else {
				// TODO Call Error
			}

		} else {
			rtc_alarm_head = NULL;
			rtc_alarm_head->state = STOPPED;
		}
	} else {
		MCU_Error_Handler( );
	}
}

/**
 *  \brief  Converts a 32-bit utc time to a timedat struct
 */
static void utc_to_rtc_timedat ( rtc_timedate_s *timdat, rtc_utc_t *utc )
{
	struct tm *time_s;
	time_s = gmtime( utc );			//UTC otherwise localtime
	// fill weekday with mktime
	if( time_s->tm_wday == 0 ){
		timdat->date.wday = (uint8_t)7;
	} else {
		timdat->date.wday = (uint8_t)( time_s->tm_wday);
	}
	timdat->date.date = (uint8_t)( time_s->tm_mday);
	timdat->date.month = (uint8_t)( time_s->tm_mon + 1);
	timdat->date.year = (uint8_t)( time_s->tm_year - 100 );
	timdat->time.hour = time_s->tm_hour;
	timdat->time.minute = time_s->tm_min;
	timdat->time.second = time_s->tm_sec;
	timdat->time.milisecond =  0;
}

/**
 *  \brief  Converts a timedat struct to a  32-bit utc time
 */
static void timedat_to_utc ( rtc_utc_t *utc, rtc_timedate_s *timdat)
{
	struct tm time_s;
	time_s.tm_mday = (int)timdat->date.date;
	time_s.tm_mon =  (int)(timdat->date.month - 1);
	time_s.tm_year = (int)(timdat->date.year + 100);
	time_s.tm_sec = (int)timdat->time.second;
	time_s.tm_min = (int)timdat->time.minute;
	time_s.tm_hour = (int)timdat->time.hour;
	if((*utc = mktime(&time_s)) == -1) { //error
		utc = utc + 10;
	}

}

/*
 * 	\brief	Compares two alarm times including milliseconds
 * 	\param	*ref:	Alarm time to be checked
 * 	\param	*comp:	Comparison value
 * 	\return	returns 1 wenn ref > comp, zero otherwise
 */
static uint8_t alarm_time_is_bigger( rtc_alarm_t *ref, rtc_alarm_t *comp )
{
	if( ref->alarm_time > comp->alarm_time ) {
		return 1;
	} else 	if( ref->alarm_time == comp->alarm_time ) {
		if( ref->alarm_ms > comp->alarm_ms ) {
			return 1;	 // bigger
		} else if( ref->alarm_ms == comp->alarm_ms ) {
			return 0;	// equal
		} else {
			return 0;
		}
	} else {
		return 0;
	}
}

/**
 * 	\brief	Checks if a given alarm time is later than current system time
 * 	\param	*alarm: alarm time to be checked
 * 	\return	returns 1 when *alarm is later than current system time,
 * 			zero otherwise
 */
static uint8_t alarm_time_is_later_then_systime( rtc_alarm_t *alarm )
{
	rtc_utc_t temptime;
	uint16_t temp_ms;
	rtc_get_time_date( &temptime, &temp_ms );
	if( alarm->alarm_time > temptime ) {
		return 1;
	} else if( alarm->alarm_time == temptime ) {
		if( alarm->alarm_ms > (temp_ms + SAFETY_OFFSET_MS)) {
			return 1;
		} else {
			return 0;
		}
	} else {
		return 0;
	}
}

/**
 * 	\brief	Inserts an alarm in the list
 * 	\param	*alarm: alarm to be inserted into the list
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t insert_alarm_in_list( rtc_alarm_t *alarm)
{
	rtc_alarm_t *curr, *next;
	curr = rtc_alarm_head;
	next = curr->next;

	// if alarm is in list, delete it
	while( 1 ) {
		if( (next != NULL) && (next->state == RUNNING)) {
			if( next == alarm ) {
				if( alarm->next->state == RUNNING ){
					curr->next = alarm->next;
					break;
				} else {
					curr = next;
					next = curr->next;
				}
			} else {
				curr = next;
				next = curr->next;
			}
		} else {
			break;
		}
	}

	// insert alarm new in list
	curr = rtc_alarm_head;
	next = curr->next;
	while (1) {
		if( (next != NULL) && (next->state == RUNNING)) {
			if( alarm_time_is_bigger( next, alarm )) {
				//alarm->id = alarm_id;
				alarm_id++;
				curr->next = alarm;
				alarm->next = next;
				break;
			} else {
				curr = next;
				next = curr->next;
			}
		} else {
			//alarm->id = alarm_id;
			alarm_id++;
			curr->next = alarm;
			alarm->next = NULL;
			break;
		}
	}
	alarm->state = RUNNING;
	return 0;
}
