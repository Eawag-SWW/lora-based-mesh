/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		rtc_hal.c
 *
 * \description	HAL layer used for the RTC module
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		20.01.2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "rtc_hal.h"
#include "stm32l4xx_hal.h"
#include "utilities.h"
/* -- makros ----------------------------------------------------------------*/
/** RTC configuration
 *
 */
#define PREDIV_A	31			// asynchronous prescaler value
#define PREDIV_S	1023		// synchronous  prescaler value

/**  RTC AM or PM format selection
 *   0: AM/24h
 *	 1: PM
 */
#define RTC_PM_EN				 0

/** define which masks should be set or not
 * 	0: not masked (value is compared with RTC time value)
 * 	1: masked (value is NOT compared with RTC time value)
 */
#define ALRM_DATE_MASK_EN		 0	// date
#define ALRM_HOUR_MASK_EN		 0	// hour
#define ALRM_MIN_MASK_EN		 0	// minutes
#define ALRM_SEC_MASK_EN		 0 	// seconds
#define ALRM_SSEC_MASK_EN		 0	// subseconds

/** define if weekday or date should be compared for alarm interrupt
 * 	0: date value is compared
 * 	1: weekday (MON to SUN) are compared
 */
#define ALRM_WDSEL				 0	// date is selected
//--end configuration----------------------------------------------------------

#define F_RTC			32768		// Frequency of the RTC clock in Hz
#define RTC_SS_FREQ		1024		/** Clock frequency for the Subsecond
									 *	downcounter
									 */
#define RTC_SSTICK_PER_S   1024
#define RTC_SSTICK_PER_MS 1.024

// mask values uesd for RTC configuraion (do not modify)
#define RTC_SEC_MASK 	0x0000007F
#define RTC_MIN_MASK 	0x00007F00
#define RTC_HOUR_MASK 	0x003F0000
#define RTC_DAT_MASK 	0x0000003F
#define RTC_MON_MASK 	0x00001F00
#define RTC_WD_MASK 	0x0000E000
#define RTC_YR_MASK 	0x00FF0000

// bitshift values for RTC configuration (do not modify)
#define RTC_SEC_SH				 0
#define RTC_MIN_SH				 8
#define RTC_HOUR_SH				16
#define RTC_PM_SH				22
#define RTC_DAT_SH				 0
#define RTC_MON_SH				 8
#define RTC_WD_SH				13
#define RTC_YR_SH				16

// default weekday (not used)
#define RTC_WD_MON				 1

// register values used for configuration
#define RTC_TR_PM_EN	(RTC_PM_EN << RTC_PM_SH)
#define RTC_DR_WD_DEFAULT  (RTC_WD_MON << RTC_WD_SH)

// bitshift values for alarm configuration (do not modify)
#define ALRM_DATE_MASK_SH		31
#define ALRM_HOUR_MASK_SH		23
#define ALRM_MIN_MASK_SH 		15
#define ALRM_SEC_MASK_SH		 7
#define ALRM_WDSEL_SH			30
#define ALRM_SEC_SH				 0
#define ALRM_MIN_SH				 8
#define ALRM_HOUR_SH			16
#define ALRM_DAT_SH				24

#define ALRM_SS_MASK			0x00007FFF

// register values for alarm configuration (do not modify)
#define ALRxR_DATE_MASK		( ALRM_DATE_MASK_EN << ALRM_DATE_MASK_SH)
#define ALRxR_HOUR_MASK		( ALRM_HOUR_MASK_EN << ALRM_HOUR_MASK_SH)
#define ALRxR_MIN_MASK		( ALRM_MIN_MASK_EN << ALRM_MIN_MASK_SH)
#define ALRxR_SEC_MASK		( ALRM_SEC_MASK_EN << ALRM_SEC_MASK_SH)
#define ALRxR_WDSEL			( ALRM_WDSEL << ALRM_WDSEL_SH)


/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */
//static void rtc_hal_init_clocks ( void );
static inline uint16_t compute_milisecond_to_subsecond_ticks( uint16_t ms);
static inline uint16_t compute_subsecond_ticks_to_miliseconds ( uint16_t ticks);
static inline void disable_wpr ( void );
static inline void enable_wpr ( void );
 
/* internal variable definitions ------------------------------------------- */ 
RTC_HandleTypeDef hrtc;

void (*callback_fct) ( void );
/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
void rtc_hal_init ( void )
{
	__HAL_RCC_RTC_ENABLE();
	//rtc_hal_init_clocks();

	disable_wpr( );
	RTC->ISR |= RTC_ISR_INIT;	// set RTC to init mode
	while((RTC->ISR & RTC_ISR_INITF) != RTC_ISR_INITF){
	}
	// set prescaler
	RTC->PRER = (((uint32_t)PREDIV_A << 16) & RTC_PRER_PREDIV_A) |
				(((uint32_t)PREDIV_S) & RTC_PRER_PREDIV_S);
	RTC->DR = (uint32_t)0;
	RTC->TR = (uint32_t)0;
	RTC->SSR = (uint32_t)PREDIV_S;
	RTC->CR |= RTC_CR_BYPSHAD;
	RTC->ISR &=~ RTC_ISR_INIT;	// exit init status
	enable_wpr( );
}

/*
 * See header file
 */
void rtc_hal_set_time_date (rtc_timedate_s *datetime)
{
	uint16_t temp;
	disable_wpr( );
	RTC->ISR |= RTC_ISR_INIT;
	while((RTC->ISR & RTC_ISR_INITF) != RTC_ISR_INITF){
	}

	RTC->TR =   (RTC_TR_PM_EN |
			    (((uint32_t)byte_to_bcd(datetime->time.second)) << RTC_SEC_SH) |
			    (((uint32_t)byte_to_bcd(datetime->time.minute)) << RTC_MIN_SH) |
			    (((uint32_t)byte_to_bcd(datetime->time.hour)) << RTC_HOUR_SH));
	RTC->DR =  ((((uint32_t)byte_to_bcd(datetime->date.date)) << RTC_DAT_SH)|
			   (((uint32_t)byte_to_bcd(datetime->date.month)) << RTC_MON_SH) |
			   (((uint32_t)byte_to_bcd(datetime->date.wday)) << RTC_WD_SH) |
			   (((uint32_t)byte_to_bcd(datetime->date.year)) << RTC_YR_SH));

	// advance the RTC time using the shift register
	temp = (1000 - datetime->time.milisecond) * RTC_SSTICK_PER_MS;
	RTC->SHIFTR |= (0x80000000 | temp);
	RTC->ISR &=~ RTC_ISR_INIT;
	enable_wpr( );

	// configre EXTI line 18 interrupt (RTC interrupt)
	EXTI->IMR1  |= 0x00040000;		// enable interrupt
	EXTI->RTSR1 |= 0x00040000;		// set RTC IRQ to rising edge
	return;

}

/*
 * See header file
 */
void rtc_hal_get_time_date ( rtc_timedate_s *datetime)
{
	volatile uint32_t DR = 0;
	volatile uint32_t TR = 0;
	volatile uint32_t SSR = 0;
	volatile uint32_t tempval = 0;

	TR = RTC->TR;
	DR = RTC->DR;
	SSR = RTC->SSR;
	tempval = RTC->TR;
	if( TR != tempval ){	// RTC clock edge occured during read operation
		TR = RTC->TR;		// --> update values
		DR = RTC->DR;
		SSR = RTC->SSR;
	}
	datetime->date.date = bcd_to_byte((uint8_t)((DR & RTC_DAT_MASK) >> RTC_DAT_SH));
	datetime->date.month = bcd_to_byte((uint8_t)((DR & RTC_MON_MASK) >> RTC_MON_SH));
	datetime->date.year = bcd_to_byte((uint8_t)((DR & RTC_YR_MASK) >> RTC_YR_SH));
	datetime->date.wday = bcd_to_byte((uint8_t)((DR & RTC_WD_MASK) >> RTC_WD_SH));
	datetime->time.second = bcd_to_byte((uint8_t)((TR & RTC_SEC_MASK) >> RTC_SEC_SH));
	datetime->time.minute = bcd_to_byte((uint8_t)((TR & RTC_MIN_MASK) >> RTC_MIN_SH));
	datetime->time.hour = bcd_to_byte((uint8_t)((TR & RTC_HOUR_MASK) >> RTC_HOUR_SH));
	if( SSR > PREDIV_S ){
		tempval = SSR;
	} else {
		tempval = PREDIV_S - SSR;
	}
	datetime->time.milisecond = compute_subsecond_ticks_to_miliseconds(tempval);
	return;
}

/*
 * See header file
 */
void rtc_hal_set_alarm ( rtc_timedate_s *alarm, void (*callback)( void ))
{
	uint16_t num_ss = 0;
	if( callback == NULL){
		return;
	}
	callback_fct = callback;
	HAL_NVIC_DisableIRQ(RTC_Alarm_IRQn);
	disable_wpr( );

	// disable the alarm
	RTC->CR &=~ (RTC_CR_ALRAE | RTC_CR_ALRAIE);
	RTC->ALRMAR = ( ALRxR_DATE_MASK | ALRxR_HOUR_MASK | ALRxR_MIN_MASK |
			        ALRxR_SEC_MASK | ALRxR_WDSEL |
				(((uint32_t)byte_to_bcd(alarm->date.date)) << ALRM_DAT_SH) |
				(((uint32_t)byte_to_bcd(alarm->time.hour)) << ALRM_HOUR_SH) |
				(((uint32_t)byte_to_bcd(alarm->time.minute)) << ALRM_MIN_SH) |
				(((uint32_t)byte_to_bcd(alarm->time.second)) << ALRM_SEC_SH));
	RTC->ALRMASSR = (uint32_t) 0;
	num_ss = compute_milisecond_to_subsecond_ticks(alarm->time.milisecond);
	RTC->ALRMASSR |= ((PREDIV_S - num_ss) & ALRM_SS_MASK);
#if ALRM_SSEC_MASK_EN
	RTC->ALRMASSR &=~ 	0x0F000000;
#else
	RTC->ALRMASSR |= 	0x0F000000;
#endif

	RTC->ISR &=~ RTC_ISR_ALRAF;
	RTC->CR |= (RTC_CR_ALRAE | RTC_CR_ALRAIE);
	RTC->ISR &=~ RTC_ISR_INIT;
	enable_wpr( );

	EXTI->PR1 |= 0x00040000;		// clear pending EXTI line interrupt

	// configure NVIC
	HAL_NVIC_SetPriority(RTC_Alarm_IRQn, 11, 0);
	HAL_NVIC_ClearPendingIRQ(RTC_Alarm_IRQn);
	HAL_NVIC_EnableIRQ(RTC_Alarm_IRQn);
}

/*
 * See header file
 */
void rtc_hal_reset_alarm( void )
{
	HAL_NVIC_DisableIRQ( RTC_Alarm_IRQn );
	disable_wpr( );
	RTC->CR &=~ ( RTC_CR_ALRAE | RTC_CR_ALRAIE );
	enable_wpr( );
}

/*
 *	 RTC alarm irq handler
 */
void RTC_Alarm_IRQHandler ( void )
{
	if((RTC->ISR & RTC_ISR_ALRAF) == RTC_ISR_ALRAF){
		disable_wpr( );
		RTC->ISR &=~ RTC_ISR_ALRAF;
		while( (RTC->ISR & RTC_ISR_ALRAF) != 0x00 ) {

		}
		enable_wpr( );
		EXTI->PR1 |= 0x00040000;	// clear pending EXTI line interrupt
		while( (EXTI->PR1 & EXTI_PR1_PIF18 ) != 0x00) {

		}
		NVIC_ClearPendingIRQ(RTC_Alarm_IRQn);
		callback_fct( );
	}
}

/* internal functions definitions ------------------------------------------ */

/**
 *  \brief  Computes the number of subsecond ticks according to desired
 *  		time value in miliseconds
 *  \param	ms:	milisecond value
 *  \return returns number of subsecond ticks
 */
static inline uint16_t compute_milisecond_to_subsecond_ticks( uint16_t ms)
{
	return (ms * RTC_SSTICK_PER_S) / 1000;
}

/**
 *  \brief  Computes the millisecond value according to sub seconds value
 *	\param	ticks:	sub second value
 *  \return returns millisecond value
 */
static inline uint16_t compute_subsecond_ticks_to_miliseconds ( uint16_t ticks)
{
	return ( ticks / RTC_SSTICK_PER_MS);
}

/**
 *  \brief  Enables the RTC write protection (see reference manual p. 1073)
 */
static inline void enable_wpr ( void )
{
	RTC->WPR = 0x11;			// enable write protection (write wrong value)
	PWR->CR1 &=~ PWR_CR1_DBP;
}

/**
 *  \brief  Disables the RTC write protection (see reference manual p. 1073)
 */
static inline void disable_wpr ( void )
{
	PWR->CR1 |= PWR_CR1_DBP;
	RTC->WPR = 0xCA;
	RTC->WPR = 0x53;
}

