/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		filter_median.c
 *
 * \description	Median Filter implementation
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "filter_median.h"
#include "stdlib.h"
#include "cmsis_os.h"

/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */

/* internal variable definitions ------------------------------------------- */ 

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint16_t filter_median( uint16_t *pbuffer, uint8_t nsamples)
{
	uint16_t ret = 0;
	uint16_t *tbuffer = NULL;
	uint8_t	sample_cnt = 0;
	uint8_t i = 0;
	uint8_t j = 0;
	uint32_t sum;

	// free exising buffer (should never occure)
	if( tbuffer != NULL ){
		vPortFree( tbuffer );
	}
	// allocate a temporary buffer and initialize its values with 0
	tbuffer = pvPortMalloc( sizeof(uint16_t) * nsamples );
	if( tbuffer == NULL ){
		return 0;				// something went wrong
	}
	for( i=0; i<nsamples; i++ ){
		*(tbuffer + i) = 0;
	}

	// sort data according their value
	*tbuffer = *pbuffer;
	for( sample_cnt = 1; sample_cnt < nsamples; sample_cnt++ ){
		for( i = 0; i<= sample_cnt; i++ ){
			if( *(pbuffer + sample_cnt) < *(tbuffer + i)){
				// shift existing values one position to the right
				j = nsamples;
				while( 1 ){
					*(tbuffer + j) = *(tbuffer + j - 1);
					j--;
					if( j == i ){
						break;
					}
				}
				*(tbuffer + i) = *(pbuffer + sample_cnt );
				break;
			}
			if( i == sample_cnt ){
				// insert value at the end
				*(tbuffer + i ) = *(pbuffer + sample_cnt );
			}
		}
	}

	// get resulting median value from the temporary buffer
	if( nsamples & 0x01 ){
		// odd samples --> take the middle value
		ret = *(tbuffer + (nsamples/2));
	} else {
		// even samples --> take the two values in the middle
		sum = *(tbuffer + (nsamples/2)) + *(tbuffer + (nsamples/2) - 1);
		sum>>=1;
		ret = (uint16_t)sum;
	}
	vPortFree( tbuffer );
	return ret;
}


/* internal functions definitions ------------------------------------------ */

