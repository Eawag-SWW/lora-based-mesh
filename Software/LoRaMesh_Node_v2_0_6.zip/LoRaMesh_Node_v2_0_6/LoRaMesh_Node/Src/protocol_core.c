/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		protocol_core.c
 *
 * \description	This is the main control element of the whole software.
 * 				The protocol core is responsible for handling tasks
 * 				and compute requests and responses
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "protocol_core.h"
#include "task_run.h"
#include "device_config.h"
#include "protocol_config.h"
#include "cmsis_os.h"
#include "proc_join.h"
#include "loramesh.h"
#include <string.h>
#include <stdlib.h>
#include "cycler.h"
#include "proc_sync.h"
#include "proc_join.h"
#include "leds.h"
#include "beacon_window_handler.h"
#include "subslot_handler.h"
#include "proc_communication.h"
#include "stm32l4xx.h"
#include "rtc.h"
#include "debug/debug.h"
#include "log/log.h"
#include "proc_lorawan.h"
#include "utilities.h"
#include "proc_measure.h"
#include "rng.h"
#include "power_switches/power_switches.h"
#include "timesource/timesource.h"
#include "buttons.h"
#include "ldo.h"
#include "sensors.h"
#include "iwdg.h"
/* -- makros ----------------------------------------------------------------*/

/* -- type definitions-------------------------------------------------------*/
typedef enum {
	TASK_TYPE_SYNC = 0,
	TASK_TYPE_APPROVE,
	TASK_TYPE_JOIN,
	TASK_TYPE_DL_TX,
	TASK_TYPE_DL_RX,
	TASK_TYPE_UL_TX,
	TASK_TYPE_UL_RX,
	TASK_TYPE_WAN,
	TASK_TYPE_MEASURE
} task_type_t;

/* -- OS globals			*/
extern osThreadId runTaskHandle;

/* internal function declarations ------------------------------------------ */
static void ptk_core_task_handler(TCyTask *task, uint32_t ts);
static void pkt_core_reset_state(void);
static uint8_t ptk_create_routing_tree_root(uint16_t address);
static uint8_t ptk_create_routing_tree_entry(	uint16_t parent_address,
												uint16_t new_address);
static uint8_t ptk_routing_tree_get_ul_slot(uint16_t address);
static uint8_t ptk_routing_tree_get_dl_slot(uint16_t address);
static uint16_t ptk_routing_tree_get_parent_address(uint16_t naddr);
static uint8_t ptk_delete_routing_tree_entry(uint16_t naddr);
static void ptk_reset_routing_tree(void);
static uint8_t timeslots_init(void);
static uint8_t timeslot_register_root_slots(uint16_t address, uint8_t *dl,
											uint8_t *ul);
static uint8_t timeslot_get_free(uint16_t addr, uint8_t *s_ul, uint8_t *s_dl);
static uint8_t timeslot_delete_slot(uint16_t addr);
static uint8_t timeslot_reset_slots(void);
static uint8_t add_to_ignore_list(uint16_t ignore_addr);
static uint8_t remove_from_ignore_list(uint16_t remove_address);
static uint8_t clear_ignore_list(void);
static uint8_t is_in_ignore_list(uint16_t addr);

/** LoRaMesh callback functions	*/
static void mesh_on_beacon_received(loramesh_sync_s *sync);
static void mesh_on_tx_done(void);
static void mesh_on_rx_done(loramesh_rx_data_s *rx_data);
static void mesh_on_rx_error(void);
static void mesh_on_tx_error(void);
static void mesh_on_jreq_received(uint16_t src_addr);
static void mesh_on_jresp_received(loramesh_joinresp_s *rsp);
static void mesh_on_conf_received(loramesh_conf_t conf);

static uint8_t WAN_do_OTAA(void);

/* internal variable definitions ------------------------------------------- */
static ptk_core_state_s ptk_core_state; /** state of the protocol core		 */
/** buffer for storing latest packets received over LoRaMesh				 */
static loramesh_sync_s mesh_sync_data;
static loramesh_rx_data_s mesh_rx_data;
static loramesh_conf_t mesh_confirmation = LORAMESH_NACK;
static uint16_t mesh_joinee_address;
static loramesh_joinresp_s mesh_joinresp_data;
/** variable for store mesh callback functions								 */
static loramesh_callbacks_s mesh_cbs;
static uint16_t num_ul_slots = 0; /** buffer stores number of uplink slots 	 */
static uint16_t num_dl_slots = 0; /** buffer stores number of downlink slots */

/** variables used for handling ignore list									 */
static uint16_t *ignore_list;
static uint8_t num_ignore_enties = 0;

/** counter used for beacon timeout											 */
static uint8_t beacon_search_timeout_cnt = 0;

/** buffers used for storing latest measurement data and timestamp		 	 */
static uint16_t latest_meas_data;
static uint32_t latest_meas_ts;
static uint16_t latest_battery_voltage;
static uint8_t latest_senstype;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
ptk_errors_t ptk_core_init(void) {
	// Peripheral initialization
	ldo_init();
	power_switch_init();
	LEDS_Init();
	rtc_init();
	buttons_init();
	debug_gpio_init();
	dbgPrintf("Peripherals initialized\n");
	// Write device config on uart
	dbgPrintf("Device configuration:\n");
	char str_code_version[64];
	strcpy(str_code_version, "- CODE_VERSION: ");
	strcat(str_code_version,CODE_VERSION);
	strcat(str_code_version,"\n");
	dbgPrintf(str_code_version);
#ifdef DEV_IS_NODE
	dbgPrintf( "- DEVICE_TYPE: NODE\n");
#endif
#ifdef DEV_IS_REPEATER
	dbgPrintf("- DEVICE_TYPE: REPEATER\n");
#endif

	dbgPrintf("- DEVICE_ADDR_LORAMESH: %h %h \n",
			(DEVICE_ADDR_LORAMESH >> 8) & 0xFF, DEVICE_ADDR_LORAMESH & 0xFF); //TODO: display true 4 digit hex number

	if (SENSOR_TYPE == NO_SENSOR) {
		dbgPrintf("- SENSOR_TYPE: NO_SENSOR\n");
	} else if (SENSOR_TYPE == MB7389) {
		dbgPrintf("- SENSOR_TYPE: MB7389\n");
	} else if (SENSOR_TYPE == MB7369) {
		dbgPrintf("- SENSOR_TYPE: MB7369\n");
	} else if (SENSOR_TYPE == DS18B20) {
		dbgPrintf("- SENSOR_TYPE: DS18B20\n");
	}

#if USE_DBG_IN_STOPMODE == 0
	dbgPrintf("- USE_DBG_IN_STOPMODE: 0\n");
#else
	dbgPrintf( "- USE_DBG_IN_STOPMODE: 1\n");
#endif

#if SD_LOG == SD_LOG_NONE
	dbgPrintf( "- SD_LOG: NONE\n");
#elif SD_LOG == SD_LOG_SENS
	dbgPrintf( "- SD_LOG: SD_LOG_SENS\n");
#elif SD_LOG == SD_LOG_DBG
	dbgPrintf( "- SD_LOG: SD_LOG_DBG\n");
#elif SD_LOG == SD_LOG_SENS_DBG
	dbgPrintf("- SD_LOG: SD_LOG_SENS_DBG\n");
#endif
	FRESULT fResult = log_status();
	if (fResult == FR_OK) {
		dbgPrintf("- SD_STATUS: SD_READY\n");
	} else {
		dbgPrintf("- SD_STATUS: ERROR_CODE %i\n", fResult);
	}

#if USE_LORAWAN == 0
	dbgPrintf( "- USE_LORAWAN: 0\n");
#else
	dbgPrintf("- USE_LORAWAN: 1\n");
#endif

#if LORAWAN_PARAM == LORAWAN_PARAM_EAWAG
	dbgPrintf("- LORAWAN_PARAM: EAWAG\n");
#elif LORAWAN_PARAM == LORAWAN_PARAM_INES
	dbgPrintf( "- LORAWAN_PARAM: INES\n");
#endif

#if USE_LOWPOWER == 0
	dbgPrintf( "- USE_LOWPOWER: 0\n");
#else
	dbgPrintf("- USE_LOWPOWER: 1\n");
#endif

#if TIMESOURCE == TIMESOURCE_NONE
	dbgPrintf( "- TIMESOURCE: NONE\n");
#elif TIMESOURCE == TIMESOURCE_GPS
	dbgPrintf("- TIMESOURCE: GPS\n");
#elif TIMESOURCE == TIMESOURCE_DCF77
	dbgPrintf( "- TIMESOURCE: DCF77\n");
#endif

#if SETUP_TESTBENCH == 0
	dbgPrintf("- SETUP_TESTBENCH: 0\n");
#else
	dbgPrintf( "- SETUP_TESTBENCH: 1\n");
#endif

#if NETWORK_MODE == NETWORK_MODE_MESH
	dbgPrintf( "- NETWORK_MODE: MESH\n");
#elif NETWORK_MODE == NETWORK_MODE_STAR
	dbgPrintf("- NETWORK_MODE: STAR\n");
#endif

#ifdef DEV_IS_NODE
	//Print device configuration with wrong timestamp. Writing to SD Card inside cycle can
	// interrupt timing
	debug_log_device_configuration();
#endif

	if (ptk_set_config(PTK_MODE_TEST) != 0) {
		return PTK_ERR_CONFIG;
	}
	if (timeslots_init() != 0) {
	}
	if (subslot_handler_init(ptk_get_num_network_nodes()) != 0) {
		//TODO: error handling
	}
	ptk_core_state.state = PTK_STATE_RESET;
	ptk_core_state.device_type = DEV_TYPE_UNKNOWN;
	ptk_core_state.hop_count = HOP_COUNT_RESET_VAL;
	ptk_core_state.link_quality = LINK_QUALITY_RESET_VAL;
	ptk_core_state.subnet_id = SUBNET_ID_RESET_VAL;
	ptk_core_state.beacon_window = BEACON_WINDOW_RESET_VAL;
	ptk_core_state.slot_ul = SLOT_UL_RESET_VAL;
	ptk_core_state.slot_dl = SLOT_DL_RESET_VAL;
	ptk_core_state.slot_parent_ul = SLOT_PARENT_UL_RESET_VAL;
	ptk_core_state.address = DEVICE_ADDR_LORAMESH;
	ptk_core_state.routing_tree = NULL;
	ptk_core_state.routing_item = NULL;
	ptk_core_state.join_agent.role = JOIN_ROLE_NONE;
	ptk_core_state.join_agent.type = JOIN_TYPE_NONE;

	mesh_cbs.cb_beacon_received = mesh_on_beacon_received;
	mesh_cbs.cb_confirmation_received = mesh_on_conf_received;
	mesh_cbs.cb_join_req_received = mesh_on_jreq_received;
	mesh_cbs.cb_join_resp_received = mesh_on_jresp_received;
	mesh_cbs.cb_rx_done = mesh_on_rx_done;
	mesh_cbs.cb_rx_error = mesh_on_rx_error;
	mesh_cbs.cb_tx_done = mesh_on_tx_done;
	mesh_cbs.cb_tx_error = mesh_on_tx_error;

	power_switch_control(PS_SX1276, PS_ON);
	loramesh_init(ptk_core_state.address, &mesh_cbs);
	cyRegisterTaskHandler(ptk_core_task_handler);
	return PTK_OK;
}

/*
 * See header file
 */
ptk_errors_t ptk_set_device_type(dev_type_t type) {
	ptk_core_state.device_type = type;
	return PTK_OK;
}

/*
 * 	See header file
 */
ptk_errors_t ptk_before_lp(void) {
	if (ptk_core_state.state == PTK_STATE_RESET) {
		if (ptk_init_sync() == PTK_OK) {
			return PTK_OK;
		} else {
			return PTK_ERR_UNSPECIFIED;
		}
	}
	return PTK_OK;
}

/**	asynchronous tasks ( not schedulded by the cycle )	*/
/*
 * 	See header file
 */
ptk_errors_t ptk_init_sync(void) {
	uint32_t temp_time = 0;
	TCyTask task;

	/** checking connection to a LoRaWAN gateway	*/
	if (WAN_do_OTAA() == 0) {			// wan connection found
		ptk_set_device_type(DEV_TYPE_REPEATER);
	} else {
		ptk_set_device_type(DEV_TYPE_NODE);
	}

	switch (ptk_core_state.device_type) {
	case (DEV_TYPE_REPEATER):
		LED_gn_on();
		timesource_actualice_rtc_time();
#if USE_LORAWAN == 1
		power_switch_control(PS_IM880B, PS_ON);
		if (lorawan_init() != 0) {
			LED_ora_on();
			return PTK_ERR_UNSPECIFIED;
		}
#endif
		temp_time = rng_get_random_number();
		temp_time &= 0x00003FFF;		// take only lowest 12 bit
										// leads to a range of 0..16384
		dbgPrintf( "wait: %i\n",temp_time);
		osDelay( temp_time );
		temp_time = ptk_proc_rep_init_sync( &ptk_core_state,
					(ptk_get_cycle_duration_s( ) *1000)+
					(ptk_get_slot_duration_ms() * (ptk_get_nsync()))
					);
		if( temp_time == 0 ) {
			cySetStartTimeRel( 1000 );
		} else {
			cySetNextPossibleStart( temp_time, 0);
		}
		ptk_core_state.hop_count = 0;
		if( beacon_window_handler_init(ptk_get_num_network_nodes() + 1) != 0 ){
			//TODO: error handling
		}
		if(	beacon_window_handler_register_window( 0, ptk_core_state.address) != 0){
			//TODO: error handling
			return PTK_ERR_UNSPECIFIED;
		}
		ptk_core_state.subnet_id = (uint8_t)(ptk_core_state.address >> 8);
		ptk_core_state.subnet_id |= (uint8_t)(ptk_core_state.address);
		ptk_core_state.beacon_window = 0;
		cyInitPrototype( &task );
		task.slot = 0;
		task.subslot = 0;
		task.type = TASK_TYPE_SYNC;
		task.wakeup_offset_ms = 0;
		cyRegisterTask( &task );
		ptk_core_state.state = PTK_STATE_IN;
		cyInitPrototype( &task );
		task.type = TASK_TYPE_JOIN;
		task.slot = ptk_get_nsync( );
		task.subslot = 0;
		task.wakeup_offset_ms = ptk_get_sync_rx_offset();
		cyRegisterTask( &task );
		ptk_create_routing_tree_root( ptk_core_state.address );
		task.type = TASK_TYPE_UL_RX;
		task.slot = ptk_get_nsync() + ptk_get_njoin() + ptk_get_napprove();
		task.slot += ptk_routing_tree_get_ul_slot( ptk_core_state.address );
		task.subslot = 0;
		task.wakeup_offset_ms = ptk_get_sync_rx_offset();
		cyRegisterTask( &task );
#if USE_LORAWAN == 1
		task.type = TASK_TYPE_WAN;
		task.slot = ptk_get_nsync() + ptk_get_njoin() + ptk_get_napprove()
				+ ptk_get_nuplink() + ptk_get_ndownlink();
		task.subslot = 0;
		cyRegisterTask(&task);
#endif
		LED_ora_off();
		LED_gn_off();
		break;
	case (DEV_TYPE_NODE):
		while (1) {
			LED_gn_on();
			temp_time = ptk_proc_node_init_sync(&ptk_core_state,
					ptk_get_cycle_duration_s() * 1000);
			if (temp_time == 0) {
				// no beacon found
				if (beacon_search_timeout_cnt > 2) {
					dbgPrintf("Max beacon search timeouts\n");
					debug_log_append_line("Max beacon search timeouts\n"); //TODO: check timing
					NVIC_SystemReset();
				} else {
					beacon_search_timeout_cnt++;
				}
				osDelay(1000);
			} else {
				// beacon found
				ptk_core_state.state = PTK_STATE_JOINING;
				cySetNextPossibleStart(temp_time, 0);
				cyInitPrototype(&task);
				task.slot = 0;
				task.subslot = 0;
				task.type = TASK_TYPE_SYNC;
				task.wakeup_offset_ms = ptk_get_sync_rx_offset();
				cyRegisterTask(&task);
				dbgPrintf("Beacon found from %i with systime = %i\n", ptk_core_state.join_agent.fav_address, temp_time);
				LED_gn_off();
				LED_ora_on();
				break;
			}
		}
		break;
	default:
		return PTK_ERR_DEVICETYPE;
		break;
	}
	return PTK_OK;
}

/*
 * 	See header file
 */
void ptk_get_latest_beacon(loramesh_sync_s *pkt) {
	pkt->source_address = mesh_sync_data.source_address;
	pkt->utc_time = mesh_sync_data.utc_time;
	pkt->num_hops = mesh_sync_data.num_hops;
	pkt->rssi = mesh_sync_data.rssi;
	pkt->fw_window = mesh_sync_data.fw_window;
	pkt->subnet_id = mesh_sync_data.subnet_id;
}

/*
 * 	See header file
 */
uint16_t ptk_get_latest_jreq(void) {
	uint16_t addr;
	if (mesh_joinee_address != 0xFFFF) {
		addr = mesh_joinee_address;
		mesh_joinee_address = 0xFFFF;
		return addr;
	} else {
		return 0xFFFF;
	}
}

/*
 * 	See header file
 */
void ptk_get_latest_jresp(loramesh_joinresp_s *resp) {
	resp->confirmation = mesh_joinresp_data.confirmation;
	resp->downlink_slot_nr = mesh_joinresp_data.downlink_slot_nr;
	resp->source_address = mesh_joinresp_data.source_address;
	resp->uplink_slot_nr = mesh_joinresp_data.uplink_slot_nr;
	resp->forwarding_window = mesh_joinresp_data.forwarding_window;
	resp->parent_slot = mesh_joinresp_data.parent_slot;
	resp->subslot_nr = mesh_joinresp_data.subslot_nr;
}

/*
 * 	See header file
 */
void ptk_set_join_agent(uint16_t agent_address) {
	ptk_core_state.join_agent.fav_address = agent_address;
	ptk_core_state.join_agent.state = JOIN_STT_PREPARED;
}

/*
 * 	See header file
 */
uint8_t ptk_process_join_request(uint16_t joinee_address) {
	uint16_t paddr;
	uint8_t slot;

	if (joinee_address == 0) {
		return 1;
	}
	if (ptk_core_state.device_type == DEV_TYPE_REPEATER) {
		// node is directly accessable
		if (ptk_create_routing_tree_entry(ptk_core_state.address,
				joinee_address) == 0) {
			// success
			slot = beacon_window_get_reg_free_window(joinee_address);
			if (slot == 0xFF) {
				return 2;
			}
			ptk_core_state.join_agent.joinee_beacon_window = slot;

			slot = subslot_handler_get_reg_free_subslot(joinee_address);
			if (slot == 0xFF) {
				return 2;
			}
			ptk_core_state.join_agent.joinee_subslot = slot;

			paddr = ptk_routing_tree_get_parent_address(joinee_address);
			if (paddr == 0) {
				return 2;	// not found in routing tree / no parent found
			}
			ptk_core_state.join_agent.confirm = JOIN_ACK;
			ptk_core_state.join_agent.joinee_address = joinee_address;
			slot = ptk_routing_tree_get_ul_slot(paddr);
			if (slot == 0xFFFF) {
				return 3;	// no slot found
			}
			ptk_core_state.join_agent.slots.parent_slot = slot;
			slot = ptk_routing_tree_get_ul_slot(joinee_address);
			if (slot == 0xFFFF) {
				return 4;	//error
			}
			ptk_core_state.join_agent.slots.join_ul_slot = slot;
			slot = ptk_routing_tree_get_dl_slot(joinee_address);
			if (slot == 0xFFFF) {
				return 5;	//error
			}
			ptk_core_state.join_agent.slots.join_dl_slot = slot;
			ptk_core_state.join_agent.state = JOIN_STT_SEND_CONFIRM;
			ptk_core_state.join_agent.role = JOIN_ROLE_AGENT;
			return 0;
		} else {
			//TODO: handle nodes which exist in the routing table
			return 2;
		}
	} else if (ptk_core_state.device_type == DEV_TYPE_NODE) {
		clear_ignore_list();

	} else {
		// error
		return 1;
	}
	return 0;
}

/*
 *	See header file
 */
uint8_t ptk_process_join_response(void) {
	TCyTask task;

	if (ptk_core_state.join_agent.confirm != JOIN_ACK) {
		return 1;
	}

	ptk_core_state.parent_address = ptk_core_state.join_agent.fav_address;
	ptk_core_state.slot_dl = ptk_core_state.join_agent.slots.join_dl_slot;
	ptk_core_state.slot_ul = ptk_core_state.join_agent.slots.join_ul_slot;
	ptk_core_state.slot_parent_ul = ptk_core_state.join_agent.slots.parent_slot;
	ptk_core_state.hop_count = ptk_core_state.join_agent.agent_hop_count + 1;
	ptk_core_state.beacon_window =
			ptk_core_state.join_agent.joinee_beacon_window;
	ptk_core_state.subnet_id = ptk_core_state.join_agent.agent_subnet_id;
	ptk_core_state.subslot_parent_ul = ptk_core_state.join_agent.joinee_subslot;
	ptk_core_state.state = PTK_STATE_IN;

	cyInitPrototype(&task);
	task.type = TASK_TYPE_DL_RX;
	task.slot = ptk_get_nsync() + ptk_get_njoin() + ptk_get_napprove()
			+ ptk_get_nuplink(); //+nuplink
	task.slot += ptk_core_state.slot_dl;
	task.subslot = 0;
	task.wakeup_offset_ms = ptk_get_sync_rx_offset();
	cyRegisterTask(&task);
#if !(defined(DEV_IS_NODE) && NETWORK_MODE == NETWORK_MODE_STAR)
	// Uplink receiving is not required for sensor nodes in a star shaped
	// network. Excluding this process will save energy.
	cyInitPrototype(&task);
	task.type = TASK_TYPE_UL_RX;
	task.slot = ptk_get_nsync() + ptk_get_njoin() + ptk_get_napprove();
	task.slot += ptk_core_state.slot_ul;
	task.subslot = 0;
	task.wakeup_offset_ms = ptk_get_sync_rx_offset();
	cyRegisterTask(&task);
#endif
	cyInitPrototype(&task);
	task.type = TASK_TYPE_UL_TX;
	task.slot = ptk_get_nsync() + ptk_get_njoin() + ptk_get_napprove();
	task.slot += ptk_core_state.slot_parent_ul;
	task.subslot = ptk_core_state.subslot_parent_ul;
	task.wakeup_offset_ms = 0;
	cyRegisterTask(&task);
	task.type = TASK_TYPE_MEASURE;
	task.slot = ptk_get_nsync() + ptk_get_njoin() + ptk_get_napprove();
	task.slot += ptk_get_nuplink() + ptk_get_ndownlink() + 1;
	task.subslot = 0;
	task.wakeup_offset_ms = 0;
	cyRegisterTask(&task);
	// do first measurement
	proc_measure(&latest_battery_voltage, &latest_meas_data, &latest_meas_ts,
			&latest_senstype);
	comm_store_meas_data(ptk_core_state.parent_address, latest_battery_voltage,
			ptk_core_state.link_rssi, latest_meas_ts, latest_senstype,
			latest_meas_data);
	LED_ora_off();
	return 0;
}

/*
 *	See header file
 */
void ptk_set_join_task(void) {
	TCyTask task;
	cyInitPrototype(&task);
	task.type = TASK_TYPE_JOIN;
	task.slot = ptk_get_nsync();
	task.subslot = 0;
	task.wakeup_offset_ms = 0;
	cyRegisterTask(&task);
	LED_ora_on();
}

/*
 *	See header file
 */
void ptk_get_rx_data(loramesh_rx_data_s *dptr) {
	dptr->source_address = mesh_rx_data.source_address;
	dptr->data_header.payload_len = mesh_rx_data.data_header.payload_len;
	dptr->data_header.pkt_num = mesh_rx_data.data_header.pkt_num;
	dptr->data_header.status = mesh_rx_data.data_header.status;
	memcpy(dptr->data, mesh_rx_data.data, mesh_rx_data.data_header.payload_len);
}

/*
 *	See header file
 */
loramesh_conf_t ptk_get_latest_conf(void) {
	return mesh_confirmation;
}

/*
 *	See header file
 */
void ptk_core_reset(void) {
	dbgPrintf("Ptk core reset\n");
	pkt_core_reset_state();
	com_reset_ulcounter();
	cyReset();
	//NVIC_SystemReset( );
}

/*
 *	See header file
 */
void pkt_core_add_node_to_ignore_list(uint16_t addr) {
	add_to_ignore_list(addr);
}

/*
 *	See header file
 */
uint8_t pkt_core_node_is_in_ignore_list(uint16_t addr) {
	return is_in_ignore_list(addr);
}

/*
 *	See header file
 */
uint8_t ptk_node_exited(uint16_t node_addr) {
	uint8_t ret = 0;

	if (ptk_delete_routing_tree_entry(node_addr) != 0) {
		ret = 1;
	}
	if (timeslot_delete_slot(node_addr) != 0) {
		ret = 1;
	}
	if (beacon_window_deregister(node_addr) != 0) {
		ret = 1;
	}
	return ret;
}

/*
 *	See header file
 */
void ptk_core_join_error_handler(void) {
	add_to_ignore_list(ptk_core_state.join_agent.fav_address);
	ptk_core_reset();
}
/* internal functions definitions ------------------------------------------ */

/**
 *  \brief  Task handler which is called by cycler alarm event
 *  \param  *task	pointer to task to be executed
 *  \return ts		RTOS systemtime
 */
static void ptk_core_task_handler(TCyTask *task, uint32_t ts)
//TODO: ts could maybe  be removed
{
	uint32_t time = 0;
	uint16_t time_ms = 0;
	switch (task->type) {
	case (TASK_TYPE_SYNC):
		ptk_proc_sync(&ptk_core_state);
		break;
	case (TASK_TYPE_APPROVE):
		break;
	case (TASK_TYPE_JOIN):
		proc_join(&ptk_core_state);
		break;
	case (TASK_TYPE_UL_RX):
		proc_comm_ul_rx(&ptk_core_state);
		break;
	case (TASK_TYPE_UL_TX):
		cyGetRTCTime(&time, &time_ms);
		proc_comm_ul_tx(&ptk_core_state, ts);
		break;
	case (TASK_TYPE_DL_RX):
		break;
	case (TASK_TYPE_DL_TX):
		break;
	case (TASK_TYPE_WAN):
		proc_lorawan(ts);
		break;
	case (TASK_TYPE_MEASURE):
		proc_measure(&latest_battery_voltage, &latest_meas_data,
				&latest_meas_ts, &latest_senstype);

		comm_store_meas_data(ptk_core_state.parent_address,
				latest_battery_voltage, ptk_core_state.link_rssi,
				latest_meas_ts, latest_senstype, latest_meas_data);
		break;
	default:
		break;
	}
}

/**
 * 	\brief	Reset protocol core state
 */
static void pkt_core_reset_state(void) {
	join_agent_s *prev = NULL;
	join_agent_s *next = NULL;
	// device type has not to be set again
	ptk_core_state.state = PTK_STATE_RESET;
	ptk_core_state.hop_count = HOP_COUNT_RESET_VAL;
	ptk_core_state.link_quality = LINK_QUALITY_RESET_VAL;
	ptk_core_state.subnet_id = SUBNET_ID_RESET_VAL;
	ptk_core_state.beacon_window = BEACON_WINDOW_RESET_VAL;
	ptk_core_state.slot_ul = SLOT_UL_RESET_VAL;
	ptk_core_state.slot_dl = SLOT_DL_RESET_VAL;
	ptk_core_state.slot_parent_ul = SLOT_PARENT_UL_RESET_VAL;
	ptk_core_state.subslot_parent_ul = SUBNET_ID_RESET_VAL;
	ptk_core_state.parent_address = PARENT_ADDR_RESET_VAL;

	ptk_core_state.join_agent.type = JOIN_TYPE_NONE;
	ptk_core_state.join_agent.role = JOIN_ROLE_NONE;
	ptk_core_state.join_agent.state = JOIN_STT_NONE;
	ptk_core_state.join_agent.confirm = JOIN_NACK;
	ptk_core_state.join_agent.slots.join_dl_slot = SLOT_UL_RESET_VAL;
	ptk_core_state.join_agent.slots.join_ul_slot = SLOT_DL_RESET_VAL;
	ptk_core_state.join_agent.slots.parent_slot = SLOT_PARENT_UL_RESET_VAL;
	ptk_core_state.join_agent.agent_hop_count = HOP_COUNT_RESET_VAL;
	ptk_core_state.join_agent.agent_subnet_id = SUBNET_ID_RESET_VAL;
	ptk_core_state.join_agent.fav_address = 0;
	ptk_core_state.join_agent.joinee_address = 0;
	ptk_core_state.join_agent.joinee_beacon_window = BEACON_WINDOW_RESET_VAL;
	ptk_core_state.join_agent.joinee_subslot = 0xFF;

	next = ptk_core_state.join_agent.next;
	while (1) {
		if (next == NULL) {
			break;
		} else {
			prev = next;
			next = prev->next;
			vPortFree(prev);
		}
	}

	if (timeslot_reset_slots() != 0) {
		dbgPrintf("ERROR resetting timeslots\n");
		debug_log_append_line("ERROR resetting timeslots\n"); //TODO: check timing
		NVIC_SystemReset();
	}

	ptk_reset_routing_tree();

	//TODO: Reset routing item
	if (subslot_handler_reset() != 0) {
		dbgPrintf("ERROR resetting subslots\n");
		debug_log_append_line("ERROR resetting subslots\n"); //TODO: check timing
		NVIC_SystemReset();
	}
}

/**
 * 	\brief	Creates routing tree entry for root (in case of repetaer)
 * 	\param	Address of the root
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t ptk_create_routing_tree_root(uint16_t address) {
	routing_item_rep_s *root;

	root = (routing_item_rep_s*) pvPortMalloc(sizeof(routing_item_rep_s));
	if (root == NULL) {
		return 1;
	}
	root->address = address;
	root->next = NULL;
	root->parent = NULL;
	if (timeslot_register_root_slots(address, &root->slot_dl, &root->slot_ul)
			== 0) {
		ptk_core_state.routing_tree = root;
		return 0;
	} else {
		return 1;
	}
}

/*
 * 	\brief	Searches node entry in routing tree and returns uplink slot
 * 	\param	address:	address of the node which slot should be searched
 * 	\ret	returns the slot number on success (0-254), 0xFF (255) on error
 */
static uint8_t ptk_routing_tree_get_ul_slot(uint16_t address) {
	routing_item_rep_s *tree;
	uint8_t slot = 0xFF;
	tree = ptk_core_state.routing_tree;
	if (tree == NULL) {
		return 0xFF;
	}
	while (tree != NULL) {
		if (tree->address == address) {
			slot = tree->slot_ul;
			break;
		}
		tree = tree->next;
	}
	return slot;
}

/*
 * 	\brief	Searches node entry in routing tree and returns downlink slot
 * 	\param	address:	address of the node which slot should be searched
 * 	\ret	returns the slot number on success (0-254), 0xFF (255) on error
 */
static uint8_t ptk_routing_tree_get_dl_slot(uint16_t address) {
	routing_item_rep_s *tree;
	uint8_t slot = 0xFF;
	tree = ptk_core_state.routing_tree;
	if (tree == NULL) {
		return 0xFF;
	}
	while (tree != NULL) {
		if (tree->address == address) {
			slot = tree->slot_dl;
			break;
		}
		tree = tree->next;
	}
	return slot;
}

/*
 * 	\brief	Creates a new entry in the routing tree and checks if
 * 			the new registered node exists already in the routing tree
 * 	\param	*parent:	poiter to parent node
 * 	\param	new_address:address of the node to be registered
 * 	return	returns 0 on success, nozero otherwise
 */
static uint8_t ptk_create_routing_tree_entry(uint16_t parent_address,
		uint16_t new_address) {
	routing_item_rep_s *node;
	routing_item_rep_s *parent_node;
	routing_item_rep_s *new_node;

	parent_node = NULL;
	new_node = NULL;

	node = ptk_core_state.routing_tree;

	while (node != NULL) {
		if (node->address == parent_address) {
			parent_node = node;
		}
		if (node->address == new_address) {
			new_node = node;
		}
		node = node->next;
	}

	if ((new_node == NULL) && (parent_node != NULL)) {
		// node is not yet registered in the routing tree
		node = (routing_item_rep_s*) pvPortMalloc(sizeof(routing_item_rep_s));
		if (node == NULL) {
			return 1;
		}
		node->address = new_address;
		node->parent = parent_node;
		node->next = ptk_core_state.routing_tree;
		ptk_core_state.routing_tree = node;
		if (timeslot_get_free(node->address, &node->slot_ul, &node->slot_dl)
				!= 0) {
			// TODO: Error handling (bachmaph: delete node from routing tree?)
			ptk_delete_routing_tree_entry(node->address);
			return 2;
		}
		return 0;
	} else if ((new_node != NULL) && (new_node->parent == parent_node)) {
		// node already registered in the routing tree
		return 5;
	} else if ((new_node != NULL) && (new_node->parent != parent_node)) {
		// node has a new parent
		return 6;
	} else {
		// something went wrong
		return 7;
	}
}

/**
 * 	\brief	Deletes a node from the routing tree
 * 	\param	naddr: node address to be deleted
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t ptk_delete_routing_tree_entry(uint16_t naddr) {
	routing_item_rep_s *prev;
	routing_item_rep_s *next;
	uint8_t ret = 1;

	prev = ptk_core_state.routing_tree;
	next = ptk_core_state.routing_tree->next;
	if (prev == NULL) {
		return 1;	// node not found
	}

	if (prev->address == naddr) { // node is first entry of tree
		ptk_core_state.routing_tree = next;
		prev->address = 0;
		prev->next = NULL;
		prev->parent = NULL;
		prev->slot_dl = 0xFF;
		prev->slot_ul = 0xFF;
		vPortFree(prev);
		return 0;
	}

	while (next != NULL) {
		if (next->address == naddr) {
			prev->next = next->next;
			next->address = 0;
			next->slot_dl = 0xFF;
			next->slot_ul = 0xFF;
			next->parent = NULL;
			next->next = NULL;
			vPortFree(next);
			ret = 0;
		}
		next = next->next;
	}
	return ret;
}

/**
 * 	\brief	resets the routing tree by deleting all entries
 */
static void ptk_reset_routing_tree(void) {
	routing_item_rep_s *prev;
	routing_item_rep_s *next;

	prev = ptk_core_state.routing_tree;
	if (prev == NULL) {
		return;
	}

	while (prev != NULL) {
		next = prev->next;
		prev->address = 0;
		prev->parent = NULL;
		prev->slot_dl = 0xFF;
		prev->slot_ul = 0xFF;
		prev->next = NULL;
		vPortFree(prev);
		prev = next;
	}
	return;

}

/*
 * 	\brief	Searches entry for node in routing tree and returns the
 * 			parent address
 * 	\param	naddr: address of the node to be searched
 * 	\ret	returns the parent address on success, 0 on error
 */
static uint16_t ptk_routing_tree_get_parent_address(uint16_t naddr) {
	routing_item_rep_s *tree;
	uint16_t raddr = 0;

	tree = ptk_core_state.routing_tree;
	if (tree == NULL) {
		return 0;
	}
	while (tree != NULL) {
		if (tree->address == naddr) {
			if (tree->parent != NULL) {
				raddr = tree->parent->address;
				break;
			}
		}
		tree = tree->next;
	}
	return raddr;
}

/*
 * 	\brief	Initializes the timeslot table
 * 	\return	0 on success, nonzero on error
 */
static uint8_t timeslots_init(void) {
	uint16_t i = 0;
	num_ul_slots = ptk_get_nuplink() + 1;
	num_dl_slots = ptk_get_ndownlink() + 1;

	ptk_core_state.slots_dl = pvPortMalloc(sizeof(slot_s) * num_dl_slots);
	if (ptk_core_state.slots_dl == NULL) {
		return 1;
	}
	ptk_core_state.slots_ul = pvPortMalloc(sizeof(slot_s) * num_ul_slots);

	if (ptk_core_state.slots_ul == NULL) {
		return 1;
	}
	for (i = 0; i < num_dl_slots; i++) {
		(ptk_core_state.slots_dl + i)->slot_state = SLOT_FREE;
		(ptk_core_state.slots_dl + i)->node_address = 0;
	}
	for (i = 0; i < num_ul_slots; i++) {
		(ptk_core_state.slots_ul + i)->slot_state = SLOT_FREE;
		(ptk_core_state.slots_ul + i)->node_address = 0;
	}
	return 0;
}

/**
 * 	\brief	Registres root slots in the timeslot handler
 * 			Root slots are the last possible uplink slot
 * 			and the first downlink slot
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t timeslot_register_root_slots(uint16_t address, uint8_t *dl,
		uint8_t *ul) {

	if (ptk_core_state.slots_dl[0].slot_state == SLOT_FREE) {
		ptk_core_state.slots_dl[0].node_address = address;
		ptk_core_state.slots_dl[0].slot_state = SLOT_USED;
		*dl = 0;
	} else {
		return 1;
	}
	if (ptk_core_state.slots_ul[num_ul_slots - 1].slot_state == SLOT_FREE) {
		ptk_core_state.slots_ul[num_ul_slots - 1].node_address = address;
		ptk_core_state.slots_ul[num_ul_slots - 1].slot_state = SLOT_USED;
		*ul = num_ul_slots - 1;
	} else {
		return 1;
	}
	return 0;
}

/**
 * 	\brief	Gets a free timeslot from the timeslot handler and registers
 * 			a given node in the handler
 * 	\param	addr	address of the node which should be registered
 * 	\param	*s_ul	pointer to buffer where uplink slots are stored
 * 	\param	*s_dl	pointer to buffer where downlink slots are stored
 * 	\return	0: 	an unused slot is found and node is registered
 * 			1:  sensor is already registered in timeslot handler
 * 			2: 	otherwise
 *
 */
static uint8_t timeslot_get_free(uint16_t addr, uint8_t *s_ul, uint8_t *s_dl) {
	uint16_t i = 0; // TODO: set to signed
	uint8_t found = 2;
	slot_s *slots;
	slots = ptk_core_state.slots_ul;
	if (slots != NULL) {
		for (i = num_ul_slots; i > 0; i--) {
			if ((slots + i - 1)->slot_state == SLOT_FREE) {
				*s_ul = i - 1;
				(slots + i - 1)->slot_state = SLOT_USED;
				(slots + i - 1)->node_address = addr;
				found = 0;
				break;
			} else {
				if ((slots + i - 1)->node_address == addr) {
					*s_ul = i - 1;
					found = 1;
					break;
				}
			}
		}
	}
	if (found != 0) {
		return found;
	}
	found = 2;
	slots = ptk_core_state.slots_dl;
	if (slots != NULL) {
		for (i = 0; i < num_ul_slots; i++) {
			if ((slots + i)->slot_state == SLOT_FREE) {
				*s_dl = i;
				(slots + i)->slot_state = SLOT_USED;
				(slots + i)->node_address = addr;
				found = 0;
				break;
			} else {
				if ((slots + i)->node_address == addr) {
					*s_dl = i;
					found = 1;
					break;
				}
			}
		}
	}
	return found;
}

/**
 * 	\brief	Deletes slots for a specific node from timeslot handler
 * 	\param	addr	addres of the node whose slots should be given free
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t timeslot_delete_slot(uint16_t addr) {
	uint16_t i = 0;
	uint8_t ret = 0;
	slot_s *slots;
	slots = ptk_core_state.slots_ul;
	if (slots != NULL) {
		for (i = 0; i < num_ul_slots; i++) {
			if ((slots + i)->node_address == addr) {
				(slots + i)->slot_state = SLOT_FREE;
				(slots + i)->node_address = 0;
				ret = 0;
			}
		}
		if (ret == 0) {
			ret = 1;
			slots = ptk_core_state.slots_dl;
			for (i = 0; i < num_dl_slots; i++) {
				if ((slots + i)->node_address == addr) {
					(slots + i)->slot_state = SLOT_FREE;
					(slots + i)->node_address = 0;
					ret = 0;
				}
			}
		}
	}
	return ret;
}

/**
 * 	\brief	Resets all timeslots of the timeslot handler
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t timeslot_reset_slots(void) {
	uint16_t i = 0;

	if (ptk_core_state.slots_dl == NULL) {
		return 1;
	}

	if (ptk_core_state.slots_ul == NULL) {
		return 1;
	}
	for (i = 0; i < num_dl_slots; i++) {
		(ptk_core_state.slots_dl + i)->slot_state = SLOT_FREE;
		(ptk_core_state.slots_dl + i)->node_address = 0;
	}
	for (i = 0; i < num_ul_slots; i++) {
		(ptk_core_state.slots_ul + i)->slot_state = SLOT_FREE;
		(ptk_core_state.slots_ul + i)->node_address = 0;
	}
	return 0;
}

/**	LoRaMesh callback functions			*/
static void mesh_on_beacon_received(loramesh_sync_s *sync) {
	mesh_sync_data.source_address = sync->source_address;
	mesh_sync_data.utc_time = sync->utc_time;
	mesh_sync_data.rssi = sync->rssi;
	mesh_sync_data.num_hops = sync->num_hops;
	mesh_sync_data.fw_window = sync->fw_window;
	mesh_sync_data.subnet_id = sync->subnet_id;
	osSignalSet(runTaskHandle, OS_SIGN_MESH_BEAC_REC);
}

static void mesh_on_tx_done(void) {
	osSignalSet(runTaskHandle, OS_SIGN_MESH_TX_DONE);

}

static void mesh_on_rx_done(loramesh_rx_data_s *rx_data) {
	mesh_rx_data.source_address = rx_data->source_address;
	mesh_rx_data.data_header.payload_len = rx_data->data_header.payload_len;
	mesh_rx_data.data_header.pkt_num = rx_data->data_header.pkt_num;
	mesh_rx_data.data_header.status = rx_data->data_header.status;
	memcpy(mesh_rx_data.data, rx_data->data,
			mesh_rx_data.data_header.payload_len);
	osSignalSet(runTaskHandle, OS_SIGN_MESH_RX_DONE);
}

static void mesh_on_rx_error(void) {
	osSignalSet(runTaskHandle, OS_SIGN_MESH_RX_ERROR);
}

static void mesh_on_tx_error(void) {
	osSignalSet(runTaskHandle, OS_SIGN_MESH_TX_ERROR);
}

static void mesh_on_jreq_received(uint16_t src_addr) {
	mesh_joinee_address = src_addr;
	osSignalSet(runTaskHandle, OS_SIGN_MESH_JREQ_RX);
}

static void mesh_on_jresp_received(loramesh_joinresp_s *rsp) {
	mesh_joinresp_data.confirmation = rsp->confirmation;
	mesh_joinresp_data.forwarding_window = rsp->forwarding_window;
	mesh_joinresp_data.downlink_slot_nr = rsp->downlink_slot_nr;
	mesh_joinresp_data.uplink_slot_nr = rsp->uplink_slot_nr;
	mesh_joinresp_data.parent_slot = rsp->parent_slot;
	mesh_joinresp_data.subslot_nr = rsp->subslot_nr;
	mesh_joinresp_data.source_address = rsp->source_address;
	osSignalSet(runTaskHandle, OS_SIGN_MESH_JRES_RX);
}

static void mesh_on_conf_received(loramesh_conf_t conf) {
	mesh_confirmation = conf;
	osSignalSet(runTaskHandle, OS_SIGN_MESH_CONF_RX);
}

/**	 --- Ignore list handling -----------------------------------------------*/
/**
 * 	\brief	Adds a node to the ignore list
 * 			Beacon of this node will be ignored during the next init sync
 * 			process
 * 	\param	ignore_addr	address of the node whose beacon will be ignored
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t add_to_ignore_list(uint16_t ignore_addr) {
	uint16_t *old;
	if (ignore_list == NULL) {
		ignore_list = pvPortMalloc(sizeof(uint16_t) * (num_ignore_enties + 1));
		if (ignore_list == NULL) {
			dbgPrintf("ERROR ignore list allocation\n");
			debug_log_append_line("ERROR ignore list allocation\n"); //TODO: check timing
			return 1;
		}
	} else {
		old = ignore_list;
		ignore_list = pvPortMalloc(sizeof(uint16_t) * (num_ignore_enties + 1));
		if (ignore_list == NULL) {
			dbgPrintf("ERROR ignore list reallocation\n");
			debug_log_append_line("ERROR ignore list reallocation\n"); //TODO: check timing
			return 2;
		}
		memcpy(ignore_list, old, sizeof(uint16_t) * num_ignore_enties);
		vPortFree(old);
	}
	*(ignore_list + num_ignore_enties) = ignore_addr;
	num_ignore_enties++;
	return 0;
}

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
/**
 * 	\brief	Removes a node from the ignore list
 * 	\param	remove_address address of node to be removed
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t remove_from_ignore_list(uint16_t remove_address) {
	uint8_t i = 0;
	uint8_t j = 0;
	uint16_t *new;
	uint16_t *old;
	if (ignore_list == NULL) {
		return 1;
	}

	if (num_ignore_enties == 1) {
		// address is the only entry
		vPortFree(ignore_list);
		num_ignore_enties = 0;
	} else {
		new = pvPortMalloc(sizeof(uint16_t) * (num_ignore_enties - 1));
		if (new == NULL) {
			return 1;
		}
		for (i = 0; i < num_ignore_enties; i++) {
			if (*(ignore_list + i) == remove_address) {
				// do not copy into new buffer
			} else {
				*(new + j) = *(ignore_list + i);
				j++;
			}
		}
		old = ignore_list;
		ignore_list = new;
		vPortFree(old);
		num_ignore_enties--;
	}
	return 0;
}
#pragma GCC diagnostic pop

/**
 * 	\brief	Clears (resets) the ignore list by deleting all entries
 * 	\return	returns 0 on success, nonzero otherwise
 */
static uint8_t clear_ignore_list(void) {
	uint8_t i = 0;
	for (i = 0; i < num_ignore_enties; i++) {
		*(ignore_list + i) = 0;
	}
	vPortFree(ignore_list);
	num_ignore_enties = 0;
	return 0;
}

/**
 * 	\brief	Checks if a particular node has en entry in the ignore list
 * 	\param	addr:	address of the node to be checked
 * 	\return	returns 1 if the node is in the list, 0 otherwise
 */
static uint8_t is_in_ignore_list(uint16_t addr) {
	uint8_t i = 0;
	if (ignore_list == NULL) {
		return 0;
	}
	for (i = 0; i < num_ignore_enties; i++) {
		if (*(ignore_list + i) == addr) {
			return 1;
		}
	}
	return 0;
}

/**
 *  \brief  Checks the LoRaWAN connection by trying OTAA
 *  		(over the air activation)
 *  \return returns 0 on success, nonzero otherwise
 */
static uint8_t WAN_do_OTAA(void) {
	//	TODO: Implement OTAA
#ifdef DEV_IS_REPEATER
	return 0;
#else
#ifdef DEV_IS_NODE
	return 1;
#else
	return 1;
#error "Define if device is repetare (DEV_IS_REPEATER) or node (DEV_IS_NODE)"
#endif
#endif
}
