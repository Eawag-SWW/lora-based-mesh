/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		power_switches.c
 *
 * \description	Handles power switches (FET stages)
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "power_switches.h"
#include "stm32l4xx_hal.h"
#include "mcu_pinout.h"
/* -- makros ----------------------------------------------------------------*/
#define NUM_SWITCHES	5			/** defines number of switches			 */

/* -- type definitions-------------------------------------------------------*/
typedef struct {
					ps_type_t power_switch;
					ps_state_t state;
}power_switch_states_s;

/* internal function declarations ------------------------------------------ */
static void switch_ctrl( ps_type_t type ,ps_state_t state );
void all_off ( void );
void all_on ( void );
static void init_states( void );
static void update_state( ps_type_t pstype, ps_state_t psstate );

/* internal variable definitions ------------------------------------------- */
/** lookup table for used ports												 */
static GPIO_TypeDef* ports_LUT[NUM_SWITCHES] = {	PS_TIMESOURCE_PORT,
													PS_SENSI_PORT,
													PS_SX_PORT,
													PS_IM880_PORT,
													PS_SDCARD_PORT
};

/** lookup table for used pins												 */
static uint16_t pins_LUT[NUM_SWITCHES] = { 			PS_TIMESOURCE_PIN,
													PS_SENSI_PIN,
													PS_SX_PIN,
													PS_IM880_PIN,
													PS_SDCARD_PIN
};


static power_switch_states_s states[NUM_SWITCHES];
static power_switch_states_s state_before_lp[NUM_SWITCHES];

/* public function definitions --------------------------------------------- */

/*
 * 	See header file
 */
void power_switch_init( void )
{
	GPIO_InitTypeDef gpio;
	uint8_t i = 0;
	if( __HAL_RCC_GPIOA_IS_CLK_DISABLED( )){
		__HAL_RCC_GPIOA_CLK_ENABLE();
	}
	if( __HAL_RCC_GPIOB_IS_CLK_DISABLED( )){
		__HAL_RCC_GPIOB_CLK_ENABLE();
	}

	gpio.Mode = 	GPIO_MODE_OUTPUT_PP;
	gpio.Pull = 	GPIO_NOPULL;
	gpio.Speed = 	GPIO_SPEED_FREQ_LOW;

	for( i=0; i<NUM_SWITCHES; i++ ){
		gpio.Pin = pins_LUT[i];
		HAL_GPIO_Init( ports_LUT[i], &gpio );
	}
	init_states( );
	all_off();
}


/*
 * See header file
 */
void power_switch_control( ps_type_t type, ps_state_t state )
{
	if( type < PS_ALL ){
		switch_ctrl( type, state );
	} else {
		if( state == PS_ON ){
			all_on();
		} else if ( state == PS_OFF ){
			all_off();
		} else {
			// error
		}
	}
}


/*
 *	See header file
 */
void power_switch_control_enter_lowpower( void )
{
	uint8_t i = 0;
	for( i=0; i<NUM_SWITCHES; i++ ){
		state_before_lp[i].power_switch = states[i].power_switch;
		state_before_lp[i].state = states[i].state;
		if( states[i].power_switch != PS_IM880B ){
			switch_ctrl( states[i].power_switch, PS_OFF );
		}
	}
}

/*
 *	See header file
 */
void power_switch_control_exit_lowpower( void )
{
	uint8_t i = 0;
	for( i=0; i<NUM_SWITCHES; i++ ){
		if( state_before_lp[i].state == PS_ON ){
			switch_ctrl( state_before_lp[i].power_switch, state_before_lp[i].state);
		}
	}
}




/* internal functions definitions ------------------------------------------ */
/**
 *  \brief  Controls the GPIO to switch on/off a specified power switch
 *  \param  type:	type of the switch ( defines with module is controlled )
 *  \param	state:	defines switch state
 */
static void switch_ctrl( ps_type_t type ,ps_state_t state )
{
	HAL_GPIO_WritePin( ports_LUT[type], pins_LUT[type], state );
	update_state( type, state );
}

/**
 *  \brief  Switches all power switches to off state
 */
void all_off ( void )
{
	uint8_t i = 0;
	for( i=0; i<NUM_SWITCHES; i++){
		switch_ctrl( i, PS_OFF );
	}
}

/**
 *  \brief  Switches all power switches to on state
 */
void all_on ( void )
{
	uint8_t i = 0;
	for( i=0; i<NUM_SWITCHES; i++){
		switch_ctrl( i, PS_ON );
	}

}

/*
 * 	\brief	Initializes the power switch state buffer
 */
static void init_states( void )
{
	uint8_t i = 0;
	for(i=0; i<NUM_SWITCHES; i++ ){
		states[i].power_switch = i;
		states[i].state = PS_OFF;
	}
}

/*
 * 	\brief	Updates the status of a given power switch in the
 * 			state buffer
 * 	\param	pstype	power switch which's state should be updated
 * 	\param	psstate	update value
 */
static void update_state( ps_type_t pstype, ps_state_t psstate )
{
	uint8_t i = 0;
	for(i=0; i<NUM_SWITCHES; i++ ){
		if( states[i].power_switch == pstype ){
			states[i].state = psstate;
		}
	}
}

