/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		subslot_handler.c
 *
 * \description	Handles subslots for child nodes
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		18.09.2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "subslot_handler.h"
#include "stdlib.h"
#include "string.h"
#include "cmsis_os.h"
/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/
typedef enum{
				SLOT_FREE = 0,
				SLOT_USED = 1
}subslot_states;

typedef struct beacon_window {
		subslot_states state;
		uint16_t node_address;
		uint8_t ul_timeout_cnt;
} subslots_s;

/* internal function declarations ------------------------------------------ */

 
/* internal variable definitions ------------------------------------------- */
static subslots_s *subslots;
static uint8_t num_subslots;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint8_t subslot_handler_init( uint8_t n_subslots )
{
	uint8_t i;
	if( n_subslots <= 0 ){
		return 1;
	}
	if( subslots != NULL ){
		vPortFree(subslots);

	}
	subslots = pvPortMalloc( n_subslots * sizeof(subslots_s));
	if( subslots == NULL ){
		num_subslots = 0;
		return 2;
	}
	num_subslots = n_subslots;
	for(i=0; i<num_subslots; i++){
		subslots[i].node_address = 0x00;
		subslots[i].state = SLOT_FREE;
		subslots[i].ul_timeout_cnt = 0;
	}
	return 0;
}

/*
 * See header file
 */
uint8_t subslot_handler_reset( void )
{
	uint8_t i = 0;

	if( subslots == NULL ){
		return 1;
	}
	for(i=0; i<num_subslots; i++){
		subslots[i].node_address = 0x00;
		subslots[i].state = SLOT_FREE;
		subslots[i].ul_timeout_cnt = 0;
	}
	return 0;
}

/*
 * See header file
 */
uint8_t subslot_handler_register_subslot(	uint8_t subslot_nr,
											uint16_t node_addr)
{
	if( subslots == NULL ) {
		return 1;
	}
	if( subslots[subslot_nr].state != SLOT_FREE ){
		return 1;	// window already used
	} else {
		subslots[subslot_nr].state = SLOT_USED;
		subslots[subslot_nr].node_address = node_addr;
		subslots[subslot_nr].ul_timeout_cnt = 0;
	}
	return 0;
}

/*
 * 	See header file
 */
uint8_t subslot_handler_get_reg_free_subslot( uint16_t node_addr)
{
	uint8_t i = 0;
	if(subslots == NULL){
		return 0xFF;
	}
	for(i=0; i<num_subslots; i++){
		if(subslots[i].state == SLOT_FREE){
			subslots[i].state = SLOT_USED;
			subslots[i].node_address = node_addr;
			subslots[i].ul_timeout_cnt = 0;
			return i;
		}
	}
	return 0xFF;
}

/*
 * 	See header file
 */
uint8_t subslot_handler_deregister_subslot( uint16_t node_addr )
{
	uint8_t i = 0;
	for(i=0; i<num_subslots; i++){
		if( subslots[i].node_address == node_addr){
			subslots[i].node_address = 0x0000;
			subslots[i].state = SLOT_FREE;
			subslots[i].ul_timeout_cnt = 0;
			return 0;
		}
	}
	return 1;
}

/*
 *	See header file
 */
void subslot_handler_increment_all_timeouts( void )
{
	uint8_t i = 0;
	for( i=0; i<num_subslots; i++){
		if( subslots[i].state == SLOT_USED){
			subslots[i].ul_timeout_cnt++;
		}
	}
}

/*
 * 	See header file
 */
uint8_t subslot_handler_reset_timeout_for_node( uint16_t naddr )
{
	uint8_t i = 0;
	for( i=0; i<num_subslots; i++){
		if( subslots[i].node_address == naddr){
			subslots[i].ul_timeout_cnt = 0;
			return 0;
		}
	}
	return 1;
}

/*
 * 	See header file
 */
uint8_t subslot_handler_get_timeout_cnt_for_node( uint16_t naddr)
{
	uint8_t i = 0;
	for( i=0; i<num_subslots; i++){
		if( subslots[i].node_address == naddr){
			return subslots[i].ul_timeout_cnt;
		}
	}
	return 0xFF;
}

/*
 * 	See header file
 */
uint8_t subslot_handler_get_expired_timeouts( 	uint8_t threshold,
												uint8_t *numnodes,
												uint16_t *naddresses){
	uint8_t i = 0;
	uint8_t num_found = 0;
	uint8_t i_found = 0;

	if(naddresses == NULL ){
		return 1; // NULLPOINTER
	}

	for( i=0; i<num_subslots; i++){
		if( subslots[i].ul_timeout_cnt > threshold ){
			num_found++;
		}
	}
	for( i=0; i<num_subslots; i++){
		if( subslots[i].ul_timeout_cnt > threshold ){
			*(naddresses + i_found) = subslots[i].node_address;
			i_found++;
		}
	}
	*numnodes = num_found;
	return 0;
}


/* internal functions definitions ------------------------------------------ */



