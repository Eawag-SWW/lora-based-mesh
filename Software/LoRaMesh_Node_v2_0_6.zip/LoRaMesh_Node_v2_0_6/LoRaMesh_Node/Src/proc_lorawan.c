/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		lorawan.c
 *
 * \description	Implementation of LoRaWAN communication
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		01.11.2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "proc_lorawan.h"
#include "iM880B.h"
#include "stdlib.h"
#include "string.h"
#include "task_run.h"
#include "cmsis_os.h"
#include "utilities.h"
#include "debug/debug.h"
#include "log/log.h"
#include "battery_meas.h"
#include "device_config.h"

/* -- makros ----------------------------------------------------------------*/
#define WAN_MAX_PL_LEN		LORAWAN_MAX_PAYLOAD_LEN
#define NUM_STATUS_BYTES	1

/* -- type definitions-------------------------------------------------------*/

/* -- OS globals ------------------------------------------------------------*/
extern osThreadId runTaskHandle;

/* internal function declarations ------------------------------------------ */
static void im880_callback( tIM880Evt evt, uint8_t *pdata, uint16_t length );
static uint8_t get_status( void );

/* internal variable definitions ------------------------------------------- */ 
static uint8_t stored_data[WAN_MAX_PL_LEN];
static uint8_t stored_data_len = 0;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint8_t lorawan_store_txdata( uint16_t source_addr, uint8_t *buffer,
													uint8_t buff_len )
{
	uint8_t tmp[2];
	if( (stored_data_len + buff_len + 2) >= (WAN_MAX_PL_LEN - NUM_STATUS_BYTES)){
		return 1;	// lorawan packet is full
	}
	tmp[0] = B1_16TO8( source_addr );
	tmp[1] = B0_16TO8(source_addr  );
	memcpy((stored_data + stored_data_len + NUM_STATUS_BYTES), tmp, 2 );
	stored_data_len += 2;
	memcpy((stored_data + stored_data_len + NUM_STATUS_BYTES), buffer, buff_len);
	stored_data_len += buff_len;
	return 0;
}

/*
 * 	See header file
 */
uint8_t proc_lorawan( uint32_t starttick )
{
	osEvent evt;
	uint8_t num_bytes;
	uint8_t maxpl;
	uint8_t i = 0;

	stored_data[0] = get_status();
	num_bytes = NUM_STATUS_BYTES + stored_data_len;

	if( iM880B_send_data_unconfirmed( LORAWAN_MAC_DATA_PORT, stored_data, num_bytes) != IM880_OK ){
		dbgPrintf("ERROR imst communication\n");
		stored_data_len = 0;
		return 1;
	}
	evt = osSignalWait( OS_SIGN_WAN_DONE, 4800 );	//TODO: set corret timeout
	if( check_is_signal_set( &evt, OS_SIGN_WAN_DONE )){
		stored_data_len = 0;
		dbgPrintf("Wan data sent\n");
	} else {
		// Request maximum allowed payload from imst module
		if( iM880B_get_max_payload( &maxpl ) != IM880_OK ){
			stored_data_len = 0;
			dbgPrintf("Error maxpl\n");
			return 2;
		}
		// Shorten payload til it fits within allowed payload size
		// ATTENTION: Sensor data get lost
		for(i=0; num_bytes >=1; i++ ){
			num_bytes-= 10;
			if( num_bytes <= maxpl ){
				break;
			}
		}
		if( iM880B_send_data_unconfirmed( LORAWAN_MAC_DATA_PORT, stored_data, num_bytes )!= IM880_OK ){
			stored_data_len = 0;
			dbgPrintf("Command2 error\n");
			return 3;
		}
		evt = osSignalWait( OS_SIGN_WAN_DONE, 4800 );	//TODO: set corret timeout
		if( check_is_signal_set( &evt, OS_SIGN_WAN_DONE )){
			dbgPrintf("Wan short data sent %i\n",num_bytes);
		} else {
			stored_data_len = 0;
			dbgPrintf("ERROR trasnmitting short data\n");
			return 4;
		}
	}
	stored_data_len = 0;
	return 0;
}

/*
 * 	See header file
 */
uint8_t lorawan_init( void )
{
	if( iM880B_Init( im880_callback ) != IM880_OK ){
		dbgPrintf("ERROR initializing wan\n");
		debug_log_append_line("ERROR initializing wan\n"); //TODO: SD: Timing probably not critical
		return 1;
	}
	dbgPrintf("WAN module initialized\n");
	return 0;
}


/* internal functions definitions ------------------------------------------ */
/**
 *  \brief  Callback function for IM880B layer
 *  \param  evt:	event which caused calling the callback function
 *  \param	*pdata:	pointer to buffer where data are stored
 *  \param	length:	length of the stored data
 */

static void im880_callback( tIM880Evt evt, uint8_t *pdata, uint16_t length )
{
	switch( evt ){
	case ( IM880_EVT_NO_EVT ):
		break;
	case ( IM880_EVT_CMD_ACCEPTED ):
		break;
	case ( IM880_EVT_CMD_ERROR ):
		osSignalSet( runTaskHandle, OS_SIGN_WAN_ERROR );
		break;
	case ( IM880_EVT_CMD_TIMEOUT ):
		osSignalSet( runTaskHandle, OS_SIGN_WAN_ERROR );
		break;
	case ( IM880_EVT_TX_DONE ):
		break;
	case ( IM880_EVT_TX_TIMEOUT ):
		osSignalSet( runTaskHandle, OS_SIGN_WAN_ERROR );
		break;
	case ( IM880_EVT_RX_DONE ):
		osSignalSet( runTaskHandle, OS_SIGN_WAN_DONE );
		break;
	case ( IM880_EVT_ACK_RX_DONE ):
		osSignalSet( runTaskHandle, OS_SIGN_WAN_DONE );
		break;
	case ( IM880_EVT_RX_WINDOW_ELLAPSED ):
		osSignalSet( runTaskHandle, OS_SIGN_WAN_DONE );
		break;
	case ( IM880_EVT_RX_TIMEOUT ):
		osSignalSet( runTaskHandle, OS_SIGN_WAN_ERROR );
		break;
	default:
		break;
	}
}

/**
 * 	\brief	Determines the current status of the repeater
 * 			Measures battery voltage and generates status byte
 * 			which can be sent to the LoRaWAN application
 * 			| 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
 *			|     VBat      |     Reserved  |
 * 	\return	status byte
 */
static uint8_t get_status( void )
{
	uint8_t res = 0;
	uint8_t tmp = 0;
	uint16_t vbat = 0;
	uint8_t stt = 0;

	stt = meas_vbat( &vbat);
	if( stt != 0 ){

	}
	tmp = convert_vbat( vbat);
	// reserved bits
	res = (tmp<<4) & 0xF0;
	return res;
}
