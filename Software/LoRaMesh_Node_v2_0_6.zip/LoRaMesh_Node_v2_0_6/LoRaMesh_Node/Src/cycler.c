/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		cycler.c
 *
 * \description	This module handles the timing behaviour of a device by
 * 				calling differnet task at the specified time.
 * 				This module is basesd on code of D. Ast
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include "cmsis_os.h"
#include "debug/debug.h"
#include "log/log.h"
#include "rtc.h"
#include "utilities.h"
#include "network_config.h"
#include "protocol_config.h"
#include "cycler.h"
#include "task_run.h"
#include "device_config.h"
#include "lowpower.h"

/* -- makros ----------------------------------------------------------------*/
#define CY_TASK_STATE_INACTIVE 0
#define CY_TASK_STATE_SCHEDULED 1
#define CY_TASK_STATE_DO 2
#define CY_TASK_STATE_ERROR 3
#define CY_TASK_STATE_DONE 4
#define CY_TASK_STATE_REMOVE 99

#define MCU_WKUP_OFFSET_MS	28 				 //* MCU wakeup time offset in ms*/

extern osThreadId runTaskHandle;

/* -- type definitions-------------------------------------------------------*/
typedef struct CyState {
	struct CyTask *first;
	struct CyTask *scheduled;
	TaskHandler taskHandler;
	BeforeIssueHook beforeIssueHook;
	NewCycleHook newCycleHook;
	uint32_t t2Stamp;
} TCyState;


/* internal function declarations ------------------------------------------ */
static void cyInternalDumpTasks( TCyTask *next );
static uint8_t cyScheduleTask( TCyTask *task ) ;
static TCyTask *cyScheduleByLast( TCyTask *last );
static void cyDoRemoveTask( uint16_t slot );
static TCyTask *cyScheduleByRtc( void );
static void cy_on_alarm_event ( void );
static uint8_t cy_correct_alarmtime_by_offset( rtc_alarm_t *alrm );
static uint8_t cy_adv_alarmtime_by_ms ( rtc_alarm_t *alrm, uint32_t ms );
 
/* internal variable definitions ------------------------------------------- */ 
static TCyState cyState;
static rtc_alarm_t alarm;
static rtc_utc_t cycle_start_time = 0;
static uint16_t cycle_start_time_ms = 0;
static rtc_utc_t curr_cycle_start_time = 0;
static uint16_t curr_cycle_start_time_ms;
static uint32_t latest_wakeup_tick;
static uint8_t first_time = 1;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
void cyInit( void ) 							// maybe add here signal pattern
{
	//cyState.eventPtr = eventPtr;
	//cyState.eventMask = eventMask;
	cyState.first = NULL;
	cyState.scheduled = NULL;
	cyState.taskHandler = NULL;
	cyState.beforeIssueHook = NULL;
	cyState.newCycleHook = NULL;
}

/*
 * See header file
 */
void cyReset( void )
{
	TCyTask *task;
	task = cyState.first;
	while ( task != NULL ) {
		cyRemoveTask( task->slot );
		task = task->next;
	}
	cycle_start_time = 0;
	cycle_start_time_ms = 0;
	first_time = 1;
}

/*
 *	See header file
 */
uint8_t cyUpdateStartRTCTime( uint32_t time, uint16_t time_ms )
{
	rtc_set_time_date( time, time_ms );
	cycle_start_time = time;
	cycle_start_time_ms = 0;
	return 0;
}

/*
 * See header file
 */
uint8_t cyUpdateRTCTime	( uint32_t time, uint16_t time_ms )
{
	rtc_set_time_date( time, time_ms );
	return 0;
}

/*
 * 	See header file
 */
uint8_t cySetStartTimeRel ( uint32_t ms_offset )
{
	rtc_utc_t curr_time = 0;
	uint16_t curr_time_ms = 0;
	uint32_t sec;
	uint16_t ms;

	if( cycle_start_time != 0 ) {		// start time already set
		return 1;
	}
	sec = ms_offset / 1000;
	ms = ms_offset % 1000;

	rtc_get_time_date( &curr_time, &curr_time_ms );
	cycle_start_time = curr_time + sec;
	cycle_start_time_ms = curr_time_ms + ms;
	if(cycle_start_time_ms >= 1000 ) {
		cycle_start_time += (uint32_t)(cycle_start_time_ms / 1000);
		cycle_start_time_ms = cycle_start_time_ms % 1000;
	}
	return 0;
}

/*
 * 	See header file
 */
uint8_t cySetNextPossibleStart( uint32_t starttime, uint16_t start_ms )
{
	rtc_utc_t curr_time = 0;
	uint16_t curr_time_ms = 0;
	if( cycle_start_time != 0 ){	// start time already set
		return 1;
	}
	rtc_get_time_date( &curr_time, &curr_time_ms );
	while( starttime <= curr_time ){
		starttime += ptk_get_cycle_duration_s( );
	}
	cycle_start_time = starttime;
	cycle_start_time_ms = start_ms;
	return 0;
}

/*
 *	See header file
 */
uint8_t cySetStartTimeAbs ( uint32_t starttime, uint16_t start_ms )
{
	rtc_utc_t curr_time = 0;
	uint16_t curr_time_ms = 0;
	if( cycle_start_time != 0 ) {		// start time already set
		return 1;
	}
	rtc_get_time_date( &curr_time, &curr_time_ms );
	if( starttime <= curr_time ){
		return 1;	// settling time must be in the future
	}
	cycle_start_time = starttime;
	cycle_start_time_ms = start_ms;
	return 0;
}

/*
 * 	See header file
 */
void cySchedule( void )
{
	TCyTask *last;

	last = NULL;

	if ( cyState.scheduled != NULL ) {
		last = cyState.scheduled;
		cyState.scheduled = NULL;
	}

	if ( last == NULL ) {
		last = cyScheduleByRtc();
	}

	while ( last != NULL ) {
		if ( last != NULL ) {
			last = cyScheduleByLast( last );
		}
	}
}

/*
 * See header file
 */
uint8_t cyGetRTCTime( uint32_t *time, uint16_t *time_ms )
{
	rtc_utc_t tmp_time;
	uint16_t tmp_time_ms;
	rtc_get_time_date( &tmp_time, &tmp_time_ms );
	*time = tmp_time;
	*time_ms = tmp_time_ms;
	return 0;
}

/*
 * 	See header file
 */
void cyDispatch( void )
{
	TCyTask *task;
	uint32_t curr_tick = 0;
	int64_t diff = 0;
	task = cyState.scheduled;

	osDelay( MCU_WKUP_OFFSET_MS - (uint32_t)diff );

	curr_tick = osKernelSysTick( );
	if ( task != NULL ) {
		if ( task->state == CY_TASK_STATE_DO ) {

			if ( cyState.taskHandler != NULL ) {
				cyState.taskHandler( task, curr_tick );
			}

			if ( task->state != CY_TASK_STATE_REMOVE ) {
				task->state = CY_TASK_STATE_DONE;
			}

		}
	}

}

/*
 * 	See header file
 */
uint8_t cyRegisterTask( TCyTask *prototype )
{
	TCyTask *prev;
	TCyTask *task;

	task = NULL;

	if ( prototype->slot == 0xFFFF ) {
		return 1;
	}

	task = cyState.first;
	while ( task != NULL ) {
		if ( task->slot == prototype->slot ) {
			break;
		}
		task = task->next;
	}

	if ( task != NULL ) {

		if ( task->state != CY_TASK_STATE_REMOVE ) {
			return 1;
		}

		// Reuse removed task

	} else {

		// Find unused task

		task = (TCyTask *)pvPortMalloc( sizeof( TCyTask ) );

		if ( task == NULL ) {
			return 2;
		}

		// Insert new task

		task->slot = prototype->slot;
		task->subslot = prototype->subslot;

		if ( cyState.first == NULL ) {
			cyState.first = task;
			task->next = NULL;
		} else {
			if ( task->slot < cyState.first->slot ) {
				task->next = cyState.first;
				cyState.first = task;
			} else {
				prev = cyState.first;
				while ( TRUE ) {
					if ( prev->next == NULL ) {
						prev->next = task;
						task->next = NULL;
						break;
					} else {
						if ( task->slot < prev->next->slot ) {
							task->next = prev->next;
							prev->next = task;
							break;
						}
					}
					prev = prev->next;
				}
			}
		}
	}

	// Populate task

	task->type = prototype->type;
	task->wakeup_offset_ms = prototype->wakeup_offset_ms;
	task->state = CY_TASK_STATE_INACTIVE;

	return 0;
}

/*
 *	See header file
 */
void cyRemoveTask( uint16_t slot )
{
	TCyTask *task;
	task = cyState.first;
	while ( task != NULL ) {
		if ( task->slot == slot ) {
			task->state = CY_TASK_STATE_REMOVE;
			break;
		}
		task = task->next;
	}
}

/*
 *	See header file
 */
TCyTask *cyGetTask( uint16_t slot )
{
	TCyTask *task;
	task = cyState.first;
	while ( task != NULL ) {
		if ( task-> slot == slot ) {
			return task;
		}
		task = task->next;
	}
	return NULL;
}

/*
 * 	See header file
 */
TCyTask *cyGetFirstTask( void )
{
	return cyState.first;
}

/*
 * 	See header file
 */
void cyCleanup( void )
{
	TCyTask *task;
	TCyTask *old;
	task = cyState.first;
	while ( task != NULL ) {
		old = task;
		task = task->next;
		vPortFree( old );
	}
	cyState.first = NULL;
	cyState.scheduled = NULL;
}

/*
 * 	See header file
 */
void cyInitPrototype( TCyTask *prototype )
{
	prototype->type = 0;
	prototype->slot = 0xFFFF;
	prototype->wakeup_offset_ms = 0;
	prototype->subslot = 0;
}

/*
 * 	See header file
 */
void cyDumpTasks( void )
{
	cyInternalDumpTasks( NULL );
}

/*
 * 	See header file
 */
void cyRegisterTaskHandler( TaskHandler taskHandler )
{
	cyState.taskHandler = taskHandler;
}

/*
 * 	See header file
 */
void cyRegisterBeforeIssueHook( BeforeIssueHook beforeIssueHook )
{
	cyState.beforeIssueHook = beforeIssueHook;
}

/*
 * 	See header file
 */
void cyRegisterNewCycleHook( NewCycleHook hook )
{
	cyState.newCycleHook = hook;
}


/* internal functions definitions ------------------------------------------ */

/**
 * 	\brief	Remove task from list
 * 	\slot	slot number of the task to be removed
 */
static void cyDoRemoveTask( uint16_t slot )
{
	TCyTask *task;
	TCyTask *oldTask;

	if( cyState.first->slot == slot ) {

		oldTask = cyState.first;
		cyState.first = cyState.first->next;
		vPortFree( oldTask );

	} else {

		task = cyState.first;
		while ( task->next != NULL ) {
			if ( task->next->slot == slot ) {
				oldTask = task->next;
				task->next = task->next->next;
				vPortFree( oldTask );
				break;
			}
			task = task->next;
		}
	}
}

/**
 * 	\brief	Schedules task
 * 	\param	*task: task to be scheduled
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t cyScheduleTask( TCyTask *task )
{
	uint16_t inset;
	rtc_utc_t time_now;
	uint16_t time_now_ms;
	uint8_t ret = 0;

	// Dont schedule removed tasks!
	if ( task->state == CY_TASK_STATE_REMOVE ) {
		return 2;
	}

	// Time now
	rtc_get_time_date( &time_now, &time_now_ms );

	// If task to be scheduled is the first of the cycle
	if ( task == cyState.first ) {
		if( first_time ) {
			// Schedule was not called before
			first_time = 0;
			if( cycle_start_time != 0 ) {
				alarm.alarm_time = cycle_start_time;
				alarm.alarm_ms = cycle_start_time_ms;
				alarm.alarm_ms+= (task->subslot) * ptk_get_subslot_duration_ms();
				cy_correct_alarmtime_by_offset( &alarm );
				cy_adv_alarmtime_by_ms( &alarm, task->wakeup_offset_ms );
			}
		} else
		{
			// Set task start to next cycle start time
			cycle_start_time += ptk_get_cycle_duration_s( );
			alarm.alarm_time = cycle_start_time;
			alarm.alarm_ms = cycle_start_time_ms;
			alarm.alarm_ms += (task->subslot) * ptk_get_subslot_duration_ms();
			cy_correct_alarmtime_by_offset( &alarm );
			cy_adv_alarmtime_by_ms( &alarm, task->wakeup_offset_ms );
		}
	} else {
		// Set task start to given time defined by slot number
		if( cycle_start_time != 0){
			alarm.alarm_time = cycle_start_time;
			alarm.alarm_ms = cycle_start_time_ms;
			alarm.alarm_ms += ( task->slot * ptk_get_slot_duration_ms() );
			alarm.alarm_ms += ( task->subslot) * ptk_get_subslot_duration_ms();
			inset = 0;
				if ( cyState.beforeIssueHook != NULL ) {
					cyState.beforeIssueHook( task, &alarm.alarm_ms );
				}

			alarm.alarm_ms += inset;
			alarm.alarm_time += ( alarm.alarm_ms / 1000 );
			alarm.alarm_ms = alarm.alarm_ms % 1000;
			cy_correct_alarmtime_by_offset( &alarm );
			cy_adv_alarmtime_by_ms( &alarm, task->wakeup_offset_ms );
		}
	}

	// Schedule task
	alarm.alarm_cb = cy_on_alarm_event;
	ret = rtc_set_alarm( &alarm );

	if ( ret == RTC_OK ) {
		task->state = CY_TASK_STATE_SCHEDULED;
		cyState.scheduled = task;
	} else {
		dbgPrintf("Alarm set failed code %i\n",ret);
		dbgPrintf("T = %i\n",time_now);
		dbgPrintf("Failed task type %i\n", task->type );
		debug_log_append_line("Alarm set failed code %i\n",ret); // TODO: check timing
		debug_log_append_line("T = %i\n",time_now); // TODO: check timing
		debug_log_append_line("Failed task type %i\n", task->type ); // TODO: check timing
		ret = 1;
	}

	return ret;
}

/**
 *	\brief	Sets the alarm time earlier than defined by the
 *			slot number. This is necessary because the MCU
 *			needs a certain time to start up
 *	\param	*alrm: pointer to alarm structure which is corrected
 */
static uint8_t cy_correct_alarmtime_by_offset( rtc_alarm_t *alrm )
{
uint8_t nsecs;
	if( alrm == NULL ){
		return 1;
	}
#if USE_LOWPOWER == 1
	if( alrm->alarm_ms >= MCU_WKUP_OFFSET_MS ){
		alrm->alarm_ms -= MCU_WKUP_OFFSET_MS;
	} else {
		nsecs = MCU_WKUP_OFFSET_MS / 1000;
		alrm->alarm_time -= (nsecs + 1);
		alrm->alarm_ms = 1000 - ( MCU_WKUP_OFFSET_MS - alrm->alarm_ms );
	}
	return 0;
#else
#endif
}

/**
 * 	\brief	Advances alarm time by <ms> milliseconds
 * 	\param	*alrm	pointer to alarm struct to be advanced
 * 	\param	ms		number of milliseconds the alarm should be advanced
 * 	\return	return 0 on success, nonzero on error
 */
static uint8_t cy_adv_alarmtime_by_ms ( rtc_alarm_t *alrm, uint32_t ms )
{
	uint8_t nsecs = 0;
	if( alrm == NULL ){
		return 1;
	}
	if( alrm->alarm_ms >= ms ){
		alrm->alarm_ms -= ms;
	} else {
		nsecs = ms / 1000;
		alrm->alarm_time -= nsecs;
		alrm->alarm_ms = 1000 - ( ms - alrm->alarm_ms);
	}
	return 0;
}

/**
 * 	\brief	Schedule task by last task
 * 	\param	*last: pointer to last task
 * 	\return	returns pointer to next task
 */
static TCyTask * cyScheduleByLast( TCyTask *last ) {
	uint8_t rc;
	TCyTask *next;
	uint8_t changed;

	next = last->next;

	if ( last->state == CY_TASK_STATE_REMOVE ) {
		cyDoRemoveTask( last->slot );
	} else {
		last->state = CY_TASK_STATE_INACTIVE;
	}

	while ( TRUE ) {

		if ( next == NULL ) {

			if ( cyState.newCycleHook != NULL ) {
				changed = 0;
				cyState.newCycleHook( &changed );
			}

			next = cyState.first;

		}

		if ( next->state == CY_TASK_STATE_REMOVE ) {
			last = next;
			next = last->next;
			cyDoRemoveTask( last->slot );
		} else {
			break;
		}

	}

	rc = cyScheduleTask( next );

	if ( rc == 0 ) {
		return NULL;
	} else {
		return next;
	}
}

/**
 * 	\brief	Schedules next task by RTC
 * 	\return	pointer to next task
 */
static TCyTask *cyScheduleByRtc( void ) {
	//uint32_t sec;
	uint32_t slot;

	rtc_utc_t systime;
	uint16_t systime_ms;

	//LDD_RTC_TTime time;
	TCyTask *next;
	uint8_t rc;

	if( cycle_start_time != 0 ) {		// start time was set before
		systime = cycle_start_time;
	} else {
		rtc_get_time_date( &systime, &systime_ms );
		systime += 4;
		cycle_start_time = systime + 4;
	}

	slot = ( systime * 1000 );
	slot = ( slot / ptk_get_cycle_duration_s( ));

	next = cyState.first;
	while ( next != NULL ) {
		if ( next->slot >= slot ) {
			break;
		}
		next = next->next;
	}

	if ( next == NULL ) {
		next = cyState.first;
	}

	if ( next == NULL ) {
		return NULL;
	}

	rc = cyScheduleTask( next );

	if ( rc == 0 ) {
		return NULL;
	} else {
		return next;
	}
}

/*
 * 	\brief	Dumps all tasks
 */
static void cyInternalDumpTasks( TCyTask *next )
{
	TCyTask *task;
	task = cyState.scheduled;
	if ( next != NULL ) {
		dbgPrintf( "next: slot=%i, state=%i\n", next->slot, next->state );
	}
	if ( task != NULL ) {
		dbgPrintf( "sched: slot=%i, state=%i\n", task->slot, task->state );
	}
	task = cyState.first;
	while ( task != NULL ) {
		dbgPrintf( "task: slot=%i, state=%i\n", task->slot, task->state );
		task = task->next;
	}
	dbgPrintf( "---------------\n" );
}

/**
 *	\brief	Cycler alarm callback function
 */
static void cy_on_alarm_event ( void )
{
	latest_wakeup_tick = osKernelSysTick();
	if ( cyState.scheduled == NULL ) {
		return;
	}

	if( cyState.scheduled == cyState.first ){
		curr_cycle_start_time = cycle_start_time;
		curr_cycle_start_time_ms = cycle_start_time_ms + MCU_WKUP_OFFSET_MS;
		curr_cycle_start_time += curr_cycle_start_time_ms / 1000;
		curr_cycle_start_time_ms = curr_cycle_start_time_ms % 1000;
	}

	cyState.scheduled->state = CY_TASK_STATE_DO;
	cyState.t2Stamp = osKernelSysTick( );
	osSignalSet( runTaskHandle, OS_SIGN_RUN_TASK_RTC );
}
