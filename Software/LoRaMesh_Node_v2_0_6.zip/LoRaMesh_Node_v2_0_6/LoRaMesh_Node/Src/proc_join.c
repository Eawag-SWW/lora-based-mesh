/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		proc_join.c
 *
 * \description	Handle of join process
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include <stdint.h>
#include <stdlib.h>
#include "proc_join.h"
#include "task_run.h"
#include "loramesh.h"
#include "protocol_config.h"
#include "cmsis_os.h"
#include "utilities.h"
#include "rng.h"
#include "device_config.h"

#include "debug/debug.h"
#include "log/log.h"

/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/


/* -- RTOS globals ----------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */
static uint16_t wait_request( uint32_t timeout_ms );
static uint8_t send_join_request ( uint16_t dest_addr );

/* internal variable definitions ------------------------------------------- */ 
static uint8_t join_timeout_cnt = 0;
#ifdef USE_RANDOM_JOIN_WAIT
static uint8_t join_wait_cnt = 0;
#endif

/* public function definitions --------------------------------------------- */

/*
 * 	See header file
 */
uint8_t proc_join( ptk_core_state_s *pstate )
{
	osEvent evt;
	uint8_t ret;
	uint16_t jaddr;
	loramesh_joinresp_s jresp;
	uint8_t tmp = 0;
	switch( pstate->device_type ){
	case ( DEV_TYPE_REPEATER ):
			if( pstate->state != PTK_STATE_IN ){
				return 1;
			}
			jaddr = wait_request( 1000 );			// TODO: Set correct timeout
			tmp = ptk_process_join_request( jaddr );
			if( (tmp == 0) || (tmp == 5)){
				//success
				loramesh_send_join_response(
										pstate->join_agent.joinee_address,
										pstate->join_agent.confirm,
										pstate->join_agent.joinee_beacon_window,
										pstate->join_agent.slots.join_ul_slot,
										pstate->join_agent.slots.join_dl_slot,
										pstate->join_agent.slots.parent_slot,
										pstate->join_agent.joinee_subslot);
				dbgPrintf("R, Join request processed from node %i\n", jaddr);
				evt = osSignalWait( OS_SIGN_MESH_TX_DONE, 1000 ); // TODO: set correct timeout
				if( check_is_signal_set( &evt, OS_SIGN_MESH_TX_DONE )){
					pstate->join_agent.type = JOIN_TYPE_NONE;
					pstate->join_agent.role = JOIN_ROLE_NONE;
					pstate->join_agent.state = JOIN_STT_NONE;
					dbgPrintf("R, Join response sent\n");
					dbgPrintf("SS = %i\n",pstate->join_agent.joinee_subslot);
					ret = 0;
				} else {
					dbgPrintf("R, Join response TX timeout\n");
					debug_log_append_line("R, Join response TX timeout\n"); //TODO: SD: Timing probably not critical
					ret = 1;
				}
			}else if(tmp==2)
			{
				// No free slots
				loramesh_send_join_response(
						jaddr,
						JOIN_NACK,
						0,
						0,
						0,
						0,
						0);
				dbgPrintf("R, Join request processed from node %i with NACK\n", jaddr);
				evt = osSignalWait( OS_SIGN_MESH_TX_DONE, 1000 ); // TODO: set correct timeout
				if( check_is_signal_set( &evt, OS_SIGN_MESH_TX_DONE )){
					dbgPrintf("R, Join response sent NACK\n");
					ret = 0;
				} else {
					dbgPrintf("R, Join response TX timeout\n");
					debug_log_append_line("R, Join response TX timeout\n"); //TODO: SD: Timing probably not critical
					ret = 1;
				}
			}
		break;
	case ( DEV_TYPE_NODE ):
			if( pstate->state == PTK_STATE_IN ) {
				// node is in network --> start listening
			} else if (pstate->state == PTK_STATE_JOINING ){
				if( pstate->join_agent.role != JOIN_ROLE_JOINEE ){
					return 1;
				}
#ifdef USE_RANDOM_JOIN_WAIT
				if(join_wait_cnt%RANDOM_JOIN_WAIT_MAX==0)
				{
					if( send_join_request( pstate->join_agent.fav_address ) != 0){
						// TX error
						return 1;
					}
				}else
				{
					join_wait_cnt++;
					dbgPrintf("N, Join skipped\n");
					dbgPrintf("N, Next join attempt in %i cycles\n", RANDOM_JOIN_WAIT_MAX-join_wait_cnt);
					return 1;
				}
#else
				if( send_join_request( pstate->join_agent.fav_address ) != 0){
					// TX error
					return 1;
				}
#endif
				dbgPrintf("N, Join request sent\n");
				// direct join request-----------------------------------------
				if( pstate->join_agent.type == JOIN_TYPE_DIRECT ){
					if( loramesh_receive( ) != LORAMESH_OK){
						//TODO: Error handling
					}
					evt = osSignalWait( OS_SIGN_MESH_JRES_RX, ptk_get_jreq_timeout());
					if( check_is_signal_set( &evt, OS_SIGN_MESH_JRES_RX )){
						//debug_gpio_pb10_reset( );
						ptk_get_latest_jresp( &jresp );
						dbgPrintf("N, Join response received from %i\n", jresp.source_address);
						dbgPrintf("N, beacon window: %i,\n",jresp.forwarding_window);
						if( jresp.source_address == pstate->join_agent.fav_address){
							if( jresp.confirmation == JOIN_ACK ){
								pstate->join_agent.confirm = jresp.confirmation;
								pstate->join_agent.joinee_beacon_window = jresp.forwarding_window;
								pstate->join_agent.slots.join_dl_slot = jresp.downlink_slot_nr;
								pstate->join_agent.slots.join_ul_slot = jresp.uplink_slot_nr;
								pstate->join_agent.slots.parent_slot = jresp.parent_slot;
								pstate->join_agent.joinee_subslot = jresp.subslot_nr;
								ptk_process_join_response( );
								join_timeout_cnt = 0;
								// join accepted
							}else if( jresp.confirmation == JOIN_NACK ){ // join not acknowledged
								dbgPrintf("N, Join request NACK from agent %i\n", pstate->join_agent.fav_address );
								ptk_core_join_error_handler( );
							}
						} else { // Join response not from correct join agent
							// TODO: Search other join agent
						}
					} else {	// join timeout
						join_timeout_cnt++;
						if( join_timeout_cnt >= ptk_get_max_join_timeouts()){
							dbgPrintf("N, Max join timeouts\n");
							dbgPrintf("From join agent %i\n", pstate->join_agent.fav_address );
							debug_log_append_line("N, Max join timeouts\n"); //TODO: check timing
							debug_log_append_line("From join agent %i\n", pstate->join_agent.fav_address ); //TODO: check timing
							ptk_core_join_error_handler( );
							join_timeout_cnt = 0;
						}
#ifdef USE_RANDOM_JOIN_WAIT
						else
						{
							join_wait_cnt=(rng_get_random_number()%RANDOM_JOIN_WAIT_MAX);
							if(join_wait_cnt==0)
							{
								dbgPrintf("N, Join timeout. Wait count set to 0 cycles\n");
							}else
							{
								dbgPrintf("N, Join timeout. Wait count set to %i cycles\n", RANDOM_JOIN_WAIT_MAX-join_wait_cnt);
							}
						}
#endif
						return 1;
					}
				// indirect join request---------------------------------------
				} else if (pstate->join_agent.type == JOIN_TYPE_INDIRECT ){
					join_timeout_cnt++;
					if( join_timeout_cnt >= ptk_get_max_join_timeouts()){
						dbgPrintf("N, Max join timeouts\n");
						dbgPrintf("From join agent %i\n", pstate->join_agent.fav_address );
						debug_log_append_line("N, Max join timeouts\n"); //TODO: check timing
						debug_log_append_line("From join agent %i\n", pstate->join_agent.fav_address ); //TODO: check timing
						ptk_core_join_error_handler( );
						join_timeout_cnt = 0;
					}
					// TODO: register approve slot
					//loramesh_radio_stop( );
				} else {
					loramesh_radio_stop( );
				}

			} else {
				// error
				return 1;
			}
		break;
	default:
		ret = 1;
		break;
	}
	return ret;;
}



/* internal functions definitions ------------------------------------------ */

/*
 * 	\brief	Waits for a join request
 * 	\param	timeout_ms: 	timeout in milliseconds
 * 	\return	returns address of the requesting node (nonzero), zero otherwise
 */
static uint16_t wait_request( uint32_t timeout_ms )
{
	osEvent evt;
	if( loramesh_receive( ) != LORAMESH_OK ){
		return 0;
	}
	evt = osSignalWait( OS_SIGN_MESH_JREQ_RX, timeout_ms );
	if( check_is_signal_set( &evt, OS_SIGN_MESH_JREQ_RX )){
		loramesh_radio_stop();
		return ptk_get_latest_jreq();
	} else {
		loramesh_radio_stop();
		return 0;
	}

}

/**
 * 	\brief	Send a join request to specified parent node
 * 	\param	dest_addr:	address of desired parent node
 * 	\return returns 0 on success, nonzero otherwise
 */
static uint8_t send_join_request ( uint16_t dest_addr )
{
	osEvent evt;
	if( loramesh_send_join_request( dest_addr ) != LORAMESH_OK ){
		return 1;
	}
	evt = osSignalWait( OS_SIGN_MESH_TX_DONE, 1000 );
	if( check_is_signal_set( &evt, OS_SIGN_MESH_TX_DONE )){
		return 0;
	} else {
		return 1;
	}
}


