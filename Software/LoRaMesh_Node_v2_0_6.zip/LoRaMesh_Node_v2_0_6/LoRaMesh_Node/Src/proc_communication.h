/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		proc_communication.c
 *
 * \description	Handles LoRaMesh up- and downlink communication
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		Oct. 2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _PROC_COMM_H
#define _PROC_COMM_H

/* -- includes --------------------------------------------------------------*/
#include <stdint.h>
#include "protocol_core.h"

/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/


/* public function declarations -------------------------------------------- */
/**
 * 	\brief	Handles uplink receive process
 * 	\param	*pstate	pointer to current state of the protocol core
 * 	\return returns 0 on success, nonzero on error
 */
uint8_t proc_comm_ul_rx( ptk_core_state_s *pstate );

/**
 * 	\brief	Handles uplink transmit process (sends stored data to parent node)
 * 	\param	*pstate	pointer to current state of the protocol core
 * 	\param	task_start_time	32-bit UTC time of task start
 */
uint8_t proc_comm_ul_tx( ptk_core_state_s *pstate, uint32_t task_start_time );

/**
 * 	\brief	Interface to store uplink data for parent node
 * 	\param	*pdata	pointer to data
 * 	\param	len		length of the data
 * 	\param	ul_dst_addr	destination address of the data
 */
uint8_t comm_store_ul_tx_data( uint8_t *pdata, uint8_t len, uint16_t ul_dst_addr );

/**
 *	\brief	Callback function for the RTOS timer
 */
void commtimer_on_timeout( void const *arg );

/**
 *	\brief	Stores measurement data in the uplink buffers
 *	\param	dest_addr:	destination address of the data
 *	\param	vbat:		actual battery voltage in millivolts
 *	\param	rssi:		actual RSSI value to parent node
 *	\param	timestamp:	timestamp of measurement
 *	\param	sensortype:	used type of sensor
  *	\param	sensordata:	measured data
 */
uint8_t comm_store_meas_data( uint16_t dest_addr, uint16_t vbat, int16_t rssi,
							  uint32_t timestamp, uint8_t sensortype,
							  uint16_t sensordata );

/**
 * 	\brief	Resets the uplink counter
 */
void com_reset_ulcounter( void );

#endif	//_PROC_COMM_H

