/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		proc_communication.c
 *
 * \description	Handles LoRaMesh up- and downlink communication
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		Oct. 2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "proc_communication.h"
#include "protocol_config.h"
#include "loramesh.h"
#include "cmsis_os.h"
#include "task_run.h"
#include "utilities.h"
#include "stdlib.h"
#include "subslot_handler.h"
#include "debug/debug.h"
#include "log/log.h"
#include "string.h"
#include "proc_lorawan.h"

/* -- makros ----------------------------------------------------------------*/
#define PROTOCOL_VERSION	1
typedef struct	pkt_pl	{
		uint8_t 	pl_len;
		uint16_t	pkt_num;
		uint8_t		status;
		uint8_t		*pl;
} pkt_pl_s;


typedef struct 	pkt	{
		uint16_t	dest;
		uint16_t	src;
		uint8_t		type;
		pkt_pl_s	*payload;
		struct	pkt	*next;
} ptk_s;

typedef struct data_buffer {
							// address of child node to which data should be sent
							uint16_t node_address;
							uint8_t  num_bytes;		// number of bytes to be sent
							uint8_t  *data;			// pointer to data buffer
							struct data_buffer *next;
} data_buffer_s;


/* -- type definitions-------------------------------------------------------*/

/* RTOS globals -------------------------------------------------------------*/
extern osTimerId commTimerHandle;

/* internal function declarations ------------------------------------------ */
static data_buffer_s* entry_exists_for_node( 	data_buffer_s *rbhead,
												uint16_t addr );
static uint8_t store_data_to_buffer( 	data_buffer_s *buff,
										uint16_t dest_address,
										uint8_t *data, uint8_t data_len);
static uint8_t clear_ringbuffer_entry( data_buffer_s *rb, uint16_t naddr );
static uint8_t convert_senstype_protvers(uint8_t sensortype, uint8_t pversion);
static uint8_t convert_vbat_rssi( uint16_t vbat, int16_t rssi );
static uint8_t convert_rssi( int16_t rssi );

/* internal variable definitions ------------------------------------------- */
static uint16_t ul_counter = 0;
static uint8_t ul_timeout_counter = 0;
static uint8_t fl_to = FALSE;
static data_buffer_s *ul_txbuff_head;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
uint8_t proc_comm_ul_rx( ptk_core_state_s *pstate )
{
	osEvent evt;
	loramesh_rx_data_s data;
	uint32_t duration = 0;
	uint8_t num_expired;
	uint8_t i = 0;
	uint16_t addr_expired[ptk_get_num_network_nodes()];

	fl_to = FALSE;
	osTimerStart( commTimerHandle, ptk_get_slot_duration_ms() - 100 );	//TODO: correct timeout
	loramesh_receive( );
	subslot_handler_increment_all_timeouts( );

	while( fl_to == FALSE ){
		evt = osSignalWait( OS_SIGN_MESH_RX_DONE, 1);	//TODO: correct timeout
		if( check_is_signal_set( &evt, OS_SIGN_MESH_RX_DONE )){
			ptk_get_rx_data( &data );
			if( (data.data_header.status & LORAMESH_FLSTT_PIGGIBACKED) &&
											LORAMESH_FLSTT_PIGGIBACKED ){
				// TODO: handle piggibacked commands
			}
			subslot_handler_reset_timeout_for_node( data.source_address );
			switch( pstate->device_type ){
			case( DEV_TYPE_REPEATER ):
				dbgPrintf("R, data received from node %i\n", data.source_address);
				dbgPrintf("R, received packet counter = %i\n", data.data_header.pkt_num);
				osDelay(2); //TODO: check duration of this delay (rx-tx swap)
				// TODO: store data to LoRaWAN buffer
				lorawan_store_txdata(data.source_address, data.data, data.data_header.payload_len);
				duration = loramesh_get_toa_conf( );
				loramesh_send_confirmation( data.source_address, LORAMESH_ACK );
				evt = osSignalWait( OS_SIGN_MESH_TX_DONE, ((duration * 3) >> 1));
				if( check_is_signal_set( &evt, OS_SIGN_MESH_TX_DONE)){
					dbgPrintf("R, Acknowledge sent\n");
				} else {
					dbgPrintf("R, Acknowledge send timeout\n");
					debug_log_append_line("R, Acknowledge send timeout\n"); // TODO: SD: Timing critical!!
				}
				break;
			case( DEV_TYPE_NODE ):
				dbgPrintf("N, data received from node %i\n", data.source_address);
				dbgPrintf("N, received packet counter = %i\n", data.data_header.pkt_num);
				comm_store_ul_tx_data( data.data, data.data_header.payload_len, pstate->parent_address);
				duration = loramesh_get_toa_conf( );
				loramesh_send_confirmation( data.source_address, LORAMESH_ACK );
				evt = osSignalWait( OS_SIGN_MESH_TX_DONE, ((duration * 3) >> 1));
				if( check_is_signal_set( &evt, OS_SIGN_MESH_TX_DONE)){
					dbgPrintf("N, Acknowledge sent\n");
				} else {
					dbgPrintf("N, Acknowledge send timeout\n");
					debug_log_append_line("N, Acknowledge send timeout\n"); // TODO: check timing
				}
				break;
			default:
				// error
				break;
			}
			loramesh_receive( );	// restart receive process
		}
	}
	loramesh_radio_stop( );
	subslot_handler_get_expired_timeouts( ptk_get_max_ul_timeouts(),
										  &num_expired,
										  addr_expired );
	if( num_expired > 0 ){
		for(i=0; i<num_expired; i++ ){
			dbgPrintf("Uplink expired for node %i\n", *(addr_expired + i));
			debug_log_append_line("Uplink expired for node %i\n", *(addr_expired + i)); // TODO: SD: Timing probably not critical
			subslot_handler_deregister_subslot( *(addr_expired + i));
			ptk_node_exited( *(addr_expired + i));
		}
	}
	return 0;
}

/**
 * 	See header file
 */
uint8_t proc_comm_ul_tx( ptk_core_state_s *pstate, uint32_t task_start_time )
{
	osEvent evt;
	data_buffer_s *tbuf;
	uint32_t duration;
	uint8_t err = 0;

	if( (tbuf =  entry_exists_for_node( ul_txbuff_head, pstate->parent_address)) != NULL){ //data ready to send
		duration = loramesh_get_toa_data( tbuf->num_bytes );
		if( loramesh_send_data( tbuf->node_address,
								tbuf->num_bytes,
								tbuf->data) != LORAMESH_OK){
			err = 1;
		}
		evt = osSignalWait( OS_SIGN_MESH_TX_DONE, 2 * duration  );
		if( check_is_signal_set( &evt, OS_SIGN_MESH_TX_DONE )){
			err = 0;
		} else {
			err = 1;
		}
		clear_ringbuffer_entry( ul_txbuff_head, tbuf->node_address );
		if( err == 0 ){
			dbgPrintf("N, Data sent\n");
		} else {
			dbgPrintf("N, Data send error %i\n", err);
			debug_log_append_line("N, Data send error %i\n", err); // TODO: check timing
		}

		loramesh_receive();
		evt = osSignalWait( OS_SIGN_MESH_CONF_RX, ptk_get_ack_timeout());
		if( check_is_signal_set( &evt, OS_SIGN_MESH_CONF_RX)){
			if( ptk_get_latest_conf() == LORAMESH_ACK){
				dbgPrintf("N, Acknowledge received: %i\n", ptk_get_latest_conf());
				err  = 0;
				ul_counter++;
				ul_timeout_counter = 0;
			} else {
				dbgPrintf("N, Acknowledge not confirmed %i\n", ptk_get_latest_conf());
				debug_log_append_line("N, Acknowledge not confirmed %i\n", ptk_get_latest_conf()); // TODO: check timing
				err = 1;
				ul_timeout_counter++;
			}
		} else {
			dbgPrintf("N, Acknowledge timeout, count= %i\n", ul_timeout_counter);
			debug_log_append_line("N, Acknowledge timeout, count= %i\n", ul_timeout_counter); // TODO: check timing
			ul_timeout_counter++;
		}
		loramesh_radio_stop( );
	} else {
		// no data to send
	}
	if( ul_timeout_counter > ptk_get_max_ul_timeouts()){
		dbgPrintf("N, max ultimeouts reached\n");
		debug_log_append_line("N, max ultimeouts reached\n"); // TODO: check timing
		ul_timeout_counter = 0;
		ul_counter = 0;
		ptk_core_reset( );
	}
	return err;
}


/*
 * 	See header file
 */
uint8_t comm_store_ul_tx_data( uint8_t *pdata, uint8_t len, uint16_t ul_dst_addr )
{
	if( ul_txbuff_head == NULL ){
		ul_txbuff_head = pvPortMalloc( sizeof( data_buffer_s ));
		if( ul_txbuff_head == NULL ){
			return 1;
		}
		ul_txbuff_head->node_address = 0;
		ul_txbuff_head->num_bytes = 0;
		ul_txbuff_head->data = NULL;
		ul_txbuff_head->next = NULL;
	}
	if( store_data_to_buffer( ul_txbuff_head, ul_dst_addr, pdata, len ) != 0 ){
		dbgPrintf("Data storage failed\n");
		debug_log_append_line("Data storage failed\n"); // TODO: check timing

		return 1;
	}
	dbgPrintf("Data storage done\n");
	return 0;
}

/*
 * 	See header file
 */
uint8_t comm_store_meas_data( uint16_t dest_addr, uint16_t vbat, int16_t rssi,
							  uint32_t timestamp, uint8_t sensortype,
							  uint16_t sensordata )
{
	uint8_t *tbuff = NULL;

	tbuff = pvPortMalloc( sizeof(uint8_t) * ( 8 ));
	if( tbuff == NULL ){
		return 1;
	}
	*tbuff = convert_vbat_rssi( vbat, rssi );
	*(tbuff + 1) = convert_senstype_protvers( sensortype, PROTOCOL_VERSION);
	*(tbuff + 2) = B3_32TO8( timestamp );
	*(tbuff + 3) = B2_32TO8( timestamp );
	*(tbuff + 4) = B1_32TO8( timestamp );
	*(tbuff + 5) = B0_32TO8( timestamp );
	*(tbuff + 6) = B1_16TO8( sensordata );
	*(tbuff + 7) = B0_16TO8( sensordata );
	comm_store_ul_tx_data( tbuff, 8, dest_addr );
	vPortFree( tbuff );
	return 0;
}

/*
 *	See header file
 */
void com_reset_ulcounter( void )
{
	ul_counter = 0;
}

/*
 *	See header file
 */
void commtimer_on_timeout( void const *arg )
{
	fl_to = TRUE;
}

/* internal functions definitions ------------------------------------------ */


/**
 * 	\brief	Stores new data into the buffer
 * 	\param	*rbhead			pointer to head of the ring buffer
 * 	\param	dest_address	destination address of the data
 * 	\param	*data			pointer to the data
 * 	\param	data_len		length of the data
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t store_data_to_buffer( data_buffer_s *rbhead, uint16_t dest_address,
									 uint8_t *data, uint8_t data_len)
{
	data_buffer_s *prev;
	data_buffer_s *next;
	data_buffer_s *tmp;


	if( rbhead == NULL ){
		return 1;
	}

	prev = rbhead;

	// check first element
	if( (rbhead->node_address == 0) && (rbhead->next == NULL)){
		rbhead->data = pvPortMalloc( sizeof(uint8_t) * data_len );
		if( rbhead->data == NULL ){
			return 1;
		}
		memcpy( rbhead->data, data, data_len);
		rbhead->node_address = dest_address;
		rbhead->num_bytes = data_len;
		return 0;
	}

	// check if buffer is already available and insert data
	while( prev != NULL ) {
		if( prev->node_address == dest_address ){	// head is buffer for node
			prev->data = realloc( prev->data, (prev->num_bytes + data_len));
			memcpy( prev->data + prev->num_bytes, data, data_len);
			prev->num_bytes+= data_len;
			break;
		}
		prev = prev->next;
	}

	if( prev == NULL ){	// no entry for desired node yet, append it to ringbuffer
		prev = rbhead;
		next = rbhead->next;

		while( 1 ){
			if( prev->node_address == 0 ){
				if( prev->data != NULL ){
					vPortFree( prev->data );
				}
				prev->data = pvPortMalloc( sizeof(uint8_t) * data_len );
				if(prev->data == NULL ){
					return 1;
				}
				memcpy( prev->data, data, data_len );
				prev->node_address = dest_address;
				prev->num_bytes = data_len;
				break;
			}
			if( next != NULL ){
				prev = next;
				next = next->next;
			} else {
				tmp = pvPortMalloc(sizeof(data_buffer_s));
				if( tmp == NULL ){
					return 2;
				}
				tmp->data = pvPortMalloc(sizeof(uint8_t) * data_len );
				if( tmp->data == NULL ){
					return 3;
				}
				memcpy( tmp->data, data, data_len );
				tmp->node_address = dest_address;
				tmp->num_bytes = data_len;
				tmp->next = NULL;
				prev->next = tmp;
				break;
			}
		}
	}
	return 0;
}

/*
 * 	\brief	Checks if a buffer for the given node address is already available
 * 	\param	*buff	pointer to head of ringbuffer
 * 	\param	addr	specifies address for sending data to
 * 	\return	returns NULL when no buffer exists, returns address to buffer
 * 			otherwise
 */
static data_buffer_s* entry_exists_for_node( data_buffer_s *rbhead, uint16_t addr )
{
	data_buffer_s *tbuff = NULL;

	if( rbhead == NULL ){
		return NULL;
	}
	tbuff = rbhead;
	while( tbuff != NULL ){
		if( tbuff->node_address == addr ){
			return tbuff;		// buffer found
		}
		tbuff = tbuff->next;
	}
	return NULL; // no buffer found
}

/*
 * \brief	Clears data from the ringbuffer
 * \param	*rb		pointer to the head of the ringbuffer
 * \param	naddr	address of the node whichs data should be deleted
 *
 */
static uint8_t clear_ringbuffer_entry( data_buffer_s *rb, uint16_t naddr )
{
	data_buffer_s *prev;
	data_buffer_s *next;
	uint8_t not_found = 1;

	prev = rb;

	if( prev->node_address == naddr ){	// searched entry is head of ringbuffer
		if( prev->next != NULL ){
			// set ringbuffer to next entry
			//rb = prev->next;
			dbgPrintf("ERROR comm line 649\n");
			debug_log_append_line("ERROR comm line 649\n"); //TODO: SD: Timing probably not critical
		}
		prev->node_address = 0;
		prev->num_bytes = 0;
		prev->next = NULL;
		vPortFree( prev->data );
		not_found = 0;
		//dbgPrintf("Head cleared\n");
		return 0;
	} else {
		while( prev != NULL ){
			next = prev->next;
			if( next->node_address == naddr ){
				prev->next = next->next;
				next->next = NULL;
				next->node_address = 0;
				vPortFree(next->data);
				next->num_bytes = 0;
				vPortFree( next );
				not_found = 0;
				break;
			}
		}
	}
	return not_found;
}

/*
 * 	\brief	Converts sensortype and protocol version into one byte value
 * 			value into one byte
 *			| 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
 *			| Sensortype    |ProtocolVersion|
 *	\param	sensortype	Type of used sensor
 *	\param  pversion	Used protocol version
 *	\return	returns combined value as mentioned above
 */
static uint8_t convert_senstype_protvers( uint8_t sensortype, uint8_t pversion )
{
	return ((sensortype<<4) & 0xF0) | (pversion & 0x0F);
}

/*
 * 	\brief	Converts the battery voltage value and the RSSI
 * 			value into one byte
 *			| 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
 *			|      Vbat     |     RSSI      |
 *			Vbat: Range from 1.6 to 3.1 V in 0.1 V steps
 *			RSSI: Range from -127dBm to -37 dBm in 6dB steps
 *	\param	Measured battery voltage in millivolts
 *	\param  RSSI value in dBm
 *	\return	returns Combined Vbat and RSSI byte as mention above
 */
static uint8_t convert_vbat_rssi( uint16_t vbat, int16_t rssi )
{
	uint8_t bat = 0;
	uint8_t trssi = 0;


	bat = convert_vbat( vbat );
	trssi = convert_rssi( rssi );
	return((bat<<4) | trssi );


}

/*
 * 	\brief	Converts 16 bit signed rssi value to 4 bit RSSI value
 * 	\param	rssi	rssi value
 * 	\return	Returns 4 byte battery voltage value from -127dBm to -37dBm
 * 			in 6dB steps
 *
 * 			return value
 * 		  	^
 * 		  15|                   -------
 * 			|                  /
 * 			|                 /
 * 			|                /
 * 			|               /
 * 			|              /
 * 			|			  /
 * 		   0_____________/______________________>rssi
 * 		   -inf        -127  -37
 */
static uint8_t convert_rssi( int16_t rssi )
{
	if( rssi <= -127 ){
		return 0;
	}
	if( rssi >= -37 ){
		return 15;
	}
	return (uint8_t)((rssi + 127)/6);

}
