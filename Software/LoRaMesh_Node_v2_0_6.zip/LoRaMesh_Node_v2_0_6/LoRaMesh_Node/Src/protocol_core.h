/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		protocol_core.h
 *
 * \description	This is the main control element of the whole software.
 * 				The protocol core is responsible for handling tasks
 * 				and compute requests and responses
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _PROTOCOL_CORE_H
#define _PROTOCOL_CORE_H

/* -- includes --------------------------------------------------------------*/
#include "loramesh.h"
#include "cycler.h"

/* -- makros ----------------------------------------------------------------*/
#define PTK_MODE_SETUP 0
#define PTK_MODE_RUN 1

/* -- OS Signal definitions--------------------------------------------------*/

/* -- Makros ----------------------------------------------------------------*/
/** Reset values for the protocol core state								 */
#define HOP_COUNT_RESET_VAL			0xFF
#define LINK_QUALITY_RESET_VAL		0x00
#define SUBNET_ID_RESET_VAL			0
#define BEACON_WINDOW_RESET_VAL		0xFF
#define SLOT_UL_RESET_VAL			0xFF
#define SLOT_DL_RESET_VAL			0xFF
#define SLOT_PARENT_UL_RESET_VAL	0xFF
#define SUBSLOT_PARENT_UL_RESET_VAL	0xFF
#define PARENT_ADDR_RESET_VAL		0


/* -- type definitions-------------------------------------------------------*/
typedef enum {
				PTK_OK = 0,
				PTK_ERR_UNSPECIFIED,
				PTK_ERR_DEVICETYPE,
				PTK_ERR_NULLPOINTER,
				PTK_ERR_CONFIG
}ptk_errors_t;

typedef enum {	DEV_TYPE_UNKNOWN = 0,
				DEV_TYPE_REPEATER,
				DEV_TYPE_NODE
}dev_type_t;

typedef enum { 	PTK_STATE_RESET 	= 0,
				PTK_STATE_JOINING,
				PTK_STATE_IN
}protocol_states_t;

typedef enum {	JOIN_ROLE_NONE = 0,
				JOIN_ROLE_AGENT,
				JOIN_ROLE_JOINEE
}join_role_t;

typedef enum {
				JOIN_TYPE_NONE = 0,
				JOIN_TYPE_DIRECT,
				JOIN_TYPE_INDIRECT
}join_type_t;

typedef enum {
				JOIN_STT_NONE = 0,
				JOIN_STT_PREPARED,
				JOIN_STT_READY,
				JOIN_STT_SENT,
				JOIN_STT_WAIT_APPROVE,
				JOIN_STT_SEND_CONFIRM
}join_state_t;

typedef enum {
				JOIN_ACK = 0,
				JOIN_NACK
}join_confirm_t;

typedef struct {
					uint8_t join_ul_slot;
					uint8_t join_dl_slot;
					uint8_t parent_slot;
}join_slots_t;

typedef struct  join_agent {
					join_type_t type;
					join_role_t role;
					join_state_t state;
					join_confirm_t confirm;
					join_slots_t slots;
					uint8_t 	agent_hop_count;
					uint8_t		agent_subnet_id;
					uint16_t	fav_address;
					uint16_t 	joinee_address;
					uint8_t 	joinee_beacon_window;
					uint8_t 	joinee_subslot;
					struct join_agent *next;
}join_agent_s;

typedef enum { 	SLOT_FREE = 0,
				SLOT_USED
}slot_states_t;

typedef struct { 	slot_states_t slot_state;
					uint16_t node_address;
					//uint8_t conn_counter;
}slot_s;


typedef struct routing_dest {
			uint16_t address;
			struct routing_dest *next;
}routing_dest_s;

typedef struct routing_item_node {
			uint16_t address;
			uint8_t slot_dl;
			routing_dest_s *dest;
			struct routing_item_node *next;
}routing_item_node_s;

typedef struct routing_item_rep {
			uint16_t address;
			uint8_t slot_dl;
			uint8_t slot_ul;
			struct routing_item_rep *parent;
			struct routing_item_rep *next;
}routing_item_rep_s;

typedef struct {
	/**	common parameters and states			*/
	dev_type_t 			device_type;	/**< Device type (node/repeater)	 */
	protocol_states_t 	state;			/**< State of the protocol core		 */
	uint8_t 			hop_count;		/**< Number of hops to a repeater	 */
	uint8_t 			link_quality;	/**< Link quality to the next node	 */
	int16_t				link_rssi;		/**< RSSI value to parent node		 */
	uint8_t 			subnet_id;		/**< Subnet-id						 */
	uint8_t				beacon_window;	/**< window used to forward beacons	 */
	uint8_t				slot_ul;		/**< rx slot for device in uplink phase*/
	uint8_t				slot_dl;		/**< rx slot for device in downlink phase*/
	uint8_t				slot_parent_ul;	/**< rx slot for device's parent in UL*/
	uint8_t 			subslot_parent_ul; /**< the parent's subslots		 */
	uint16_t			address;		/**< own device address				 */
	uint16_t 			parent_address; /**< address of the parent node		 */
	join_agent_s		join_agent;		/**< join agent handle				 */
	slot_s				*slots_dl;		//TODO: Move to repeater specific buffer
	slot_s				*slots_ul;		//TODO: Move to repeater specific buffer
	routing_item_rep_s	*routing_tree;	/**< routing tree (case of repeater) */
	routing_item_node_s *routing_item;	/**< routing tree (case of node)	 */
}ptk_core_state_s;

/* public function declarations -------------------------------------------- */

/**
 *  \brief  Initializes the protocol core
 *  \return error code
 */
ptk_errors_t ptk_core_init( void );

/**
 * 	\brief	This function is called everytime the device enters low power
 *			mode.
 *	\return	error code
 */
ptk_errors_t ptk_before_lp( void );

/**
 * 	\brief	Starts the initial synchronization process
 * 	\return	error code
 */
ptk_errors_t ptk_init_sync( void );

/**
 * 	\brief	Sets the device type in the proctol core state
 * 	\type	Device type to be set
 * 	\return	error code
 */
ptk_errors_t ptk_set_device_type( dev_type_t type );

/**
 * 	\brief	Sets the desired join agent (parent) in the protocol core
 * 	\param	agent_address	address of the favourite join agent
 */
void ptk_set_join_agent( uint16_t agent_address );

/**
 * 	\brief	Sets the join task
 */
void ptk_set_join_task( void );

/**
 * 	\brief	Starts a join request process
 * 	\param	joinee_address	address of the joining node
 * 	\return returns 0 on success, nonzero otherwise
 */
uint8_t ptk_process_join_request ( uint16_t joinee_address );

/**
 * 	\brief	Processes a received join response
 * 	\return	returns 0 on success, nonzero otherwise
 */
uint8_t  ptk_process_join_response( void );

/**
 * 	\brief	Stores data of the latest received beacon into a buffer
 * 	\param	*pkt	pointer to buffer where data can be stored
 */
void ptk_get_latest_beacon ( loramesh_sync_s *pkt );

/**
 * 	\brief	Get the address of the latest joinee
 * 	\return	Address of the joinee node
 */
uint16_t ptk_get_latest_jreq( void );

/**
 * 	\brief	Stores data of the latest received join response into a buffer
 * 	\param	*resp	pointer to buffer where data can be stored
 */
void ptk_get_latest_jresp( loramesh_joinresp_s *resp );

/**
 * 	\brief	Stores data of the latest received data packet into a buffer
 * 	\param	*dptr	pointer to buffer where data can be stored
 */
void ptk_get_rx_data( loramesh_rx_data_s *dptr );

/**
 * 	\brief	Returns state of the latest confirmation packet (ACK/NACK)
 * 	\return	ACK / NACK
 */
loramesh_conf_t ptk_get_latest_conf( void );

/**
 * 	\brief	Resets the protocol core
 * 			This function is called when a node looses connection to network
 */
void ptk_core_reset( void );

/**
 * 	\brief	Notifies the protocol core, that a child node has exicted the
 * 			network (e.g. by loosing connection)
 * 	\return	return 0 when node is successfully deleted from all handler entries
 * 			nonzero otherwise
 */
uint8_t ptk_node_exited( uint16_t node_addr );

/**
 * 	\brief	Checks if a given node is in the ignore list
 * 	\param	Address to be checked
 * 	\return	0 if node is NOT in ignore list, nonzero otherwise
 */
uint8_t pkt_core_node_is_in_ignore_list( uint16_t addr );

/**
 *	\brief	Notifies the protocol core that a join timeout has happend
 *			(A node tried to join multiple times at the same join agent)
 */
void ptk_core_join_error_handler( void );

#endif	// _PROTOCOL_CORE_H

