/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		proc_sync.c
 *
 * \description	Handles synchronization process
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "proc_sync.h"
#include "task_run.h"
#include <stdlib.h>
#include <string.h>
#include "cmsis_os.h"
#include "loramesh.h"
#include "utilities.h"
#include "cycler.h"
#include "protocol_core.h"
#include "debug/debug.h"
#include "log/log.h"
#include "protocol_config.h"
#include "device_config.h"

/* -- makros ----------------------------------------------------------------*/
#define SYNC_PACKET_TIMEOUT_S 	3	/**< Timeout for sending sync packet [s] */
#define COMP_TIME_MS 			5	/**< Computing time [ms]				 */

#define MAX_NUM_BEACON			50	/**< Maximum number of beacons to be
										 stored								 */

/* -- type definitions-------------------------------------------------------*/
typedef struct {
				loramesh_sync_s beacon;
				uint32_t internal_ts;
				uint16_t internal_ts_ms;
} beacon_data_s;

/* RTOS globals -------------------------------------------------------------*/
extern osTimerId syncTimerHandle;

/* internal function declarations ------------------------------------------ */
static uint8_t send_beacon ( 	uint32_t systime, uint8_t bwindow,
										uint8_t hops, uint8_t subnet_id );

static uint32_t repeater_observe_channel( uint32_t timeout_ms );

static uint8_t node_sync_to_best_beacon ( 	uint32_t timeout_ms,
											loramesh_sync_s *best_beac );

static uint8_t node_sync_to_beacon( uint32_t timeout_ms, uint16_t parent_address,
									uint8_t check_subnet, uint16_t subnet_id,
									int16_t *prssi);

static uint32_t calculate_time_offset( uint8_t num_hops );

static uint8_t store_beacon( 	loramesh_sync_s *bdata,
								uint32_t time,
								uint16_t time_ms );

static uint32_t get_biggest_timspace( void );

static uint8_t scan_for_beacons( uint32_t timeout );

static uint8_t get_rating( int16_t rssi, uint8_t num_hops );
 
/* internal variable definitions ------------------------------------------- */ 
static uint8_t fl_to = FALSE;
static beacon_data_s *b_table = NULL;
static uint8_t table_ind = 0;
static uint8_t beacon_timeout_cnt = 0;

/* public function definitions --------------------------------------------- */

/*
 * 	See header file
 */
uint32_t ptk_proc_rep_init_sync ( 	ptk_core_state_s *pstate, uint32_t to_ms )
{
	return repeater_observe_channel( to_ms );
}

/*
 * 	See header file
 */
uint32_t ptk_proc_node_init_sync ( ptk_core_state_s *pstate, uint32_t to_ms )
{
	loramesh_sync_s best_beacon;

	if(node_sync_to_best_beacon( to_ms, &best_beacon ) == 0){
		// beacon found
		pstate->join_agent.fav_address = best_beacon.source_address;
		pstate->join_agent.agent_hop_count = best_beacon.num_hops;
		pstate->join_agent.agent_subnet_id = best_beacon.subnet_id;
		pstate->join_agent.role = JOIN_ROLE_JOINEE;
		pstate->join_agent.state = JOIN_STT_PREPARED;
		if( best_beacon.num_hops == 0 ){
			// direct join at the repeater
			pstate->join_agent.type = JOIN_TYPE_DIRECT;
		} else {
			pstate->join_agent.type = JOIN_TYPE_INDIRECT;
		}
		return best_beacon.utc_time;
	} else {
		// no beacon found
		return 0;
	}
}

/*
 * See header file
 */
uint8_t ptk_proc_sync ( ptk_core_state_s *pstate )
{
	uint8_t ret = 0;
	uint32_t systime = 0;
	uint16_t systime_ms;
	loramesh_sync_s tbeac;
	uint32_t offset = 0;
	int16_t trssi;

	if( pstate == NULL ) {
		return 1;
	}
	switch( pstate->device_type ){
	case (DEV_TYPE_REPEATER):	//---------------------------------------------
			cyGetRTCTime( &systime, &systime_ms );
			if(send_beacon( systime, pstate->beacon_window,
									 pstate->hop_count, pstate->subnet_id) == 0)
			{
				dbgPrintf("R, Beacon sent, Systime=%i\n", systime);
			} else {
				dbgPrintf("R, Beacon send timeout\n");
				debug_log_append_line("R, Beacon send timeout\n");
				//TODO: SD: Timing probably not critical
			}
			break;
	case (DEV_TYPE_NODE): //---------------------------------------------------
			if( pstate->state == PTK_STATE_JOINING ){
				if( node_sync_to_beacon( ptk_get_beacon_timeout(),
										pstate->join_agent.fav_address,
										0,
										0,
										&trssi ) == 0){
					dbgPrintf("N, Synced to beacon\n");
					pstate->link_rssi = trssi;
					ptk_set_join_task( );
				} else {
					beacon_timeout_cnt++;
				}
			} else if( pstate->state == PTK_STATE_IN){
				if(node_sync_to_beacon( ptk_get_beacon_timeout(),
										pstate->parent_address,
										1,
										pstate->subnet_id,
										&trssi ) == 0){
					// beacon was received
					offset = (pstate->beacon_window * ptk_get_fw_duration_ms());
					offset -= loramesh_get_toa_sync() * pstate->hop_count;
					osDelay(offset);
					ptk_get_latest_beacon( &tbeac );
					send_beacon( 	tbeac.utc_time,
											pstate->beacon_window,
											pstate->hop_count, pstate->subnet_id);
					pstate->link_rssi = trssi;
					beacon_timeout_cnt = 0;
					dbgPrintf("N, Beacon forwarded, Systime=%i\n", tbeac.utc_time);
				} else {
					beacon_timeout_cnt++;
					dbgPrintf("N, Beacon not received\n");
					debug_log_append_line("N, Beacon not received\n");
					//TODO: check timing
					// TODO: Beacon timeout handling --> rejoin
					return 1;
				}
			} else {
				return 1;
			}
			break;
	default: //----------------------------------------------------------------
		return 1;
		break;
	}
	if( beacon_timeout_cnt > ptk_get_max_ul_timeouts( )){
		dbgPrintf("N, max beacon timeouts reached\n");
		debug_log_append_line("N, max beacon timeouts reached\n"); //TODO: check timing
		ptk_core_reset();
		beacon_timeout_cnt = 0;
	}
	return ret;
}

/*
 * See header file
 */
void sync_timer_on_timeout ( void const *arg )
{
	fl_to = TRUE;
}

/* internal functions definitions ------------------------------------------ */

/**
 *  \brief  Sends out a beacon over the mesh network
 *  \param  systime	current system time as 32-bit UTC value
 *  \return returns 0 on success, nonzero otherwise
 */
static uint8_t send_beacon ( 	uint32_t systime, uint8_t bwindow,
										uint8_t hops, uint8_t subnet_id )
{
	osEvent evt;

	loramesh_send_beacon( systime, bwindow, hops, subnet_id );
	evt = osSignalWait( OS_SIGN_MESH_TX_DONE, SYNC_PACKET_TIMEOUT_S * 1000 );
	if( check_is_signal_set( &evt, OS_SIGN_MESH_TX_DONE )){
		return 0;
	} else {
		return 1;
	}
}


/*
 * 	\brief	Synchronizes the node to the best beacon by observing the
 * 			channel an rate the beacons. The RTC time is updated after
 * 			reception of the best beacon
 * 	\param	timeout_ms:	observing timeout in milliseconds
 * 	\param	*curr_start_time	pointer where the current start time
 * 								can be stored
 * 	\param	*fav_addr			pointer where the address of the
 * 								favourite parent can be stored
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t node_sync_to_best_beacon ( 	uint32_t timeout_ms,
											loramesh_sync_s *best_beac )
{
	uint8_t ret = 1;
	osEvent evt;
	uint8_t best_rating = 0;
	uint8_t rating = 0;
	loramesh_sync_s beac;
	uint32_t offset_ms = 0;

	fl_to = FALSE;
	osTimerStart( syncTimerHandle, timeout_ms );
	if( loramesh_receive() != LORAMESH_OK ){
		return 1;
	}
	while ( fl_to == FALSE ) {
		evt = osSignalWait( 0xFFFFFFFF, 0 );
		if( check_is_signal_set( &evt, OS_SIGN_MESH_BEAC_REC)) {
			loramesh_receive( );
			ptk_get_latest_beacon( &beac );
			if( !pkt_core_node_is_in_ignore_list(beac.source_address )){
				rating = get_rating( beac.rssi, beac.num_hops );
				if( best_rating < rating ) {
					offset_ms = calculate_time_offset( beac.fw_window );
					cyUpdateRTCTime( beac.utc_time, offset_ms);
					best_rating = rating;
					memcpy( best_beac, &beac, sizeof(loramesh_sync_s));
					ret = 0;
				}
				dbgPrintf("B from %i, RSSI %i, rat %i\n",beac.source_address, beac.rssi, rating);
			} else {
				dbgPrintf("Ignored beacon from %i\n", beac.source_address );
			}
		}
		if( check_is_signal_set( &evt, OS_SIGN_MESH_RX_DONE )){
			dbgPrintf("st: %i\n",evt.status);
			dbgPrintf("s: %i\n", evt.value.signals);
		}
		if( fl_to == TRUE ) {
			loramesh_radio_stop( );
			break;
		}
	}
	return ret;
}


/*
 * 	\brief	Synchronizes a node to the beacon of the favourite parent
 * 	\param	timeout_ms	receive timeout in milliseconds
 * 	\param	parent_address	address of the parent
 * 	\param	subnet_id	subnet id for beacon reception (is not checked if set to 0)
 * 	\param	*prssi		pointer to buffer to store current RSSI value
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t node_sync_to_beacon( uint32_t timeout_ms, uint16_t parent_address,
									uint8_t check_subnet, uint16_t subnet_id,
									int16_t *prssi)
{
	osEvent evt;
	loramesh_sync_s beac;
	uint16_t offset_ms;
	uint8_t ret = 1;
	fl_to = FALSE;
	if( loramesh_receive( ) != LORAMESH_OK ){
		return 1;
	}
	osTimerStart( syncTimerHandle, timeout_ms );
	while( fl_to == FALSE ){
		evt = osSignalWait( OS_SIGN_MESH_BEAC_REC, 0 );
		if( check_is_signal_set( &evt, OS_SIGN_MESH_BEAC_REC )){
			ptk_get_latest_beacon( &beac );
			if( beac.source_address == parent_address ){
				if((check_subnet == 1) && (beac.subnet_id != subnet_id)){
					loramesh_receive();
					dbgPrintf("Beacon subnet id missmatch\n");
				} else {
					offset_ms = calculate_time_offset( beac.fw_window );
					//cyUpdateRTCTime( beac.utc_time, offset_ms );
					cyUpdateStartRTCTime(beac.utc_time, offset_ms);
					loramesh_radio_stop( );
					osTimerStop( syncTimerHandle );
					if( prssi != NULL ){
						*prssi = beac.rssi;
					}
					ret = 0;
					break;
				}

			} else {
				loramesh_receive();
			}
			if( fl_to == TRUE ){
				loramesh_radio_stop( );
				ret = 1;
			}
		}
	}
	return ret;
}


/*
 *	\brief	Calculates the time offset according to the LoRa setting,
 *			the computing time and number of hops the beacon has passed
 *	\param	num_hops:	number of hops the beacon has passed
 *	\return	returns a valid timeoffset (nonzero) on success,
 *			0 on error
 */
static uint32_t calculate_time_offset( uint8_t i_fw )
{
#if SETUP_TESTBENCH == 0
	uint32_t to = 0;
	to = ptk_get_fw_duration_ms();
	to = i_fw * to;
	to += loramesh_get_toa_sync( );
	to += 26;							//TODO: make a define
	return to;
#else
	return 1;
#endif
}


/*
 * 	\brief	Observes the channel for a certain time and returns
 * 			the timestamp in the middle of the biggest timespace
 * 			where no packets could be received
 * 	\param	timeout_ms:	timeout in milliseconds
 * 	\return	returns a valid start time on success
 * 			0 if now beacons could be found
 * 			0xFFFFFFFF on error
 */
static uint32_t repeater_observe_channel( uint32_t timeout_ms )
{
	uint32_t start_time;
	if( scan_for_beacons( timeout_ms ) == 0 ) {
		start_time = get_biggest_timspace( );
		//TODO: register cycle start in protocol core
	} else {
		start_time = 0xFFFFFFFF;
	}
	return start_time;
}


/*
 * 	\brief	Repeater scans the channel for beacons and stores them in a table
 * 	\param	timeout	timeout in milliseconds
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t scan_for_beacons( uint32_t timeout )
{
	osEvent evt;
	static loramesh_sync_s sync;
	uint32_t time;
	uint16_t time_ms;
	uint8_t retval = 0;
	uint8_t first_beacon = 1;

	fl_to = FALSE;
	osTimerStart( syncTimerHandle, timeout );

	while( fl_to == FALSE ) {
		if( loramesh_receive() == LORAMESH_OK ) {
			evt = osSignalWait( OS_SIGN_MESH_BEAC_REC, 10 );
			if( check_is_signal_set( &evt, OS_SIGN_MESH_BEAC_REC)) {
				if( first_beacon ){
					first_beacon = 0;
				}
				debug_gpio2_toggle();
				cyGetRTCTime( &time, &time_ms );
				ptk_get_latest_beacon( &sync );
				store_beacon( &sync, time, time_ms );
			}
			if( fl_to == TRUE ) {
				break;
			}
		} else
		{
			retval = 1;
			break;
		}
	}
	// Print on uart which repeater plus RSSI were seen
	dbgPrintf("R, Beacon scan result:\n");
	for(uint8_t i=0;i<table_ind;i++)
	{
		dbgPrintf("- Beacon seen from %i with RSSI %i\n", (b_table + i)->beacon.source_address,
				(b_table + i)->beacon.rssi);
	}

	return retval;
}


/*
 * 	\brief	Stores received beacons in a table
 * 	\param	*bdata	beacon to be stored
 * 	\param	time	utc time of the beacon
 * 	\param	time_ms	miliseconds time of the beacon
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t store_beacon( 	loramesh_sync_s *bdata,
								uint32_t time,
								uint16_t time_ms )
{
	uint8_t ret = 1;
	if( b_table == NULL ) {
		b_table = (beacon_data_s*) pvPortMalloc( MAX_NUM_BEACON * sizeof( beacon_data_s ));
		if( b_table == NULL ) {
			// malloc failed
		}
	}
	if( table_ind < MAX_NUM_BEACON ) {
		b_table[table_ind].beacon.num_hops = bdata->num_hops;
		b_table[table_ind].beacon.rssi = bdata->rssi;
		b_table[table_ind].beacon.source_address = bdata->source_address;
		b_table[table_ind].beacon.fw_window = bdata->fw_window;
		b_table[table_ind].beacon.utc_time = bdata->utc_time;
		b_table[table_ind].beacon.subnet_id = bdata->subnet_id;
		b_table[table_ind].internal_ts = time;
		b_table[table_ind].internal_ts_ms = time_ms;
		table_ind++;
		ret = 0;
	}
	return ret;
}


/*
 * 	\brief	Gets the biggest free timespace between two received beacons
 * 	\return	The middle timepoint between the two beacons on sucess,
 * 			0 if now beacons could be found
 */
static uint32_t get_biggest_timspace( void )
{
	uint8_t i = 0;
	uint32_t timediff;
	uint32_t best_timediff = 0;
	uint8_t best_timediff_ind;
	uint64_t ts1 = 0;
	uint64_t ts2 = 0;
	uint64_t ret = 0;
	//uint32_t ts1, ts2;

	if( b_table == NULL ){
		// no beacon received
		return 0;
	}

	if( table_ind < 2 ){
		// only one beacon received
		ts1 = (uint64_t)(b_table)->internal_ts;
		ts1 = ts1 * 1000;
		ts1 += (uint64_t)(b_table)->internal_ts_ms;
		ts2 = (uint64_t)(ptk_get_cycle_duration_s() * 1000);
		ts2 = (ts2/2);
	} else {
		if(table_ind==2 && (b_table)->beacon.source_address==(b_table+1)->beacon.source_address )
		{
			// only one beacon received
			ts1 = (uint64_t)(b_table)->internal_ts;
			ts1 = ts1 * 1000;
			ts1 += (uint64_t)(b_table)->internal_ts_ms;
			ts2 = (uint64_t)(ptk_get_cycle_duration_s() * 1000);
			ts2 = (ts2/2);
		}else{
			for( i = table_ind; i>=1; i-- ){
				if(i  == table_ind  ){
					ts1 = (b_table + i - 1)->internal_ts;
					ts1 = ts1 * 1000;
					ts1 += (b_table + i - 1)->internal_ts_ms;
					ts2 = (b_table)->internal_ts + (ptk_get_cycle_duration_s());
					ts2 = ts2 * 1000;
					ts2 += (b_table)->internal_ts_ms;
					timediff = ts2 - ts1;
				} else {
					ts1 = (b_table + i - 1)->internal_ts;
					ts1 = ts1 * 1000;
					ts1 += (b_table + i - 1)->internal_ts_ms;
					ts2 = (b_table + i - 1 + 1 )->internal_ts;
					ts2 = ts2 * 1000;
					ts2 += (b_table + i - 1 + 1 )->internal_ts_ms;
					timediff = ts2 - ts1;
				}
				if( ts2>ts1 && timediff > best_timediff ) { //TODO: check
					best_timediff = timediff;
					best_timediff_ind = i - 1;
				}
			}
			ts1 = (uint32_t)(b_table + best_timediff_ind)->internal_ts;
			ts1 = ts1 * 1000;
			ts2 = (best_timediff);
			ts2 = ts2 / 2;
		}
	}
	vPortFree( b_table );
	ret = ts1 + ts2 + 500;
	ret = ret / 1000;
	return ( (uint32_t)ret );
}


/*
 * 	\brief	Rates received beacons
 * 	\param	rssi:	RSSI of the beacon
 * 	\param	num_hops:	num_hops of the beacon
 * 	\return	rating
 */
static uint8_t get_rating( int16_t rssi, uint8_t num_hops )
{
	// TODO: Implement rating function
	int32_t temp;

	if( num_hops == 0 ){
		temp = rssi + 127;
	} else {
		temp = 0;
	}
	return (uint8_t)temp;
}
