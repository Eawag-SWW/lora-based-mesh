/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		iM880B_HAL.c
 *
 * \description	Hal layer for IMST iM880B module on STM32L476
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		07.02.2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "iM880B_Hal.h"
#include "iM880B_ComSlip.h"
#include "stm32l4xx_hal.h"
#include "mcu_pinout.h"

/* -- makros ----------------------------------------------------------------*/
#define FALSE		0
#define TRUE		1

/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */
static void iM880B_hal_UARTInit (void);
static void iM880B_hal_TimInit(void);
static void iM880_hal_UARTDeInit ( void );
 
/* internal variable definitions ------------------------------------------- */ 
static TIM_TypeDef *timer = TIM3;			// use timer 3 WARNING:
											// when using other timer,
											// IRQ handler has to be modified

static void (*tim_callback) ( void );

static uint8_t timer_is_initialized = FALSE;

static USART_TypeDef *usart = USART1;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
void iM880B_hal_Init(void)
{
	iM880B_hal_UARTInit( );
	iM880B_hal_TimInit( );
}

/*
 * See header file
 */
void iM880B_hal_reinit( void )
{
	iM880B_hal_UARTInit( );
}

/*
 * See header file
 */
void iM880B_hal_deinit( void )
{
	iM880_hal_UARTDeInit ( );
}

/*
 * See header file
 */
void iM880B_hal_UART_send_byte (uint8_t byte)
{
	usart->TDR = byte;
	while( !(usart->ISR & USART_ISR_TXE)){

	}
}

/*
 * See header file
 */
void iM880B_hal_UART_start_rx ( void )
{
	usart->RQR |= USART_RQR_RXFRQ;
	usart->ICR |= USART_ICR_ORECF;
	HAL_NVIC_ClearPendingIRQ( USART1_IRQn );
	HAL_NVIC_EnableIRQ( USART1_IRQn );
	usart->CR1 |= USART_CR1_RE;
	usart->CR1 |= USART_CR1_RXNEIE;
}

/*
 * See header file
 */
void iM880B_hal_setTimer(uint32_t duration, void (*cb_timeout)(void))
{
	timer->CR1 &=~ TIM_CR1_CEN;				// stop timer
	NVIC_DisableIRQ(TIM3_IRQn);
	if( cb_timeout == NULL){
	}
	tim_callback = cb_timeout;
	if( duration < 1){
		timer->CNT = 0;
		//timer->ARR = 0;
		//latest_start_cnt = 0;
	} else {
		timer->CNT = (duration - 1);
		//timer->ARR = (timeout - 1);
		//latest_start_cnt = (duration - 1);
	}
	//timer->EGR |= TIM_EGR_UG;
	timer->SR &=~ TIM_SR_UIF;
	//timer->DIER |= TIM_DIER_UIE;
	HAL_NVIC_ClearPendingIRQ(TIM3_IRQn);
	HAL_NVIC_EnableIRQ(TIM3_IRQn);
	timer->CR1 |= TIM_CR1_CEN;
}

/*
 * See header file
 */
void iM880B_hal_stopTimer ( void )
{
	timer->SR &=~ TIM_SR_UIF;
	HAL_NVIC_DisableIRQ(TIM3_IRQn);
	timer->CR1 &=~ TIM_CR1_CEN;
}

/* internal functions definitions ------------------------------------------ */
/**
 *  \brief  USART 1 IRQ handler
 */
void USART1_IRQHandler( void )
{
	uint8_t data = 0;
	if((usart->ISR & USART_ISR_TXE) == USART_ISR_TXE){
		// TX EMPTY
	}
	if((usart->ISR & USART_ISR_TC) == USART_ISR_TC){
		usart->ICR |= USART_ICR_TCCF;
		// TX COMPLETED
	}
	if((usart->ISR & USART_ISR_RXNE) == USART_ISR_RXNE){
		usart->RQR |= USART_RQR_RXFRQ;
		data = usart->RDR;
		iM880B_ComSlip_ProcessRxByte(data);	//TODO: replace with a callback function
		// RX NOT EMPTY
	}
	if((usart->ISR & USART_ISR_ORE ) == USART_ISR_ORE){
		usart->ICR |= USART_ICR_ORECF;

	}
	NVIC_ClearPendingIRQ(USART1_IRQn);
}

/**
 *  \brief  Timer 3 IRQ handler
 *  \param  name: Description
 */
void TIM3_IRQHandler ( void )
{
	if((timer->SR & TIM_SR_UIF) == TIM_SR_UIF) {	// update event occured
		timer->CR1 &=~ TIM_CR1_CEN;
		timer->SR  &=~ TIM_SR_UIF;
		HAL_NVIC_DisableIRQ(TIM3_IRQn);
		HAL_NVIC_ClearPendingIRQ(TIM3_IRQn);
		if( tim_callback == NULL) {
		}
		tim_callback( );
	}
}

/**
 *  \brief  Initializes the UART HAL
 */
static void iM880B_hal_UARTInit (void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

	if(!__HAL_RCC_GPIOA_IS_CLK_ENABLED()) {
		__HAL_RCC_GPIOA_CLK_ENABLE();
	}
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_USART1_CLK_ENABLE();


	GPIO_InitStruct.Pin = IM880_USART_TX_PIN|IM880_USART_RX_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
	HAL_GPIO_Init(IM880_USART_PORT, &GPIO_InitStruct);

	usart->CR1 = 0x00000000;
	usart->CR1 |= ( USART_CR1_RXNEIE | USART_CR1_TE | USART_CR1_RE);
	usart->CR3 |= (USART_CR3_OVRDIS | USART_CR3_EIE);

	usart->BRR = 347;

	usart->CR1 |= USART_CR1_UE;
	HAL_NVIC_ClearPendingIRQ(USART1_IRQn);
	HAL_NVIC_SetPriority(USART1_IRQn,11,0);
	HAL_NVIC_EnableIRQ(USART1_IRQn);
}

/**
 *  \brief  Deinitializes the UART HAL
 */
static void iM880_hal_UARTDeInit ( void )
{
	// TODO: Reset UART pins
	GPIO_InitTypeDef gp;
	usart->CR1 &=~ ( USART_CR1_RXNEIE | USART_CR1_TE | USART_CR1_RE | USART_CR1_UE);
	__HAL_RCC_USART1_CLK_DISABLE( );
    HAL_GPIO_DeInit(GPIOA, IM880_USART_TX_PIN|IM880_USART_RX_PIN);
    HAL_NVIC_DisableIRQ(USART1_IRQn);

    gp.Pin = IM880_USART_TX_PIN | IM880_USART_RX_PIN;
    gp.Mode = GPIO_MODE_INPUT;
    gp.Pull = GPIO_NOPULL;
    gp.Speed = GPIO_SPEED_FREQ_LOW;

    HAL_GPIO_Init( IM880_USART_PORT, &gp);
}

/**
 *  \brief  Initializes the Timer HAL
 */
static void iM880B_hal_TimInit(void)
{
	if( timer_is_initialized == FALSE) {
		__HAL_RCC_TIM3_CLK_ENABLE();
		while(!__HAL_RCC_TIM3_IS_CLK_ENABLED());
		timer->CR1 = 0x0000;	// reset value
		timer->CR1 |= (	TIM_CR1_CKD_1	|	// clock division by 1
						TIM_CR1_DIR); 	//|	// direction down
						//TIM_CR1_OPM);		// one pulse mode
		timer->CR2 = 0x0000;
		timer->DIER |= TIM_DIER_UIE;		// enable update interrupt
		timer->PSC = (uint16_t)40000;		// leads to 1ms ticks
		timer->ARR = 0xFFFFFFFF;
		timer->EGR |= TIM_EGR_UG;			// update event

		timer->SR &=~ TIM_SR_UIF;			// clear interrupt flag

		HAL_NVIC_SetPriority(TIM3_IRQn, 11, 0);		// configure interrupts
		HAL_NVIC_ClearPendingIRQ(TIM3_IRQn);
		HAL_NVIC_EnableIRQ(TIM3_IRQn);
		timer_is_initialized = TRUE;
	} else {
		// TODO: Error handling
	}
}


