/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		iM880B.c
 *
 * \description	Handles LoRaWAN communication using iM880B-module from IMST
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#if 1
#include "iM880B.h"
#include "device_config.h"
#include "iM880B_ComMsg.h"
#include "iM880B_Hal.h"
#include "stdio.h"
#include "stm32l4xx_hal.h"
#include "lowpower.h"
#include "debug/debug.h"
#include "log/log.h"
#include "utilities.h"
#include "string.h"

/* -- makros ----------------------------------------------------------------*/
#define RESPONSE_TIMEOUT		100	/** response timeout after sending
										a command to iM880B module			 */



/** Delay definitions for the iM880B module									 */
#define PWR_UP_DELAY_MS				500	/**< power-up delay in ms		 	 */
#define IM880X_RESET_TIMEMOUT_MS 	500	/**< delay after reseting the module */
#define IM880X_TX_TIMEOUT_MS		3000/**< transmission timeout in ms		 */
#define IM880X_RXWIN_TIMEOUT_MS 	2500/**< reception timeout in ms		 */
#define IM880X_STATUS_TIMEOUT_MS	20	/**< network status response timeout */
/* -- type definitions-------------------------------------------------------*/
typedef enum {
	IM880B_DEV_UNINITIALIZED = 0,
	IM880B_DEV_IDLE,
	IM880B_DEV_START_TX,
	IM880B_DEV_WAIT_TX_DONE,
	IM880B_DEV_WAIT_RX_WINDOW
}tIM880DevStates;

typedef enum {
	IM880B_ACT_NO_ACTION = 0,
	IM880B_ACT_INIT,
	IM880B_ACT_TX_UDATA,
	IM880B_ACT_TX_CDATA
}tIM880Actions;

typedef enum {
	NWK_STT_INACTIVE = 0x00,
	NWK_STT_ACTIVE_ABP = 0x01,
	NWK_STT_ACTIVE_OTAA = 0x02,
	NWK_STT_JOINING_OTAA = 0x03
}tIM880NwkStatus;

typedef struct {
	uint8_t 		status_byte;
	tIM880NwkStatus nwk_status;
	uint32_t 		dev_addr;
	uint8_t			data_rate;
	uint8_t			power_level;
	uint8_t			max_payload;
} im880_netw_status_s;

/* internal function declarations ------------------------------------------ */
// Callback functions for iM880B drivers
static void CbMsgIndication ( 	uint8_t *msg, uint8_t length,
								tWiMODLRWanIndication indication);
static void CbLoRaWANHCIResponse ( uint8_t msgID, uint8_t *msg, uint8_t length);
static void CbDevMgmtHCIResponse ( uint8_t msgID, uint8_t *msg, uint8_t lenght);


static tIM880Results im880x_connection_is_ok ( void );
static tIM880Results im880x_set_stack_configuration ( void );
static tIM880Results im880x_activate_by_personalization( void );
static tIM880Results im880x_set_nwkSessionKey( char * key );
static tIM880Results im880x_set_appSessionKey( char * key );
static tIM880Results iM880_sm ( void );
static void delay_ms ( uint32_t timeout_ms);
static tIM880Results __iM880B_Init ( void );
static void timeout_callback ( void );
static uint8_t iM880B_DeInit ( void );
static uint8_t iM880B_ReInit ( void );
static lp_modes_t iM880B_GetLpmode ( void );
static tIM880Results iM880B_get_nwk_status( im880_netw_status_s *stt );
/* internal variable definitions ------------------------------------------- */ 

/**	function pointer for callback function									 */
static void (*iM880B_callback)(tIM880Evt evt, uint8_t *pData, uint16_t length);

static volatile uint8_t op_success = FALSE;	/** flag indicates if operation
												was successful or not		 */

static volatile uint8_t timeout = FALSE;	/** flag for timeout indication	 */

/** flag inicates if device activation was sucessful or not					 */
static volatile uint8_t activ_successfull = FALSE;

/** variable for keeping device state										 */
static tIM880DevStates dev_state = IM880B_DEV_UNINITIALIZED;


/** Direct Activation Parameters											 */

static uint8_t nwkSessionKey[KEY_LEN] = {	0x00, 0x00, 0x00, 0x00, 0x00,
												0x00, 0x00, 0x00, 0x00, 0x00,
												0x00, 0x00, 0x00, 0x00, 0x00,
												0x00};
static uint8_t appSessionKey[KEY_LEN] = {	0x00, 0x00, 0x00, 0x00, 0x00,
												0x00, 0x00, 0x00, 0x00, 0x00,
												0x00, 0x00, 0x00, 0x00, 0x00,
												0x00};

static uint8_t tx_data_buffer[LORAWAN_MAX_PAYLOAD_LEN];
static uint8_t rx_data_buffer[LORAWAN_MAX_PAYLOAD_LEN];
static uint16_t tx_data_length = 0;
static uint16_t rx_data_length = 0;

static volatile tIM880Actions action = IM880B_ACT_NO_ACTION;
static volatile tIM880Evt im_evt;
static uint8_t reset_request_accepted = 0;
static uint8_t status_updated = FALSE;
static im880_netw_status_s curr_ntwk_status;
static uint8_t use_port = 0;

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
tIM880Results iM880B_Init (void (*callback)( tIM880Evt evt,
		 	 	 	 	 	 	 	 	 	 uint8_t *pData, uint16_t length))
{
	lp_clients_s lpclient;
	if( callback == NULL){
		return IM880_ERROR;
	}
	iM880B_callback = callback;

	if (__iM880B_Init( ) != IM880_OK){
		return IM880_ERROR;
	}
	dev_state = IM880B_DEV_IDLE;

	lpclient.deinit = iM880B_DeInit;
	lpclient.reinit = iM880B_ReInit;
	lpclient.get_lpmode = iM880B_GetLpmode;
	lp_register_client( &lpclient );
	return IM880_OK;
}

/*
 * See header file
 */
static uint8_t iM880B_DeInit ( void )
{
	if( dev_state != IM880B_DEV_IDLE ){
		return 1;
	}
	iM880B_hal_deinit( );
	return 0;
}

/*
 * See header file
 */
static uint8_t iM880B_ReInit ( void )
{
	iM880B_hal_Init( );
	return 0;
}

/*
 * See header file
 */
static lp_modes_t iM880B_GetLpmode ( void )
{
	if( dev_state != IM880B_DEV_IDLE ){
		return RUN_MODE;
	}
	return STOP2_MODE;
}

/**
 * 	See header file
 */
tIM880Results iM880B_OTAA( void )
{
	//TODO: Implement over the air activation
	return IM880_ERROR;
}

/*
 * See header file
 */
tIM880Results iM880B_send_data_unconfirmed ( uint8_t port,
											 uint8_t *data,
											 uint16_t length)
{
	uint8_t i = 0;
	if( data == NULL ){
		return IM880_ERROR;
	}
	if( dev_state != IM880B_DEV_IDLE){
		return IM880_ERROR_BUSY;
	}
	tx_data_length = length;
	for( i=0; i<length; i++ ){
		tx_data_buffer[i] = *(data + i);
	}
	action = IM880B_ACT_TX_UDATA;
	use_port = port;
	if( iM880_sm( ) != IM880_OK){
		return IM880_ERROR;
	}
	return IM880_OK;
}

/*
 * See header file
 */
tIM880Results iM880B_reset( void )
{
	tIM880Results res = IM880_OK;
	reset_request_accepted = 0;

	if( iM880x_ResetRequest( ) == WiMODLR_RESULT_OK ) {
		timeout = FALSE;
		iM880B_hal_setTimer( IM880X_RESET_TIMEMOUT_MS, timeout_callback);
		while( 1 ) {
			if( timeout == TRUE ){
				res = IM880_ERROR;
				break;
			}
			if( reset_request_accepted ) {
				iM880B_hal_stopTimer( );
				HAL_Delay( 300 );
				break;
			}
		}
	} else {
		res = IM880_ERROR;
	}
	return res;
}

/*
 * 	See header file
 */
tIM880Results iM880B_get_max_payload( uint8_t *pMax )
{
	im880_netw_status_s stt;
	if( dev_state != IM880B_DEV_IDLE){
		return IM880_ERROR;
	}
	if( iM880B_get_nwk_status( &stt ) != IM880_OK){
		return IM880_ERROR;
	}
	*pMax = stt.max_payload;
	return IM880_OK;
}

/* internal functions definitions ------------------------------------------ */

/**
 *  \brief  Statemachine of the iM880 driver software
 *  \return error code
 */
static tIM880Results iM880_sm ( void )
{
	switch( dev_state ){
	case (IM880B_DEV_UNINITIALIZED):
		// initialization process is triggered asynchronous
		break;
	case (IM880B_DEV_IDLE):
			if( action == IM880B_ACT_TX_UDATA){
				timeout = FALSE;
				im_evt = IM880_EVT_NO_EVT;
				iM880B_hal_setTimer( RESPONSE_TIMEOUT, timeout_callback);
				if( iM880x_SendUDataTelegram( use_port, tx_data_buffer,
											tx_data_length)	!= WiMODLR_RESULT_OK) {
					return IM880_ERROR;
				}
				action = IM880B_ACT_NO_ACTION;
				dev_state = IM880B_DEV_START_TX;
			}
		break;
	case (IM880B_DEV_START_TX):
			if( im_evt == IM880_EVT_CMD_ACCEPTED ){
				im_evt = IM880_EVT_NO_EVT;
				iM880B_hal_stopTimer( );
				timeout = FALSE;
				iM880B_hal_setTimer( IM880X_TX_TIMEOUT_MS, timeout_callback );
				dev_state = IM880B_DEV_WAIT_TX_DONE;
			} else if ( im_evt == IM880_EVT_CMD_ERROR)
			{
				im_evt = IM880_EVT_NO_EVT;
				iM880B_hal_stopTimer( );
				dev_state = IM880B_DEV_IDLE;
				dbgPrintf("Command error\n");
				debug_log_append_line("Command error\n"); // TODO: SD: Timing critical!!
				iM880B_callback( IM880_EVT_CMD_ERROR, NULL, 0 );
			}
			if( timeout == TRUE ){
				timeout = FALSE;
				// reset the device, reinit device
				dbgPrintf("Response timeout\n");
				debug_log_append_line("Response timeout\n"); // TODO:SD: Timing probably not critical
				dev_state = IM880B_DEV_IDLE;
				iM880B_callback( IM880_EVT_CMD_TIMEOUT, NULL, 0 );
			}
		break;
	case (IM880B_DEV_WAIT_TX_DONE):
			if( im_evt == IM880_EVT_TX_DONE ){
				im_evt = IM880_EVT_NO_EVT;
				iM880B_hal_stopTimer( );
				timeout = FALSE;
				iM880B_hal_setTimer( IM880X_RXWIN_TIMEOUT_MS, timeout_callback);
				dev_state = IM880B_DEV_WAIT_RX_WINDOW;
				iM880B_callback( IM880_EVT_TX_DONE, NULL, 0 );
			}
			if( timeout ){
				timeout = FALSE;
				// error handling
				dev_state = IM880B_DEV_IDLE;
				dbgPrintf("TX timeout\n");
				debug_log_append_line("TX timeout\n"); // TODO: SD: Timing probably not critical
				iM880B_callback( IM880_EVT_TX_TIMEOUT, NULL, 0 );
			}
		break;
	case (IM880B_DEV_WAIT_RX_WINDOW):
			if( im_evt == IM880_EVT_RX_WINDOW_ELLAPSED ){
				im_evt = IM880_EVT_NO_EVT;
				iM880B_hal_stopTimer( );
				dev_state = IM880B_DEV_IDLE;
				iM880B_callback( IM880_EVT_RX_WINDOW_ELLAPSED, NULL, 0);
			}
			if( im_evt == IM880_EVT_RX_DONE ){
				// TODO: RX done handling
				iM880B_hal_stopTimer( );
				dev_state = IM880B_DEV_IDLE;
				iM880B_callback( IM880_EVT_RX_DONE, NULL, 0 );
			}
			if( im_evt == IM880_EVT_ACK_RX_DONE ){
				// TODO: Acknowledge handling
				iM880B_hal_stopTimer( );
				dev_state = IM880B_DEV_IDLE;
				iM880B_callback( IM880_EVT_ACK_RX_DONE, NULL, 0 );
			}
			if( timeout == TRUE ){
				timeout = FALSE;
				dev_state = IM880B_DEV_IDLE;
				iM880B_callback( IM880_EVT_RX_TIMEOUT, NULL, 0 );
			}
		break;

	}
	return IM880_OK;
}

/**
 *  \brief  Initializes the LoRaWAN module including activation
 *  \return error code
 */
static tIM880Results __iM880B_Init ( void )
{
	tIM880Results res = IM880_OK;
	iM880B_hal_Init( );
	iM880x_Init( );
	iM880x_RegisterRadioCallbacks(	CbMsgIndication, CbLoRaWANHCIResponse,
									CbDevMgmtHCIResponse);
	delay_ms(PWR_UP_DELAY_MS);
	if( (res = im880x_connection_is_ok ()) != IM880_OK){
		return res ;
	}

	if( (res = iM880B_reset( )) != IM880_OK ){
		return res;
	}

	if(( res = im880x_set_stack_configuration( )) != IM880_OK){
		return res;
	}
	delay_ms(300);
	im880x_set_nwkSessionKey(NWK_SESSION_KEY);
	im880x_set_appSessionKey(APP_SESSION_KEY);
	if(( res = im880x_activate_by_personalization( )) != IM880_OK){
		return res;
	}
	return res;
}

/**
 *  \brief  Massage indication callback
 *  \param	*msg		pointer to message
 *  \param	length  	length of the message
 *  \param  indication	defines what kind of indication called the function
 */
static void CbMsgIndication ( uint8_t *msg, uint8_t length,
											tWiMODLRWanIndication indication)
{
	uint8_t i = 0;
	switch( indication ){
	case ( WIMOD_JOIN_DONE):
		break;
	case ( WIMOD_TX_DONE ):
			im_evt = IM880_EVT_TX_DONE;
		break;
	case ( WIMOD_RX_DONE ):
			rx_data_length = length;
			for( i=0; i<length; i++){
				rx_data_buffer[i] = *(msg + i);
			}
			im_evt = IM880_EVT_RX_DONE;
		break;
	case ( WIMOD_RX_ACK_DONE ):
			im_evt = IM880_EVT_ACK_RX_DONE;
		break;
	case ( WIMOD_RX_WINDOW_ELAPSED ):
			im_evt = IM880_EVT_RX_WINDOW_ELLAPSED;
		break;
	default:
		break;
	}
	iM880_sm( );
}

/**
 *  \brief  LoRaWAN HCI response callback
 *  \param	msgID		message ID
 *  \param	*msg  		pointer to message
 *  \param  length		length of the message
 */
static void CbLoRaWANHCIResponse ( uint8_t msgID, uint8_t *msg, uint8_t length)
{
	switch( msgID) {
	case ( LORAWAN_MSG_SET_RSTACK_CONFIG_RSP):
			if( msg[0] == LORAWAN_STATUS_OK){
				op_success = TRUE;
			}
		break;
	case ( LORAWAN_MSG_ACTIVATE_DEVICE_RSP):
			if( msg[0] == LORAWAN_STATUS_OK){
				activ_successfull = TRUE;
			}
		break;
	case ( LORAWAN_MSG_SEND_UDATA_RSP):
	case ( LORAWAN_MSG_SEND_CDATA_RSP):
			if( msg[0] == LORAWAN_STATUS_OK){
				im_evt = IM880_EVT_CMD_ACCEPTED;
			} else if ( msg[0] == LORAWAN_STATUS_DEVICE_BUSY) {
				dbgPrintf("status: %h\n", msg[0]);
				im_evt = IM880_EVT_CMD_ERROR;
			}
			else {
				dbgPrintf("status1: %h\n", msg[0]);
				im_evt = IM880_EVT_CMD_ERROR;
			}
		break;
	case ( LORAWAN_MSG_GET_NWK_STATUS_RSP ):
			curr_ntwk_status.status_byte = msg[0];
			curr_ntwk_status.nwk_status = msg[1];
			curr_ntwk_status.dev_addr = convert_to_uint32((msg + 2));
			curr_ntwk_status.data_rate = msg[6];
			curr_ntwk_status.power_level = msg[7];
			curr_ntwk_status.max_payload = msg[8];
			status_updated = TRUE;
			break;
	default:
		break;
	}
	iM880_sm( );
}



/**
 *  \brief  Device management HCI response callback
 *  \param	msgID		message ID
 *  \param	*msg  		pointer to message
 *  \param  length		length of the message
 */
static void CbDevMgmtHCIResponse ( uint8_t msgID, uint8_t *msg, uint8_t lenght)
{
	switch(msgID) {
	case ( DEVMGMT_MSG_PING_RSP):
			if( msg[0] == DEVMGMT_STATUS_OK) {
				op_success = TRUE;
			}
		break;
	case ( DEVMGMT_MSG_RESET_RSP ):
			if( msg[0] == DEVMGMT_STATUS_OK ) {
				reset_request_accepted = 1;
			}
	default:
		break;
	}
	iM880_sm( );
}

/**
 *  \brief  Checks the communication between the host MCU and the LoRaWAN module
 *  \return error code
 */
static tIM880Results im880x_connection_is_ok ( void )
{
	op_success = FALSE;
	iM880x_PingRequest( );
	delay_ms(5);
	if(op_success == TRUE) {
		return IM880_OK;
	} else {
		return IM880_ERROR_COM;
	}
}

/**
 *  \brief  Sets the stack configuration for the LoRaWAN module
 *  \return error code
 */
static tIM880Results im880x_set_stack_configuration ( void )
{
	op_success = FALSE;
	iM880x_SetRadioStackConfiguration( );
	delay_ms( 10 );
	if( op_success == TRUE ){
		return IM880_OK;
	} else {
		return IM880_ERROR;
	}

}


/**
 *  \brief  Convert app session ASCII key to byte array
 *  \return error code
 */
static tIM880Results im880x_set_appSessionKey( char * key )
{
	// check key length
	if (strlen(key)!=32) return IM880_ERROR;

	// check if key is a hexadecimal string
	for (uint8_t i=0;i<KEY_LEN;i++)
	{
		if (((key[i] < '0') || (key[i] > '9')) &&
			((key[i] < 'A') || (key[i] > 'F')) &&
			((key[i] < 'a') || (key[i] > 'f')))
		{
			return IM880_ERROR;
		}
	}

	// Copy string to byte array
	for (uint8_t i = 0; i < KEY_LEN; i++) {
	        sscanf(key + 2*i, "%02x", &appSessionKey[i]); // TODO: test
	}

	return IM880_OK;
}

/**
 *  \brief  Convert network session ASCII key to byte array
 *  \return error code
 */
static tIM880Results im880x_set_nwkSessionKey( char * key )
{
	// check key length
	if (strlen(key)!=32) return IM880_ERROR;

	// check if key is a hexadecimal string
	for (uint8_t i=0;i<KEY_LEN;i++)
	{
		if (((key[i] < '0') || (key[i] > '9')) &&
			((key[i] < 'A') || (key[i] > 'F')) &&
			((key[i] < 'a') || (key[i] > 'f')))
		{
			return IM880_ERROR;
		}
	}

	// Copy string to byte array
	for (uint8_t i = 0; i < KEY_LEN; i++) {
	        sscanf(key + 2*i, "%02x", &nwkSessionKey[i]); // TODO: test
	}

	return IM880_OK;
}

/**
 *  \brief  Activation by personalization of the LoRaWAN module
 *  \return error code
 */
static tIM880Results im880x_activate_by_personalization( void )
{
	activ_successfull = FALSE;
	iM880x_DirectDeviceActivation(DEVICE_ADDR_LORAWAN, nwkSessionKey, appSessionKey);
	//HAL_Delay(500);
	timeout = FALSE;
	iM880B_hal_setTimer( IM880X_TX_TIMEOUT_MS, timeout_callback );
	while( timeout == FALSE){
		if( (activ_successfull == TRUE) && (im_evt == IM880_EVT_TX_DONE)){
			iM880B_hal_stopTimer( );
			activ_successfull = FALSE;
			im_evt = IM880_EVT_NO_EVT;
			break;
		}
	}
	if ( timeout == TRUE ){
		return IM880_ERROR;
	}
	iM880B_hal_setTimer(IM880X_RXWIN_TIMEOUT_MS, timeout_callback);
	while (timeout == FALSE){
		if( im_evt == IM880_EVT_RX_WINDOW_ELLAPSED){
			break;
		}
	}
	return IM880_OK;

}

/**
 *  \brief  Reads the network status from the LoRaWAN module
 *  \param  *stt pointer to buffer to save current network state
 *  \return error code
 */
static tIM880Results iM880B_get_nwk_status( im880_netw_status_s *stt )
{
	status_updated = FALSE;
	timeout = FALSE;
	iM880x_Nwk_Status_Req();
	iM880B_hal_setTimer( IM880X_STATUS_TIMEOUT_MS, timeout_callback );
	while( timeout == FALSE ){
		if( status_updated == TRUE ){
			iM880B_hal_stopTimer( );
			stt->status_byte = curr_ntwk_status.status_byte;
			stt->nwk_status = curr_ntwk_status.nwk_status;
			stt->dev_addr = curr_ntwk_status.dev_addr;
			stt->data_rate = curr_ntwk_status.data_rate;
			stt->power_level = curr_ntwk_status.power_level;
			stt->max_payload = curr_ntwk_status.max_payload;
			break;
		}
	}
	if( timeout == TRUE ){
		return IM880_ERROR;
	}
	return IM880_OK;
}

/**
 *  \brief  Timeout callback function
 */
static void timeout_callback ( void )
{
	timeout = TRUE;
	iM880_sm( );
}

/**
 *  \brief  Processes a delay ( by blocking the MCU )
 *  \param	timeout_ms	timeout value in ms
 */
static void delay_ms ( uint32_t timeout_ms)
{
	timeout = FALSE;
	iM880B_hal_setTimer( timeout_ms, timeout_callback );
	while( timeout == FALSE ){
	}
	timeout = FALSE;
}
#endif


