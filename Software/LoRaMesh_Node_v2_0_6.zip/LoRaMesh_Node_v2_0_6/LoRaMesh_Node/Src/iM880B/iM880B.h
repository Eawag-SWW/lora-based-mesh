/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		iM880B.c
 *
 * \description	Handles LoRaWAN communication using iM880B-module from IMST
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _IM880B_H
#define _IM880B_H

/* -- includes --------------------------------------------------------------*/
#include "stdint.h"
//#include "le_handler.h"
/* -- makros ----------------------------------------------------------------*/
#define LORAWAN_MAX_PAYLOAD_LEN		115		// see WiMOD LoRaWAN.. Feature Spec. p. 5

/* -- type definitions-------------------------------------------------------*/

typedef enum {
	IM880_OK = 0,
	IM880_ERROR_BUSY,
	IM880_ERROR_COM,
	IM880_ERROR
}tIM880Results;

typedef enum {
	IM880_EVT_NO_EVT 				= 0x00,
	IM880_EVT_CMD_ACCEPTED,
	IM880_EVT_CMD_ERROR,
	IM880_EVT_CMD_TIMEOUT,
	IM880_EVT_TX_DONE,
	IM880_EVT_TX_TIMEOUT,
	IM880_EVT_RX_DONE,
	IM880_EVT_ACK_RX_DONE,
	IM880_EVT_RX_WINDOW_ELLAPSED,
	IM880_EVT_RX_TIMEOUT

}tIM880Evt;

/* public function declarations -------------------------------------------- */

/**
 *  \brief  Initializes the IM880 radio module interface
 *  \param  *callback: pointer to callback function
 *  \return module status
 */
tIM880Results iM880B_Init (void (*callback)( tIM880Evt evt,
		 	 	 	 	 	 	 	 	 	 uint8_t *pData, uint16_t length));

/**
 *  \brief  Sends unconfirmed data over the LoRaWAN module
 *  \param	port:	lorawan-port
 *  \param  *data:	pointer to data
 *  \param 	length:	length of the data which shuld be transmitted
 *  \return error code
 */
tIM880Results iM880B_send_data_unconfirmed ( uint8_t port,
											 uint8_t *data,
											 uint16_t length);

/**
 * 	\brief	Starts device activation over the air
 * 	\return	code ok if activation was successful, error code otherwise
 */
tIM880Results iM880B_OTAA( void );

/**
 * 	\brief	Gets current maximum allowed payload size
 */
tIM880Results iM880B_get_max_payload( uint8_t *pMax );

#endif	//_IM880B_H

