/**
 * @file iM880B_ComMsg.c
 * <!------------------------------------------------------------------------>
 * @brief @ref REF "WiMODLR HCI Example"
 *
 * @par Project:
 * <!------------------------------------------------------------------------>
 * <!--
 * @par Description:
 *
 *  [Description]
 * -->
 * <!--
 *  @ref [extdocname] "more..."
 *  -->
 * <!------------------------------------------------------------------------>
 * <!--
 * @remarks
 * - [...]
 * - [...]
 * -->
 * <!------------------------------------------------------------------------
 * Copyright (c) 2015
 * IMST GmbH
 * Carl-Friedrich Gauss Str. 2
 * 47475 Kamp-Lintfort
 * -------------------------------------------------------------------------->
 * @author Mathias Hater (MH), IMST
 * <!------------------------------------------------------------------------
 * Target OS:    none
 * Target CPU:   EFM32
 * Compiler:     IAR C/C++ Compiler
 * -------------------------------------------------------------------------->
 * @internal
 * @par Revision History:
 * <PRE>
 * ---------------------------------------------------------------------------
 * Version | Date       | Author | Comment
 * ---------------------------------------------------------------------------
 * 0.1     | 22.01.2015 | MH     | Created
 *
 * </PRE>

 Copyright (c) 2015 IMST GmbH.
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are NOT permitted without prior written permission
 of the IMST GmbH.

 THIS SOFTWARE IS PROVIDED BY THE IMST GMBH AND CONTRIBUTORS ``AS IS'' AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE IMST GMBH OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 THIS SOFTWARE IS CLASSIFIED AS: CONFIDENTIAL

 *******************************************************************************/
#include "iM880B_ComSlip.h"
#include "iM880B_ComCRC16.h"
#include "iM880B_ComMsg.h"
#include "iM880B_Hal.h"
#include "iM880B.h"


//TODO: move to separate file
//------------------------------------------------------------------------------
// Integer Conversion Macros
//------------------------------------------------------------------------------
#define HIBYTE(x)           ((uint8_t) (((uint16_t)(x)) >> 8))
#define LOBYTE(x)           ((uint8_t) (((uint16_t)(x)) & 0xFF))
#define HIWORD(x)           ((uint16_t)(((uint32_t)(x)) >> 16))
#define LOWORD(x)           ((uint16_t)(((uint32_t)(x)) & 0xFFFF))
//------------------------------------------------------------------------------
// Byte-Order Conversion Macros
//------------------------------------------------------------------------------
#define HTON32(dstPtr, value)                   \
        (dstPtr)[0] = LOBYTE(LOWORD(value));    \
        (dstPtr)[1] = HIBYTE(LOWORD(value));    \
        (dstPtr)[2] = LOBYTE(HIWORD(value));    \
        (dstPtr)[3] = HIBYTE(HIWORD(value));


static uint8_t* iM880x_CbProcessRxMessage(uint8_t* rxBuffer, uint16_t length);
//static TWiMDLRResultcodes WaitHCIResponse (void);
static TWiMDLRResultcodes SendHCIMessage(	uint8_t sapID, uint8_t msgID,
											uint8_t* payload, uint16_t length);

TWiMODLR_HCIMessage TxMessage;
TWiMODLR_HCIMessage RxMessage;

TRadioInterfaceCbMsgIndication	cbMsgIndication;
TRadioInterfaceCbLoRaWANHCIResponse     cbLoRaWANHCIResponse;
TRadioInterfaceCbDevMgmtHCIResponse     cbDevMgmtHCIResponse;


static uint8_t configBuffer[4];


//static TWiMDLRResultcodes WaitHCIResponse (void)
//{
//	uint8_t timeout_cnt = 0;
//	TWiMDLRResultcodes resultCode = WiMODLR_RESULT_OK;
//
//	while(1)
//	{
//		// Send 61 characters wait for answer needs ~10ms
//		HAL_Delay(50);
//
//		if( DevMgmt_CmdOk_Flag )
//		{
//			DevMgmt_CmdOk_Flag = 0;
//			resultCode = WiMODLR_RESULT_OK;
//			break;
//		}
//
//		// Module answer with error
//		if( DevMgmt_Fail_Flag )
//		{
//			DevMgmt_Fail_Flag = 0;
//			resultCode = WiMODLR_COM_ERROR;
//			break;
//		}
//
//		// Increase timeout counter
//		timeout_cnt++;
//		// After 0.5sec timeout occur
//		if(timeout_cnt >= 5)
//		{
//			resultCode = WiMODLR_COM_ERROR;
//			break;
//		}
//	}
//
//	// Reset DMA
//	iM880B_hal_ResetDMA();
//	return resultCode;
//}

//------------------------------------------------------------------------------
//
//  SendHCIMessage
//
//  @brief  send generic HCI message to iM880A
//
//------------------------------------------------------------------------------

static TWiMDLRResultcodes SendHCIMessage(	uint8_t sapID, uint8_t msgID,
											uint8_t* payload, uint16_t length)
{
	TWiMDLRResultcodes com_result = WiMODLR_RESULT_OK;
    // 1. check parameter
    //
    // 1.1 check length
    //
    if(length > WIMODLR_HCI_MSG_PAYLOAD_SIZE)
    {
        return WiMODLR_RESULT_PAYLOAD_LENGTH_ERROR;
    }

    // 2.  init TxMessage
    //
    // 2.1 init SAP ID
    //
    TxMessage.SapID = sapID;

    // 2.2 init Msg ID
    //
    TxMessage.MsgID = msgID;

    // 2.3 copy payload, if present
    //
    if(payload && length)
    {
        uint8_t*  dstPtr  = TxMessage.Payload;
        int     n       = (int)length;

        // copy bytes
        while(n--)
            *dstPtr++ = *payload++;
    }

    // 3. Calculate CRC16 over header and optional payload
    //
    uint16_t crc16 = CRC16_Calc(&TxMessage.SapID, length + WIMODLR_HCI_MSG_HEADER_SIZE, CRC16_INIT_VALUE);

    // 3.1 get 1's complement
    //
    crc16 = ~crc16;

    // 3.2 attach CRC16 and correct length, lobyte first
    //
    TxMessage.Payload[length++] = LOBYTE(crc16);
    TxMessage.Payload[length++] = HIBYTE(crc16);

    // 4. forward message to SLIP layer
    //    - start transmission with SAP ID
    //    - correct length by header size

    // If radio not in rx mode -> polling timer for rx dma is off
    // start timer
//    if( radio_state != IM880B_STATE_RX)
//	{
//    iM880B_hal_SartRxDMA();
    iM880B_hal_UART_start_rx( );
//	}
    if (iM880B_ComSlip_SendMessage(&TxMessage.SapID, length + WIMODLR_HCI_MSG_HEADER_SIZE))
    {
//    	// Ok! - Now wait for answer from modul
//    	com_result = WaitHCIResponse();
//    	// No answer -> retry
//    	if(com_result != WiMODLR_RESULT_OK)
//    	{
//    		iM880B_ComSlip_SendMessage(&TxMessage.SapID, length + WIMODLR_HCI_MSG_HEADER_SIZE);
//    		com_result = WaitHCIResponse();
//    	}
    	com_result = WiMODLR_RESULT_OK;
    }
    //iM880B_hal_SartRxDMA();
	return com_result;
// Stop polling timer is radio not in rx mode
//    if( radio_state != IM880B_STATE_RX)
//	{
//		iM880B_hal_StopRxDMA();
//	}

 // SLIP layer wasn't able to sent
//    iM880B_hal_SartRxDMA( );
//    return com_result;
}

/**
 * 	see header file
 */
TWiMDLRResultcodes iM880x_SendUDataTelegram( 	uint8_t port, uint8_t *payload,
												uint16_t length)
{
	TxMessage.Payload[0] = port;

	if( payload && length ){
		uint8_t *dstPtr = TxMessage.Payload + 1;
		int n			= (int)length;

		// copy bytes
		while(n--){
			*dstPtr++ = *payload++;
		}
	}
	return (TWiMDLRResultcodes) SendHCIMessage(LORAWAN_ID, LORAWAN_MSG_SEND_UDATA_REQ, NULL, length + 1);
}

/**
 * 	see header file
 */
TWiMDLRResultcodes iM880x_SendCDataTelegram(	uint8_t port, uint8_t* payload,
												uint16_t length)
{
    TxMessage.Payload[0] = port;

    if(payload && length){
        uint8_t *dstPtr  = TxMessage.Payload + 1;
        int     n       = (int)length;

        // copy bytes
        while(n--) {
            *dstPtr++ = *payload++;
        }
    }

    return (TWiMDLRResultcodes) SendHCIMessage(LORAWAN_ID, LORAWAN_MSG_SEND_CDATA_REQ, NULL, length + 1);
}


/**
 * 	see header file
 */
TWiMDLRResultcodes iM880x_DirectDeviceActivation(	uint32_t deviceAddress,
													uint8_t* nwkSessionKey,
													uint8_t* appSessionKey)
{
    HTON32(&TxMessage.Payload[0], deviceAddress);

    if(nwkSessionKey) {
        uint8_t *dstPtr  = TxMessage.Payload + DEVICE_ADDR_LEN;
        int     n       = KEY_LEN;

        // copy bytes
        while(n--){
            *dstPtr++ = *nwkSessionKey++;
        }
    }

    if(appSessionKey) {
        uint8_t *dstPtr  = TxMessage.Payload + DEVICE_ADDR_LEN + KEY_LEN;
        int     n       = KEY_LEN;

        // copy bytes
        while(n--) {
            *dstPtr++ = *appSessionKey++;
        }
    }
    return (TWiMDLRResultcodes) SendHCIMessage(LORAWAN_ID, LORAWAN_MSG_ACTIVATE_DEVICE_REQ, NULL, DEVICE_ADDR_LEN + KEY_LEN + KEY_LEN);
}


/**
 * 	see header file
 */
TWiMDLRResultcodes iM880x_SetJoinParameters(uint8_t* appEUI, uint8_t* deviceKey)
{

    if(appEUI) {
    	uint8_t*  dstPtr  = TxMessage.Payload;
        int     n       = EUI_LEN;

        // copy bytes
        while(n--) {
            *dstPtr++ = *appEUI++;
        }
    }

    if(deviceKey) {
    	uint8_t*  dstPtr  = TxMessage.Payload + EUI_LEN;
        int     n       = KEY_LEN;

        // copy bytes
        while(n--) {
            *dstPtr++ = *deviceKey++;
        }
    }

    return (TWiMDLRResultcodes) SendHCIMessage(	LORAWAN_ID,
    											LORAWAN_MSG_SET_JOIN_PARAM_REQ,
												NULL,
												EUI_LEN + KEY_LEN);
}

/**
 * 	see header file
 */
TWiMDLRResultcodes iM880x_JoinNetworkRequest(void)
{
    return (TWiMDLRResultcodes) SendHCIMessage(LORAWAN_ID,
    							LORAWAN_MSG_JOIN_NETWORK_REQ,
								NULL,
								0);
}


/**
 * 	see header file
 */
TWiMODLRResult iM880x_PingRequest()
{
    return (TWiMDLRResultcodes) SendHCIMessage(	DEVMGMT_ID,
    											DEVMGMT_MSG_PING_REQ,
												NULL,
												0);
}


/**
 * 	see header file
 */
TWiMODLRResult iM880x_SetRadioStackConfiguration(void)
{
    uint8_t offset = 0;

    configBuffer[offset++]   =  2;      // SF 10
    configBuffer[offset++]   =  14;    	// Tx Power level [dBm]
    configBuffer[offset++]   =  0x01;   // 00000001
                                        // ||||||||
                                        // |||||||- ADR enabled
                                        // ||||||-- Duty Cycle Control disabled
                                        // |||||--- Class A selected
                                        // -------- Rx MAC Command Forwarding disabled
    configBuffer[offset++]   =  1;      // Automatic Power Saving on
    configBuffer[offset++]   =  1;      // Number of Retransmissions
    configBuffer[offset++]   =  1;      // Radio Band Selection (1 == EU)

    // Set Configuration
    return	SendHCIMessage(	LORAWAN_ID,
    						LORAWAN_MSG_SET_RSTACK_CONFIG_REQ,
							(unsigned char*)&configBuffer,
							6);
}

/**
 * see header file
 */
TWiMODLRResult iM880x_ResetRequest( void )
{
	return (TWiMDLRResultcodes) SendHCIMessage( DEVMGMT_ID,
												DEVMGMT_MSG_RESET_REQ,
												NULL,
												0);
}

/**
 * 	see header file
 */
TWiMDLRResultcodes iM880x_SetSystemOperationMode(uint8_t operationMode)
{
	uint8_t *dstPtr  = TxMessage.Payload;
    *dstPtr = operationMode;
    return (TWiMDLRResultcodes) SendHCIMessage(	DEVMGMT_ID,
    											DEVMGMT_MSG_SET_OPMODE_REQ,
												NULL,
												1);
}


/**
 * 	see header file
 */
TWiMDLRResultcodes iM880x_SetDeviceEUI(uint8_t *deviceEUI)
{
    if(deviceEUI)
    {
    	uint8_t*  dstPtr  = TxMessage.Payload;
        int     n       = EUI_LEN;

        // copy bytes
        while(n--)
            *dstPtr++ = *deviceEUI++;
    }

    return (TWiMDLRResultcodes) SendHCIMessage(	LORAWAN_ID,
    											LORAWAN_MSG_SET_DEVICE_EUI_REQ,
												NULL,
												EUI_LEN);
}


/**
 * 	see header file
 */
TWiMDLRResultcodes iM880x_Nwk_Status_Req( void )
{
	return (TWiMDLRResultcodes) SendHCIMessage( LORAWAN_ID,
												LORAWAN_MSG_GET_NWK_STATUS_REQ,
												NULL,
												0);
}
/**
 * 	see header file
 */
void iM880x_Init(void)
{
    // Init Slip Layer
	iM880B_ComSlip_Init();
	iM880B_ComSlip_RegisterClient(iM880x_CbProcessRxMessage);

    // pass first RxBuffer and enable receiver/decoder
	iM880B_ComSlip_SetRxBuffer(&RxMessage.SapID, (uint16_t)WIMODLR_HCI_RX_MESSAGE_SIZE);
}

/**
 * 	see header file
 */
void iM880x_RegisterRadioCallbacks(	TRadioInterfaceCbMsgIndication cbMsgInd,
                              TRadioInterfaceCbLoRaWANHCIResponse  cbLoRaWANHCIRsp,
                              TRadioInterfaceCbDevMgmtHCIResponse  cbDevMgmtHCIRsp)
{
    cbMsgIndication      = cbMsgInd;
    cbLoRaWANHCIResponse = cbLoRaWANHCIRsp;
    cbDevMgmtHCIResponse = cbDevMgmtHCIRsp;
}



void iM880x_ActivateDevice ( void )
{

}
//------------------------------------------------------------------------------
//
//  iM880x_CbProcessRxMessage
//
//  @brief: Handle incoming HCI messages
//
//------------------------------------------------------------------------------

static uint8_t* iM880x_CbProcessRxMessage(uint8_t* rxBuffer, uint16_t length)
{
    // 1. check CRC
    if (CRC16_Check(rxBuffer, length, CRC16_INIT_VALUE))
    {
        // 2. check min length, 2 bytes for SapID + MsgID + 2 bytes CRC16
        if(length >= (WIMODLR_HCI_MSG_HEADER_SIZE + WIMODLR_HCI_MSG_FCS_SIZE))
        {
            // add length
            RxMessage.Length = length - (WIMODLR_HCI_MSG_HEADER_SIZE + WIMODLR_HCI_MSG_FCS_SIZE);

            // dispatch completed RxMessage
            // 3. forward message according to SapID / MsgID
            switch(RxMessage.SapID)
            {
                case    DEVMGMT_ID:
                		//if( RxMessage.Payload[0] == 0x00)	//TODO: exchange with define
                		//{
                        // forward Msg IDs to application, e.g. ping response
                		//	DevMgmt_CmdOk_Flag = 1;
						(*cbDevMgmtHCIResponse)(RxMessage.MsgID, RxMessage.Payload, length);
//                		} else {
//                			DevMgmt_Fail_Flag = 1;
//                		}
                        break;

                case    LORAWAN_ID:
                        // handle TX indications
                        if((RxMessage.MsgID == LORAWAN_MSG_SEND_UDATA_TX_IND)   ||
                           (RxMessage.MsgID == LORAWAN_MSG_SEND_CDATA_TX_IND)   ||
                           (RxMessage.MsgID == LORAWAN_MSG_JOIN_NETWORK_TX_IND))
                        {
                            (*cbMsgIndication)(NULL, 0, WIMOD_TX_DONE);
                        }
                        // handle RX messages
                        else if((RxMessage.MsgID == LORAWAN_MSG_RECV_UDATA_IND) ||
                                (RxMessage.MsgID == LORAWAN_MSG_RECV_CDATA_IND))
                        {
                            (*cbMsgIndication)(RxMessage.Payload, length, WIMOD_RX_DONE);
                        }

                        // handle ACKs
                        else if(RxMessage.MsgID == LORAWAN_MSG_RECV_ACK_IND)
                        {
                            (*cbMsgIndication)(NULL, 0, WIMOD_RX_ACK_DONE);
                        }
                        else if(RxMessage.MsgID == LORAWAN_MSG_RECV_NO_DATA_IND)
                        {
                        	(*cbMsgIndication)(NULL, 0, WIMOD_RX_WINDOW_ELAPSED);
                        }
                        // handle other responses
                        else
                        {
                       		(*cbLoRaWANHCIResponse)(RxMessage.MsgID, RxMessage.Payload, length);
                        }

                        break;

                default:
                        // handle unsupported SapIDs here
                        break;
            }
        }
    }
    else
    {
        // handle CRC error
    }

    // return same buffer again, keep receiver enabled
    return &RxMessage.SapID;

}

