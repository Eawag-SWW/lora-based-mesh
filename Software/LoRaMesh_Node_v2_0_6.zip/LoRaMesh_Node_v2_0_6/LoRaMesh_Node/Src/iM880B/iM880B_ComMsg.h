/**
 * @file iM880B_ComMsg.h
 * <!------------------------------------------------------------------------>
 * @brief @ref REF "WiMODLR HCI Example"
 *
 * @par Project:
 * <!------------------------------------------------------------------------>
 * <!--
 * @par Description:
 *
 *  [Description]
 * -->
 * <!--
 *  @ref [extdocname] "more..."
 *  -->
 * <!------------------------------------------------------------------------>
 * <!--
 * @remarks
 * - [...]
 * - [...]
 * -->
 * <!------------------------------------------------------------------------
 * Copyright (c) 2015
 * IMST GmbH
 * Carl-Friedrich Gauss Str. 2
 * 47475 Kamp-Lintfort
 * -------------------------------------------------------------------------->
 * @author Mathias Hater (MH), IMST
 * <!------------------------------------------------------------------------
 * Target OS:    none
 * Target CPU:   EFM32
 * Compiler:     IAR C/C++ Compiler
 * -------------------------------------------------------------------------->
 * @internal
 * @par Revision History:
 * <PRE>
 * ---------------------------------------------------------------------------
 * Version | Date       | Author | Comment
 * ---------------------------------------------------------------------------
 * 0.1     | 22.01.2015 | MH     | Created
 *
 * </PRE>

 Copyright (c) 2015 IMST GmbH.
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are NOT permitted without prior written permission
 of the IMST GmbH.

 THIS SOFTWARE IS PROVIDED BY THE IMST GMBH AND CONTRIBUTORS ``AS IS'' AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE IMST GMBH OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 THIS SOFTWARE IS CLASSIFIED AS: CONFIDENTIAL

 *******************************************************************************/


#ifndef iM880B_ComMsg_RADIOINTERFACE_H_
#define iM880B_ComMsg_RADIOINTERFACE_H_


//------------------------------------------------------------------------------
//
// Include Files
//
//------------------------------------------------------------------------------
#include "stdint.h"



//------------------------------------------------------------------------------
//
//	Section Defines
//
//------------------------------------------------------------------------------

#define DEVICE_ADDR_LEN      4
#define KEY_LEN             16
#define EUI_LEN              8


//------------------------------------------------------------------------------
//
// General Declaration
//
//------------------------------------------------------------------------------

typedef uint16_t        TWiMODLRResult;

//------------------------------------------------------------------------------
//
// Definition of Result/Error Codes
//
//------------------------------------------------------------------------------

typedef enum
{
    WiMODLR_RESULT_OK = 0,
    WiMODLR_RESULT_PAYLOAD_LENGTH_ERROR,
    WiMODLR_RESULT_PAYLOAD_PTR_ERROR,
    WiMODLR_RESULT_TRANMIT_ERROR,
    WiMODLR_COM_ERROR
}TWiMDLRResultcodes;


//------------------------------------------------------------------------------
//
// Service Access Point Identifier
//
//------------------------------------------------------------------------------

#define DEVMGMT_ID                          0x01
#define LORAWAN_ID                          0x10


//------------------------------------------------------------------------------
//
// Device Management Message Identifier
//
//------------------------------------------------------------------------------

// Status Codes
#define	DEVMGMT_STATUS_OK						0x00
#define	DEVMGMT_STATUS_ERROR					0x01
#define	DEVMGMT_STATUS_CMD_NOT_SUPPORTED		0x02
#define	DEVMGMT_STATUS_WRONG_PARAMETER			0x03
//#define DEVMGMT_STATUS_WRONG_DEVICE_MODE    0x04 	// not in HCI spec V1.13

// Message IDs
#define DEVMGMT_MSG_PING_REQ                	0x01
#define DEVMGMT_MSG_PING_RSP                	0x02

#define DEVMGMT_MSG_GET_DEVICEINFO_REQ      	0x03
#define DEVMGMT_MSG_GET_DEVICEINFO_RSP      	0x04

#define DEVMGMT_MSG_GET_FW_INFO_REQ				0x05
#define DEVMGMT_MSG_GET_FW_INFO_RSP      		0x06

#define DEVMGMT_MSG_RESET_REQ                   0x07
#define DEVMGMT_MSG_RESET_RSP                   0x08

#define DEVMGMT_MSG_SET_OPMODE_REQ              0x09
#define DEVMGMT_MSG_SET_OPMODE_RSP              0x0A
#define DEVMGMT_MSG_GET_OPMODE_REQ              0x0B
#define DEVMGMT_MSG_GET_OPMODE_RSP              0x0C


//------------------------------------------------------------------------------
//
// LoRaWAN Endpoint Message Identifier
//
//------------------------------------------------------------------------------

// Status Codes
#define LORAWAN_STATUS_OK	                	0x00	// Operation successful
#define LORAWAN_STATUS_ERROR	            	0x01	// Operation failed
#define LORAWAN_STATUS_CMD_NOT_SUPPORTED		0x02	// Command is not supported
#define LORAWAN_STATUS_WRONG_PARAMETER	    	0x03	// HCI message contains wrong parameter
#define LORAWAN_STATUS_DEVICE_NOT_ACTIVATED		0x05	// Device is not activated
#define LORAWAN_STATUS_DEVICE_BUSY	        	0x06	// Device is busy
#define LORAWAN_STATUS_QUEUE_FULL				0x07	// Message queue full
#define LORAWAN_STATUS_LENGTH_ERROR	       	 	0x08	// Radio packet length invalid
#define LORAWAN_STATUS_NO_FACTORY_SETTINGS		0x09	// Factory settings EEPROM block missing
#define LORAWAN_STATUS_CHANNEL_BLOCKED			0x0A	// Channel blocked by duty cycle
#define LORAWAN_STATUS_CHANNEL_NOT_AVAILABLE	0x0B// No channel available (e.g. no channel defined for the configured spreading factor)

// Message IDs
#define LORAWAN_MSG_ACTIVATE_DEVICE_REQ	    0x01
#define LORAWAN_MSG_ACTIVATE_DEVICE_RSP	    0x02
#define LORAWAN_MSG_SET_JOIN_PARAM_REQ	    0x05
#define LORAWAN_MSG_SET_JOIN_PARAM_RSP	    0x06
#define LORAWAN_MSG_JOIN_NETWORK_REQ	    0x09
#define LORAWAN_MSG_JOIN_NETWORK_RSP	    0x0A
#define LORAWAN_MSG_JOIN_NETWORK_TX_IND	    0x0B
#define LORAWAN_MSG_JOIN_NETWORK_IND	    0x0C
#define LORAWAN_MSG_SEND_UDATA_REQ	        0x0D
#define LORAWAN_MSG_SEND_UDATA_RSP	        0x0E
#define LORAWAN_MSG_SEND_UDATA_TX_IND	    0x0F
#define LORAWAN_MSG_RECV_UDATA_IND	        0x10
#define LORAWAN_MSG_SEND_CDATA_REQ	        0x11
#define LORAWAN_MSG_SEND_CDATA_RSP	        0x12
#define LORAWAN_MSG_SEND_CDATA_TX_IND	    0x13
#define LORAWAN_MSG_RECV_CDATA_IND	        0x14
#define LORAWAN_MSG_RECV_ACK_IND	        0x15
#define LORAWAN_MSG_RECV_NO_DATA_IND		0x16
#define LORAWAN_MSG_SET_RSTACK_CONFIG_REQ   0x19
#define LORAWAN_MSG_SET_RSTACK_CONFIG_RSP   0x1A
#define LORAWAN_MSG_GET_RSTACK_CONFIG_REQ   0x1B
#define LORAWAN_MSG_GET_RSTACK_CONFIG_RSP   0x1C
#define LORAWAN_MSG_REACTIVATE_DEVICE_REQ	0x1D
#define LORAWAN_MSG_REACTIVATE_DEVICE_RSP	0x1E
#define LORAWAN_MSG_DEACTIVATE_DEVICE_REQ	0x21
#define LORAWAN_MSG_DEACTIVATE_DEVICE_RSP	0x22
#define LORAWAN_MSG_FACTORY_RESET_REQ       0x23
#define LORAWAN_MSG_FACTORY_RESET_RSP       0x24
#define LORAWAN_MSG_SET_DEVICE_EUI_REQ      0x25
#define LORAWAN_MSG_SET_DEVICE_EUI_RSP      0x26
#define LORAWAN_MSG_GET_DEVICE_EUI_REQ		0x27
#define LORAWAN_MSG_GET_DEVICE_EUI_RSP		0x28
#define LORAWAN_MSG_GET_NWK_STATUS_REQ		0x29
#define LORAWAN_MSG_GET_NWK_STATUS_RSP		0x2A
#define LORAWAN_MSG_SEND_MAC_CMD_REQ		0x2B
#define LORAWAN_MSG_SEND_MAC_CMD_RSP		0x2C
#define LORAWAN_MSG_RECV_MAC_CMD_IND		0x2D
#define LORAWAN_MSG_SET_CUSTOM_CFG_REQ		0x31
#define LORAWAN_MSG_SET_CUSTOM_CFG_RSP		0x32
#define LORAWAN_MSG_GET_CUSTOM_CFG_REQ		0x33
#define LORAWAN_MSG_GET_CUSTOM_CFG_RSP		0x34

//System Operation Modes
#define LORAWAN_OPMODE_STANDARD                 0x00
#define LORAWAN_OPMODE_CUSTOMER_MODE            0x03


//------------------------------------------------------------------------------
//
// HCI Message Declaration
//
//------------------------------------------------------------------------------

// message header size: 2 bytes for SapID + MsgID
#define WIMODLR_HCI_MSG_HEADER_SIZE	 	2

// message payload size
#define WIMODLR_HCI_MSG_PAYLOAD_SIZE	300

// frame check sequence field size: 2 bytes for CRC16
#define WIMODLR_HCI_MSG_FCS_SIZE		2



//#define LORA_MAC_PORT                   0x02




// visible max. buffer size for lower SLIP layer
#define WIMODLR_HCI_RX_MESSAGE_SIZE (WIMODLR_HCI_MSG_HEADER_SIZE\
                                    +WIMODLR_HCI_MSG_PAYLOAD_SIZE\
                                    +WIMODLR_HCI_MSG_FCS_SIZE)


//------------------------------------------------------------------------------
//
// public available Data Types
//
//------------------------------------------------------------------------------


typedef struct
{
    // Payload Length Information, not transmitted over UART interface !
    uint16_t  Length;

    // Service Access Point Identifier
    uint8_t   SapID;

    // Message Identifier
    uint8_t   MsgID;

    // Payload Field
    uint8_t   Payload[WIMODLR_HCI_MSG_PAYLOAD_SIZE];

    // Frame Check Sequence Field
    uint8_t   CRC16[WIMODLR_HCI_MSG_FCS_SIZE];

}TWiMODLR_HCIMessage;

typedef enum {
	WIMOD_NO_INDICATION = 0,
	WIMOD_JOIN_DONE,
	WIMOD_TX_DONE,
	WIMOD_RX_DONE,
	WIMOD_RX_ACK_DONE,
	WIMOD_RX_WINDOW_ELAPSED
}tWiMODLRWanIndication;



typedef void (*TRadioInterfaceCbMsgIndication)      (uint8_t* msg, uint8_t length, tWiMODLRWanIndication indication);
typedef void (*TRadioInterfaceCbLoRaWANHCIResponse) (uint8_t msgID, uint8_t* msg, uint8_t length);
typedef void (*TRadioInterfaceCbDevMgmtHCIResponse) (uint8_t msgID, uint8_t* msg, uint8_t length);


//------------------------------------------------------------------------------
//
// Definition of Configuration Fields
//
//------------------------------------------------------------------------------
typedef struct sIM880B_Config_Fields
{
	uint8_t NVM_Flag;
	uint8_t RadioMode;
	uint8_t GroupAddress;
	uint8_t TxGroupAddress;
	uint16_t DeviceAddress;
	uint16_t TxDeviceAddress;
	uint8_t Modulation;
	uint8_t RfFreq_LSB;
	uint8_t RfFreq_ISB;
	uint8_t RfFreq_MSB;
	uint8_t LoRa_Bandwidth;
	uint8_t LoRa_SpreadingFactor;
	uint8_t LoRa_ErrorCoding;
	uint8_t PowerLevel;
	uint8_t TxControl;
	uint8_t RxControl;
	uint16_t RxWindowTime;
	uint8_t LEDControl;
	uint8_t MiscOptions;
	uint8_t FSK_Datarate;
	uint8_t AutoPowerSaving;
	int16_t LBTtreshold;
}tIM880B_Config_Fields;




//------------------------------------------------------------------------------
//
//  Section Prototypes
//
//------------------------------------------------------------------------------

/**
 * 	\brief	send an unconfirmed data telegram
 * 	\param	port		LoRaWAN MAC port
 *  \param	*payload	pointer to payload buffer
 *  \param	length		lenght of the payload
 */
TWiMDLRResultcodes iM880x_SendUDataTelegram( 	uint8_t port, uint8_t *payload,
												uint16_t length);

/**
 * 	\brief	send a confirmed data telegram
 * 	\param	port		LoRaWAN MAC port
 *  \param	*payload	pointer to payload buffer
 *  \param	length		lenght of the payload
 */
TWiMDLRResultcodes iM880x_SendCDataTelegram(	uint8_t port, uint8_t* payload,
												uint16_t length);


/**
 * 	\brief	direct device activation
 */
TWiMDLRResultcodes iM880x_DirectDeviceActivation(uint32_t deviceAddress,
												 uint8_t* nwkSessionKey,
												 uint8_t* appSessionKey);

/**
 * 	\brief	Configure the Join parameters
 */
TWiMDLRResultcodes iM880x_SetJoinParameters(uint8_t* appEUI, uint8_t* deviceKey);

/**
 * 	\brief	Send out a Join Request message
 */
TWiMDLRResultcodes iM880x_JoinNetworkRequest(void);

/**
 * 	\brief	sends a ping request to the iM880x module
 */
TWiMODLRResult iM880x_PingRequest();

/**
 * 	\brief	Configure the integrated radio stack
 */
TWiMODLRResult iM880x_SetRadioStackConfiguration(void);

/**
 * 	\brief	Sends a reset request to the radio module
 */
TWiMODLRResult iM880x_ResetRequest( void );
/**
 * 	\brief	sets the operation mode
 */
TWiMDLRResultcodes iM880x_SetSystemOperationMode(uint8_t operationMode);

/**
 * 	\brief	sets the device EUI
 */
TWiMDLRResultcodes iM880x_SetDeviceEUI(uint8_t *deviceEUI);

/**
 * 	\brief	Gets current network status
 */
TWiMDLRResultcodes iM880x_Nwk_Status_Req( void );
/**
 * 	\brief	Initialized the radio interface
 */
void iM880x_Init(void);

/**
 * 	\brief	sets callback function for incoming HCI messages
 */
void iM880x_RegisterRadioCallbacks(	TRadioInterfaceCbMsgIndication cbMsgInd,
                              TRadioInterfaceCbLoRaWANHCIResponse  cbLoRaWANHCIRsp,
                              TRadioInterfaceCbDevMgmtHCIResponse  cbDevMgmtHCIRsp) ;

#if 0
void 
iM880B_ComMsg_Init(void);

//void
//iM880B_ComMsg_RegisterRadioCallbacks(TRadioInterfaceCbRxIndication cbRxInd,
//                              TRadioInterfaceCbTxIndication cbTxInd);

void
iM880x_RegisterRadioCallbacks(TRadioInterfaceCbMsgIndication        cbMsgInd,
                              TRadioInterfaceCbLoRaWANHCIResponse   cbLoRaWANHCIRsp,
                              TRadioInterfaceCbDevMgmtHCIResponse   cbDevMgmtHCIRsp);

tIM880B_Config_Fields iM880B_ComMsg_GetConfig( void );

TWiMODLRResult iM880B_ComMsg_SetDefaultConfig(void);

TWiMODLRResult iM880B_ComMsg_Configure( tIM880B_Config_Fields newiM880B_Settings );

TWiMDLRResultcodes 
iM880B_ComMsg_SendRadioTelegram(uint8_t* payload, uint16_t length, uint16_t txAdress);

TWiMODLRResult 
iM880B_ComMsg_PingRequest();

TWiMODLRResult 
iM880B_ComMsg_PowerDown(void);

TWiMODLRResult 
iM880B_ComMsg_WakeUp(void);

TWiMODLRResult
iM880B_ComMsg_ResetRadioConfig(void);

TWiMODLRResult
iM880B_ComMsg_ResetRequest(void);

TWiMODLRResult iM880B_ComMsg_StartRX(void);

TWiMODLRResult iM880B_ComMsg_StopRX(void);
#endif

#endif  
