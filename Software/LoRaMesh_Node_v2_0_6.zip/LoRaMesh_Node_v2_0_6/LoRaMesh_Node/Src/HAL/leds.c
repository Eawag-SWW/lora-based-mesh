/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		leds.c
 *
 * \description	Handling of LED states
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "leds.h"
#include "stm32l4xx.h"
#include "mcu_pinout.h"
/* -- makros ----------------------------------------------------------------*/
#define LED_ON		GPIO_PIN_SET
#define LED_OFF		GPIO_PIN_RESET

/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */

 
/* internal variable definitions ------------------------------------------- */ 
 

/* public function definitions --------------------------------------------- */

/*
 * See header file
 */
void LEDS_Init( void )
{
	GPIO_InitTypeDef GPIO_InitStruct;

	if( __HAL_RCC_GPIOB_IS_CLK_DISABLED())
	{
		__HAL_RCC_GPIOB_CLK_ENABLE();	// LED1/2 port
	}

	GPIO_InitStruct.Pin = LED1_PIN | LED2_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(LED_PORT, &GPIO_InitStruct);
	HAL_GPIO_WritePin( LED_PORT, (LED1_PIN | LED2_PIN), LED_OFF);
}

/*
 * 	See header file
 */
void LED_ora_on ( void )
{
	HAL_GPIO_WritePin( LED_PORT, LED1_PIN, LED_ON );
}

/*
 * 	See header file
 */
void LED_ora_off ( void )
{
	HAL_GPIO_WritePin( LED_PORT, LED1_PIN, LED_OFF );
}

/*
 * 	See header file
 */
void LED_ora_toggle ( void )
{
	HAL_GPIO_TogglePin( LED_PORT, LED1_PIN );
}

/*
 * 	See header file
 */
void LED_gn_on ( void )
{
	HAL_GPIO_WritePin( LED_PORT, LED2_PIN, LED_ON );
}

/*
 * 	See header file
 */
void LED_gn_off ( void )
{
	HAL_GPIO_WritePin( LED_PORT, LED2_PIN, LED_OFF );
}

/*
 * 	See header file
 */
void LED_gn_toggle ( void )
{
	HAL_GPIO_TogglePin( LED_PORT, LED2_PIN );
}



/* internal functions definitions ------------------------------------------ */



