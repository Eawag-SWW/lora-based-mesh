/**
 * @author  Tilen Majerle
 * @email   tilen@majerle.eu
 * @website http://stm32f4-discovery.com
 * @link    http://stm32f4-discovery.com/2014/05/library-12-onewire-library-for-stm43f4xx/
 * @version v2.1
 * @ide     Keil uVision
 * @license GNU GPL v3
 * @brief   Onewire library for STM32F4 devices
 *	
@verbatim
   ----------------------------------------------------------------------
    Copyright (C) Tilen Majerle, 2015
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.
     
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
   ----------------------------------------------------------------------
@endverbatim
 */
 /* re-definition guard */
#ifndef ONEWIRE_H
#define ONEWIRE_H

/* -- includes --------------------------------------------------------------*/
#include "stm32l4xx.h"
#include "stm32l4xx_hal_rcc.h"
#include "stm32l4xx_hal_gpio.h"

/* -- makros ----------------------------------------------------------------*/

/* Pin settings */
#define ONEWIRE_LOW(structure)			HAL_GPIO_WritePin(structure->GPIOx, structure->GPIO_Pin,GPIO_PIN_RESET)
#define ONEWIRE_HIGH(structure)			HAL_GPIO_WritePin(structure->GPIOx, structure->GPIO_Pin,GPIO_PIN_SET)
#define ONEWIRE_INPUT(structure)		HAL_GPIO_Init(structure->GPIOx, structure->GPIO_Init_input)
#define ONEWIRE_OUTPUT(structure)		HAL_GPIO_Init(structure->GPIOx, structure->GPIO_Init_output)

/* OneWire commands */
#define ONEWIRE_CMD_RSCRATCHPAD			0xBE
#define ONEWIRE_CMD_WSCRATCHPAD			0x4E
#define ONEWIRE_CMD_CPYSCRATCHPAD		0x48
#define ONEWIRE_CMD_RECEEPROM			0xB8
#define ONEWIRE_CMD_RPWRSUPPLY			0xB4
#define ONEWIRE_CMD_SEARCHROM			0xF0
#define ONEWIRE_CMD_READROM				0x33
#define ONEWIRE_CMD_MATCHROM			0x55
#define ONEWIRE_CMD_SKIPROM				0xCC

/* -- type definitions-------------------------------------------------------*/

/**
 * \brief  OneWire working struct
 * \note   Except ROM_NO member, everything is fully private and should not be touched by user
 */
typedef struct {
	GPIO_InitTypeDef *GPIO_Init_output;	   	/*!< GPIO parameters to init as output port */
	GPIO_InitTypeDef *GPIO_Init_input;	   	/*!< GPIO parameters to init as input port */
	GPIO_TypeDef *GPIOx;           			/*!< GPIOx port to be used for I/O functions */
	uint16_t GPIO_Pin;             			/*!< GPIO Pin to be used for I/O functions */
	uint8_t LastDiscrepancy;       			/*!< Search private */
	uint8_t LastFamilyDiscrepancy; 			/*!< Search private */
	uint8_t LastDeviceFlag;        			/*!< Search private */
	uint8_t ROM_NO[8];             			/*!< 8-bytes address of last search device */
} OneWire_t;

/* public function declarations -------------------------------------------- */

/**
 * \brief  Initializes OneWire bus
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t empty working onewire structure
 * \param  *Pointer to GPIO port used for onewire channel
 * \param  GPIO_Pin: GPIO Pin on specific GPIOx to be used for onewire channel
 * \return None
 */
void OneWire_Init(OneWire_t* OneWireStruct, GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);

/**
 * \brief  Deinitializes OneWire bus
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire structure
 * \return None
 */
void OneWire_DeInit(OneWire_t* OneWireStruct);

/**
 * \brief  Resets OneWire bus
 * 
 * \note   Sends reset command for OneWire
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire structure
 * \return None
 */
uint8_t OneWire_Reset(OneWire_t* OneWireStruct);

/**
 * \brief  Reads byte from one wire bus
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire structure
 * \return Byte from read operation
 */
uint8_t OneWire_ReadByte(OneWire_t* OneWireStruct);

/**
 * \brief  Writes byte to bus
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire structure
 * \param  byte: 8-bit value to write over OneWire protocol
 * \return None
 */
void OneWire_WriteByte(OneWire_t* OneWireStruct, uint8_t byte);

/**
 * \brief  Writes single bit to onewire bus
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire structure
 * \param  bit: Bit value to send, 1 or 0
 * \return None
 */
void OneWire_WriteBit(OneWire_t* OneWireStruct, uint8_t bit);

/**
 * \brief  Reads single bit from one wire bus
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire structure
 * \return Bit value:
 *            - 0: Bit is low (zero)
 *            - > 0: Bit is high (one)
 */
uint8_t OneWire_ReadBit(OneWire_t* OneWireStruct);

/**
 * \brief  Reads ROM of single device on Bus
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire structure
 */
void OneWire_ReadRom(OneWire_t* OneWireStruct);

/**
 * \brief  Searches for OneWire devices on specific Onewire port
 * \note   Not meant for public use. Use \ref TM_OneWire_First and \ref TM_OneWire_Next for this.
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire structure where to search
 * \param  Device status:
 *            - 0: No devices detected
 *            - > 0: Device detected
 */
uint8_t OneWire_Search(OneWire_t* OneWireStruct, uint8_t command);

/**
 * \brief  Resets search states
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire where to reset search values
 * \return None
 */
void OneWire_ResetSearch(OneWire_t* OneWireStruct);

/**
 * \brief  Starts search, reset states first
 * \note   When you want to search for ALL devices on one onewire port, you should first use this function.
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire where to reset search values
 * \param  Device status:
 *            - 0: No devices detected
 *            - > 0: Device detected
 */
uint8_t OneWire_First(OneWire_t* OneWireStruct);

/**
 * \brief  Reads next device
 * \note   Use \ref TM_OneWire_First to start searching
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire
 * \param  Device status:
 *            - 0: No devices detected any more
 *            - > 0: New device detected
 */
uint8_t OneWire_Next(OneWire_t* OneWireStruct);

/**
 * \brief  Gets ROM number from device from search
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire
 * \param  index: Because each device has 8-bytes long ROm address, you have to call this 8 times, to get ROM bytes from 0 to 7
 * \return ROM byte for index (0 to 7) at current found device
 */
uint8_t OneWire_GetROM(OneWire_t* OneWireStruct, uint8_t index);

/**
 * \brief  Gets all 8 bytes ROM value from device from search
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire
 * \param  *firstIndex: Pointer to first location for first byte, other bytes are automatically incremented
 * \return None
 */
void OneWire_GetFullROM(OneWire_t* OneWireStruct, uint8_t *firstIndex);

/**
 * \brief  Selects specific slave on bus
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire
 * \param  *addr: Pointer to first location of 8-bytes long ROM address
 * \return None
 */
void OneWire_Select(OneWire_t* OneWireStruct, uint8_t* addr);

/**
 * \brief  Selects specific slave on bus with pointer address
 * \param  *OneWireStruct: Pointer to \ref TM_OneWire_t working onewire
 * \param  *ROM: Pointer to first byte of ROM address
 * \return None
 */
void OneWire_SelectWithPointer(OneWire_t* OneWireStruct, uint8_t* ROM);

/**
 * \brief  Calculates 8-bit CRC for 1-wire devices
 * \param  *addr: Pointer to 8-bit array of data to calculate CRC
 * \param  len: Number of bytes to check
 *
 * \return Calculated CRC from input data
 */
uint8_t OneWire_CRC8(uint8_t* addr, uint8_t len);


#endif // ONEWIRE_H

