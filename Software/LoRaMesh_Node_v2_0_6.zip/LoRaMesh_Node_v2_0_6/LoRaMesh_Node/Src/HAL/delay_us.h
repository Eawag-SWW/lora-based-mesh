/**
 * @author  Tilen Majerle
 * @email   tilen@majerle.eu
 * @website http://stm32f4-discovery.net
 * @link    http://stm32f4-discovery.net/2015/07/hal-library-3-delay-for-stm32fxxx/
 * @version v1.0
 * @ide     Keil uVision
 * @license MIT
 * @brief   Library template 
 *	
 \verbatim
 ----------------------------------------------------------------------
 Copyright (c) 2016 Tilen Majerle

 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge,
 publish, distribute, sublicense, and/or sell copies of the Software,
 and to permit persons to whom the Software is furnished to do so,
 subject to the following conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
 ----------------------------------------------------------------------
 \endverbatim
 */
 /* re-definition guard */
#ifndef DELAY_US_H
#define DELAY_US_H

/* -- includes --------------------------------------------------------------*/
#include "stm32l4xx_hal.h"
#include "stdlib.h"

/* -- makros ----------------------------------------------------------------*/

/* -- type definitions-------------------------------------------------------*/

/* public function declarations -------------------------------------------- */
/**
 * \brief  Initializes delay functions
 * \param  None
 * \return DWT counter start status
 *           - 0: DWT counter did not start, delay for microseconds won't work
 *           - > 0: DWT counter works OK, delay is ready to use
 */
uint32_t DELAY_Init(void);

/**
 * \brief  Deinitializes delay functions
 * \param  None
 * \return none
 */
void DELAY_DeInit(void);

/**
 * \brief  Delays for amount of micro seconds
 * \param  micros: Number of microseconds for delay
 * \return None
 */
__STATIC_INLINE void Delay(__IO uint32_t micros) {
	uint32_t start = DWT->CYCCNT;

	/* Go to number of cycles for system */
	micros *= (HAL_RCC_GetHCLKFreq() / 1000000);

	/* Delay till end */
	while ((DWT->CYCCNT - start) < micros)
		;
}

#endif
