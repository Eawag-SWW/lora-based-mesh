/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		adc.c
 *
 * \description	Implementation of the ADC module
 *
 * \author		F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		04.01.2018
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "adc.h"
#include "gpio.h"
#include "math.h"

/* -- makros ----------------------------------------------------------------*/
#define ADCVREG_STUP_DELAY_US	20	/*< Startup delay of the ADC
										voltage regulator in microseconds	 */
#define VREFINT_STUP_DELAY_US	12	/*< Startup delay of the internal
										voltage reference					 */
#define ADC_CLK_FREQ_HZ			32000000 /*< ADC clock frequency			 */

#define VREFINT_CAL_ADDR		((uint16_t*) (0x1FFF75AAU))
/* Internal voltage reference, address of parameter VREFINT_CAL:
 * VrefInt ADC raw data acquired at temperature 30 DegC
 * (tolerance: +-5 DegC), Vref+ = 3.0 V (tolerance: +-10 mV).
 */

/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */
static void adc_init( ADC_TypeDef *adc_inst );
static void adc_enable( ADC_TypeDef *adc );
static void adc_disable( ADC_TypeDef *adc );
static void adc_clk_config( ADC_TypeDef *adc );
//static void adc_gpio_init( void );
static void calc_sampling_times( void );
static void set_sampling_time( ADC_TypeDef *adc_inst, uint32_t sampling_time );
static uint32_t get_smp_param( uint32_t sampling_time );
static uint32_t get_configured_sampling_time( uint32_t smp_setting );
static void adc_config_channel(	ADC_TypeDef *adc,
								adc_channel_conf_s *channel );
static uint8_t adc_measure_channel( 	ADC_TypeDef *adc,
										adc_channel_conf_s *channel,
										uint16_t *pres );
static uint8_t adc_get_vdda( uint16_t *pvref, uint8_t n_average );
/* internal variable definitions ------------------------------------------- */ 
//ADC_TypeDef *ADC = ADC1;

static uint8_t adc_initialized = 0;
static uint8_t adc_enabled = 0;

static uint32_t adc_ts_lut[8];			// used to store sampling times in us
static uint32_t curr_sampling_time = 0;	// current sampling time
/* public function definitions --------------------------------------------- */

/**
 * 	See header file
 */
uint8_t ADC_meas_absolut(	ADC_TypeDef *adc_instance,
							adc_channel_conf_s *channel,
							uint16_t *res_buffer)
{
	uint16_t tvdda = 0;
	uint16_t tbuff = 0;
	uint32_t timeout = 0;
	double tvoltage = 0;

	if( (adc_instance != ADC1) && (adc_instance != ADC2) ){
		return 1;
	}

	if( adc_initialized == 0){
		adc_init( adc_instance );
	}
	if( adc_enabled == 0 ){
		adc_enable( adc_instance );
	}

	if( adc_get_vdda( &tvdda, 20 ) != 0 ){
		return 2;
	}

	timeout = channel->tsampling;
	timeout *= channel->n_averaging;	// timeout in nanoseconds
	timeout *= 1.5;						// round to next higher interger
	timeout /= 1000000;

	if( adc_measure_channel( adc_instance, channel, &tbuff ) != 0){
		return 3;
	}
	tvoltage = (double)tvdda / 255 * (double)tbuff;
	*res_buffer = (uint16_t)tvoltage;
	adc_disable( adc_instance );
	return 0;
}


/* Interrupt handlers -------------------------------------------------------*/
/**
 *	\brief	ADC IRQ handler
 */
void ADC1_2_IRQ_Handler( void )
{

}

/* internal functions definitions ------------------------------------------ */

/**
 * 	\brief	Initializes a desired ADC module
 * 	\param	*adc_inst	desired ADC instance (ADC1 or ADC2)
 */
static void adc_init( ADC_TypeDef *adc_inst )
{
	adc_clk_config( adc_inst );		// init clock
	calc_sampling_times( );			// calculates sampling time possiblities
	adc_initialized = 1;
}

/**
 * 	\brief	Configures ADC clock
 * 	\param	*adc	Instance of ADC module whose clock is initialized
 */
static void adc_clk_config( ADC_TypeDef *adc )
{
	RCC_PeriphCLKInitTypeDef perclk;
	HAL_StatusTypeDef stt;
	perclk.PeriphClockSelection = RCC_PERIPHCLK_ADC;

	__HAL_RCC_ADC_CLK_ENABLE();

	if (adc == ADC1) {
		perclk.AdcClockSelection = RCC_ADCCLKSOURCE_PLLSAI1;
		perclk.PLLSAI1.PLLSAI1M = 1;
		perclk.PLLSAI1.PLLSAI1N = 8;
		perclk.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV7;
		perclk.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
		perclk.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_ADC1CLK;
		if( __HAL_RCC_GET_PLL_OSCSOURCE() == RCC_PLLSOURCE_HSE){
			perclk.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_HSE;
			perclk.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
		} else if (__HAL_RCC_GET_PLL_OSCSOURCE() == RCC_PLLSOURCE_HSI ){
			perclk.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_HSI;
			perclk.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV4;
		}
	} else if (adc == ADC2){
		perclk.AdcClockSelection = RCC_ADCCLKSOURCE_PLLSAI2;
		perclk.PLLSAI2.PLLSAI2Source = RCC_PLLSOURCE_HSE;
		perclk.PLLSAI2.PLLSAI2M = 1;
		perclk.PLLSAI2.PLLSAI2N = 8;
		perclk.PLLSAI2.PLLSAI2P = RCC_PLLP_DIV7;
		perclk.PLLSAI2.PLLSAI2ClockOut = RCC_PLLSAI2_ADC2CLK;
		if( __HAL_RCC_GET_PLL_OSCSOURCE() == RCC_PLLSOURCE_HSE){
			perclk.PLLSAI2.PLLSAI2R = RCC_PLLR_DIV2;
		} else if (__HAL_RCC_GET_PLL_OSCSOURCE() == RCC_PLLSOURCE_HSI ){
			perclk.PLLSAI2.PLLSAI2R = RCC_PLLR_DIV4;
		}
	}

	stt = HAL_RCCEx_PeriphCLKConfig(&perclk );
	if( stt != HAL_OK ){

		__asm("BKPT 255");
	}
}

/**
 * 	\brief	Enables desired ADC module
 * 				- Wakes the module from deep power shutdown mode
 * 				- Enables the internal voltage regulator
 * 				- Executes automous calibration process
 * 				- Enables the module
 * 	\param	*adc	desired ADC instance to be initialized
 */
static void adc_enable( ADC_TypeDef *adc )
{
	uint32_t wait_loop_index = 0;

	if( adc_initialized == 0 ){
		adc_init( adc );
	}
	if( __HAL_RCC_ADC_IS_CLK_DISABLED( )){
		__HAL_RCC_ADC_CLK_ENABLE( );
	}

	// Enable Interrupts
	adc->IER |= ADC_IER_ADRDYIE;
	// Do calibration
	adc->CR &=~ADC_CR_DEEPPWD;		// Exit deep power down mode
	adc->CR |= ADC_CR_ADVREGEN;		// Start Voltage regulator

    wait_loop_index = (ADCVREG_STUP_DELAY_US * (SystemCoreClock / (1000000 * 2)));
    while(wait_loop_index != 0)		// Wait for VREG startup time
    {
      wait_loop_index--;
    }

    adc->CR |= ADC_CR_ADCAL;
    while((adc->CR & ADC_CR_ADCAL) != 0){

    }

    // TODO: calibration

	adc->ISR |= ADC_ISR_ADRDY;	// clear the ready flag
	adc->CR |= ADC_CR_ADEN;
	while( (adc->ISR & ADC_ISR_ADRDY) != ADC_ISR_ADRDY ){

	}
	adc_enabled = 1;
}


/**
 *  \brief  Disables the ADC peripheral if adc is enabled and
 *  \param  *adc	desired intance of ADC to be disabled
 */
static void adc_disable( ADC_TypeDef *adc )
{
	if((adc->CR & ADC_CR_ADEN) == ADC_CR_ADEN){
		if(	((adc->CR & ADC_CR_ADSTART) == 0 ) &&
			((adc->CR & ADC_CR_JADSTART) == 0) ){
				adc->CR |= ADC_CR_ADDIS;
		} else {
			adc->CR |= (ADC_CR_ADSTP | ADC_CR_JADSTP);
			while( 1 ){
				if(	((adc->CR & ADC_CR_ADSTART) == 0 ) &&
					((adc->CR & ADC_CR_JADSTART) == 0) ){
					break;
				}
			}
			adc->CR |= ADC_CR_ADDIS;
		}
	}
	if((adc->CR & ADC_CR_ADVREGEN) == ADC_CR_ADVREGEN){
		adc->CR &=~ ADC_CR_ADVREGEN;
	}
	adc_enabled = 0;
}

/**
 * 	\brief	Measures voltage on a desired channel
 * 	\param	*adc		desired ADC to be used
 * 	\param	*channel	desired channel settings
 * 	\param	*pres		pointer where result can be stored
 * 	\param	timeout		timeout in ms
 */
static uint8_t adc_measure_channel( 	ADC_TypeDef *adc,
										adc_channel_conf_s *channel,
										uint16_t *pres )
{
	uint32_t start;
	uint8_t sample_cnt = 0;
	uint8_t do_nsamples = 0;
	uint32_t tresult = 0;
	uint32_t exp_timeout = 0;
	double sum = 0;

	if( (adc_initialized == 0) || adc_enabled == 0 ){
		return 1;
	}

	if( channel->n_averaging < 1 ){
		do_nsamples = 1;
	} else if (channel->n_averaging >= 255 ){
		do_nsamples = 254;
	} else {
		do_nsamples = channel->n_averaging;
	}

	start = HAL_GetTick( );

	//if( sample_cnt > 1) {
		adc->CFGR |= ADC_CFGR_CONT;
	//} else {
		//ADC->CFGR &=~ ADC_CFGR_CONT;
	//}
	adc_config_channel( adc, channel );

	exp_timeout = curr_sampling_time * (channel->n_averaging + 1);
	exp_timeout <<= 1;
	if( exp_timeout > 1000000){
		exp_timeout /= 1000000;				// from ns to ms
	} else {
		exp_timeout = 1;
	}
	adc->ISR |= (ADC_ISR_EOC | ADC_ISR_EOS);
	adc->CR |= ADC_CR_ADSTART;
	//deb_gpio_set( );
	while( sample_cnt <= do_nsamples ){
		if((adc->ISR & ADC_ISR_EOS) == ADC_ISR_EOS){
			adc->ISR |= ADC_ISR_EOS;
			if( sample_cnt != 0){	//ignore first value
				sum += (double)adc->DR;
			}
			sample_cnt++;
		}
		if( (HAL_GetTick() - start) > exp_timeout ){
			break;
		}
	}
//	deb_gpio_reset( );
	adc->CR |= ADC_CR_ADSTP;
	if( sample_cnt == (do_nsamples + 1)){	// all measurements done
		sum /= (double)do_nsamples;
		sum = round(sum);
		tresult = (uint16_t)sum;
		*pres = tresult;
		return 0;
	}
	return 1;
}

/*
 * 	\brief	Configures adc channel according to desired settings
 * 	\param	*adc		desired ADC module instance
 * 	\param	*channel	desired channel settings
 */
static void adc_config_channel( 	ADC_TypeDef *adc,
									adc_channel_conf_s *channel )
{
	uint32_t tmp = 0;
	tmp = channel->resolution;
	adc->CFGR &= ~ ADC_CFGR_RES_Msk;
	adc->CFGR |= ((tmp << ADC_CFGR_RES_Pos) & ADC_CFGR_RES_Msk );// Set resolution to 8-bit

	// --- set sampling time

//	tmp = get_smp_param( channel->tsampling );
//	adc->SMPR1 &=~ ADC_SMPR1_SMP3_Msk;
//	adc->SMPR1 |= ((tmp << ADC_SMPR1_SMP3_Pos) & ADC_SMPR1_SMP3_Msk );
	set_sampling_time( adc, channel->tsampling );

	// --- set channel as first entry of regular sequence
	adc->SQR1 &=~ ADC_SQR1_SQ1_Msk;
	adc->SQR1 |= ((channel->channel_nr << ADC_SQR1_SQ1_Pos) & ADC_SQR1_SQ1_Msk);
	adc->SQR1 &=~ ADC_SQR1_L_Msk;	// sequence lenght = 1
}

/**
 * 	\brief	Measured the vdda voltage level
 * 	\param	*prev		pointer to buffer where result can be stored
 * 	\param	n_average	number of desired values for averaging
 * 	\return	returns 0 on success, nonzero on error
 */
static uint8_t adc_get_vdda( uint16_t *pvref, uint8_t n_average )
{
	adc_channel_conf_s chan;
	ADC_TypeDef *adc_vref = ADC1;
	uint16_t vrefint = 0;
	double vdda = 0;
	uint32_t wait_loop_index;
	uint16_t *calval = VREFINT_CAL_ADDR;

	ADC123_COMMON->CCR |= ADC_CCR_VREFEN;

	wait_loop_index = (VREFINT_STUP_DELAY_US * (SystemCoreClock / (1000000 * 2)));
	while(wait_loop_index != 0)		// Wait for VREG startup time
	{
	  wait_loop_index--;
	}

	chan.channel_nr = 0;
	chan.resolution = ADC_RES_12;
	chan.tsampling = 10000;
	chan.n_averaging = n_average;

	if( adc_measure_channel( adc_vref, &chan, &vrefint ) != 0 ){
		return 1;
	}
	ADC123_COMMON->CCR &=~ ADC_CCR_VREFEN;
	vdda = 3000 * (double)*calval / (double)vrefint;
	*pvref = (uint16_t)vdda;
	return 0;
}

/*
 * 	\brief	Calculates possible sampling times according to
 * 			ADC frequency and possible settings (see reference manual p.518)
 * 			Values are stored in a lookup table
 */
static void calc_sampling_times( void )
{
	double adc_cycle = (double)1/((double)(ADC_CLK_FREQ_HZ / 1000000));	// in microseconds
	adc_cycle *= 1000;									// in nanoseconds
	adc_ts_lut[0] = (uint32_t)(  2.5 * adc_cycle);
	adc_ts_lut[1] = (uint32_t)(  6.5 * adc_cycle);
	adc_ts_lut[2] = (uint32_t)( 12.5 * adc_cycle);
	adc_ts_lut[3] = (uint32_t)( 24.5 * adc_cycle);
	adc_ts_lut[4] = (uint32_t)( 47.5 * adc_cycle);
	adc_ts_lut[5] = (uint32_t)( 92.5 * adc_cycle);
	adc_ts_lut[6] = (uint32_t)(247.5 * adc_cycle);
	adc_ts_lut[7] = (uint32_t)(640.5 * adc_cycle);
}

/*
 * 	\brief	Evaluates best settings for the SMPRx registers
 * 			to fullfill sampling time restriction
 * 	\param	sampling_time desired sampling time in NANOseconds
 * 	\return	returns best parameter which can be set in
 * 			SMP[2:0] bits of SMPRx registers (see reference manual p.518)
 */
static uint32_t get_smp_param( uint32_t sampling_time )
{
	uint8_t i = 0;
	for( i=0; i<8; i++ ){
		if( adc_ts_lut[i] >= sampling_time ){
			return i;
		}
	}
	return 7;	// maximum
}

static void set_sampling_time( ADC_TypeDef *adc_inst, uint32_t sampling_time )
{
	uint32_t tmp = 0;
	tmp = get_smp_param( sampling_time );
	adc_inst->SMPR1 &=~ ADC_SMPR1_SMP3_Msk;
	adc_inst->SMPR1 |= ((tmp << ADC_SMPR1_SMP3_Pos) & ADC_SMPR1_SMP3_Msk );
	curr_sampling_time = get_configured_sampling_time( tmp );
}

/*
 * 	\brief	Returns configured sampling time in nanoseconds
 * 	\param	smp_setting		Setting used in SMP register
 * 	\return	returns configured sampling time
 */
static uint32_t get_configured_sampling_time( uint32_t smp_setting )
{
	return adc_ts_lut[smp_setting];
}
