/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		adc.h
 *
 * \description	Implementation of the ADC module
 *
 * \author		F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		04.01.2018
 *
 *****************************************************************************/
 
 /* re-definition guard */
#ifndef _ADC_H
#define _ADC_H

/* -- includes --------------------------------------------------------------*/
#include "stm32l4xx.h"
#include "stdint.h"

/* -- makros ----------------------------------------------------------------*/


/* -- type definitions-------------------------------------------------------*/
typedef enum {
					ADC_RES_12 = 0x00U,
					ADC_RES_10 = 0x01U,
					ADC_RES_8 =  0x02U,
					ADC_RES_6 =  0x03U
}t_adc_res;


typedef struct {	uint8_t channel_nr;
					t_adc_res resolution;
					uint32_t tsampling;		// sampling time in nanoseconds
					uint8_t	 n_averaging;
}adc_channel_conf_s;

/* public function declarations -------------------------------------------- */

/**
 * 	\brief	Measures voltage with desired ADC module and channel configuration
 * 			with respecting the analog reference voltage.
 * 			The resulting voltage is stored in millivolts.
 * 			ATTENTION: Desired GPIO must be initalizes by user
 * 	\param	adc_instance	Desired instance of ADC module to be used
 * 							ATTENTION: Only ADC1 or ADC2 can be used
 * 	\param	*channel		Deisred channel configuration
 * 	\param	*res_buffer		Buffer to store result
 * 	\return	returns 0 on success, nonzero on error
 */
uint8_t ADC_meas_absolut(	ADC_TypeDef *adc_instance,
							adc_channel_conf_s *channel,
							uint16_t *res_buffer);

#endif	// _ADC_H

