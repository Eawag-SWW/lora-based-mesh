/******************************************************************************
 *  _____       ______   ____
 * |_   _|     |  ____|/ ____|  Institute of Embedded Systems
 *   | |  _ __ | |__  | (___    Wireless Group
 *   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur
 *  _| |_| | | | |____ ____) |  (University of Applied Sciences)
 * |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 *
 *   _____    _____    ___    __    ___  _____      _____
 *  /  _  \  |__    \  \  \  /  \  /  / |__    \   /  _  \
 * |  /_\  |  __| _  |  \  \/ __ \/  /   __| _  | |  |_|  |
 * |  |____  |   |_| |   \   /  \   /   |   |_| |  \____  |
 *  \______| |_______|    \_/    \_/    |_______|   _   | |
 * Eawag                                           | \__/ |
 * Department Urban Water Management                \____/
 * �berlandstrasse 133
 * CH-8600 D�bendorf
 ******************************************************************************
 * Copyright (c) 2019, Institute of Embedded Systems, Eawag
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 * \file		mcu_hal.c
 *
 * \description	Initialization of MCU specific peripherals and modules
 *
 * \author(s)	F. Schaltegger, C. Ebi, P. Bachmann, F. Frei
 *
 * \date		2017
 *
 *****************************************************************************/
/* -- includes --------------------------------------------------------------*/
#include "mcu_hal.h"
//#include "stm32l4xx_hal.h"
#include "utilities.h"
#include "spi-board.h"
#include "mcu_pinout.h"
#include "gpio.h"
#include "dma.h"

/* -- makros ----------------------------------------------------------------*/
#define         ID1                                 ( UID_BASE )
#define         ID2                                 ( UID_BASE + 0x04 )
#define         ID3                                 ( UID_BASE + 0x08)

/* -- type definitions-------------------------------------------------------*/


/* internal function declarations ------------------------------------------ */
static void MCU_Systemclock_Config( void );
static void MCU_Systemclock_Reconfig( void );
static void MCU_Unused_IO_Init( void );
 
/* internal variable definitions ------------------------------------------- */ 
static uint8_t McuInitialized = FALSE;

/* public function definitions --------------------------------------------- */

/*
 *	see header file
 */
void MCU_Init( void )
{
	if( McuInitialized == FALSE )
	{
	#if defined( USE_BOOTLOADER )
		// Set the Vector Table base location at 0x3000
		SCB->VTOR = FLASH_BASE | 0x3000;
	#endif
		HAL_Init( );

		MCU_Systemclock_Config();
		__HAL_RCC_WAKEUPSTOP_CLK_CONFIG(RCC_STOP_WAKEUPCLOCK_HSI);

	#if defined( USE_USB_CDC )
		UartInit( &UartUsb, UART_USB_CDC, NC, NC );
		UartConfig( &UartUsb, RX_TX, 115200, UART_8_BIT, UART_1_STOP_BIT, NO_PARITY, NO_FLOW_CTRL );

		DelayMs( 1000 ); // 1000 ms for Usb initialization
	#endif

		DMA_init();

		MCU_Unused_IO_Init( );
		McuInitialized = TRUE;
	}
	else
	{
		MCU_Systemclock_Reconfig();
	}
}


/*
 *	see header file
 */
void MCU_Deinit( void )
{
	// ToDO: Deinit function
}

/*
 *	see header file
 */
void MCU_Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
	  //__asm("BKPT 255");		//ToDO: Replace SW-breakpoint with reset command
  }
  /* USER CODE END Error_Handler */
}

/*
 *	see header file
 */
uint8_t mcu_enable_port_clock( GPIO_TypeDef *port )
{
	uint8_t ret = 0;
	if( port == GPIOA ) {
		if( __HAL_RCC_GPIOA_IS_CLK_DISABLED()) {
			__HAL_RCC_GPIOA_CLK_ENABLE();
		}
	} else if ( port == GPIOB ) {
		if( __HAL_RCC_GPIOB_IS_CLK_DISABLED()) {
			__HAL_RCC_GPIOB_CLK_ENABLE();
		}

	} else if ( port == GPIOC ) {
		if( __HAL_RCC_GPIOC_IS_CLK_DISABLED()) {
			__HAL_RCC_GPIOC_CLK_ENABLE();
		}

	} else if ( port == GPIOD ) {
		if( __HAL_RCC_GPIOD_IS_CLK_DISABLED()) {
			__HAL_RCC_GPIOD_CLK_ENABLE();
		}

	} else if ( port == GPIOE ) {
		if( __HAL_RCC_GPIOE_IS_CLK_DISABLED()) {
			__HAL_RCC_GPIOE_CLK_ENABLE();
		}

	} else if ( port == GPIOF ) {
		if( __HAL_RCC_GPIOF_IS_CLK_DISABLED()) {
			__HAL_RCC_GPIOF_CLK_ENABLE();
		}

	} else if ( port == GPIOG ) {
		if( __HAL_RCC_GPIOG_IS_CLK_DISABLED()) {
			__HAL_RCC_GPIOG_CLK_ENABLE();
		}

	} else if ( port == GPIOH ) {
		if( __HAL_RCC_GPIOH_IS_CLK_DISABLED()) {
			__HAL_RCC_GPIOH_CLK_ENABLE();
		}

	} else {
		ret = 1;
	}
	return ret;
}


/* internal functions definitions ------------------------------------------ */

/**
 *  \brief  Confiuration of the system clocks
 *  		The clock sources can be defined by changing project symbols
 *  		in project settings
 *  		USE_HSE / USE_HSI / USE_LSE / USE_LSI
 */
static void MCU_Systemclock_Config( void )
{
	RCC_OscInitTypeDef RCC_OscInitStruct;
	RCC_ClkInitTypeDef RCC_ClkInitStruct;
	RCC_PeriphCLKInitTypeDef PeriphClkInit;

	/**Initializes the CPU, AHB and APB busses clocks
	*/

#ifdef USE_HSE		// HSE
	// init HSE oscillator
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLM = 1;
	RCC_OscInitStruct.PLL.PLLN = 20;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
	RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
	RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;

	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		MCU_Error_Handler();
	}

#else
#ifdef USE_HSI
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = 16;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = 1;
	RCC_OscInitStruct.PLL.PLLN = 10;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
	RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
	RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		MCU_Error_Handler();
	}
#else
#error define clock source
#endif
#endif
	// init LSE oscillator
#ifdef USE_LSE
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE;
	RCC_OscInitStruct.LSEState = RCC_LSE_BYPASS;

	if(HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		MCU_Error_Handler();
	}
#else
#ifdef USE_LSI
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI;
	RCC_OscInitStruct.LSEState = RCC_LSI_ON;

	if(HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		MCU_Error_Handler();
	}
#else
#error Choose low speed clock source
#endif
#endif
	/**Initializes the CPU, AHB and APB busses clocks
	*/
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
							  |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
	{
		MCU_Error_Handler();
	}

	// ATTENTION: LSE oscillator must be configured by user before calling this
	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
#ifdef USE_LSE
	PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
#else
#ifdef USE_LSI
	PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
#endif
#endif
	HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit);

	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2;
	PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
	{
		MCU_Error_Handler();
	}

	  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RNG;
	  PeriphClkInit.RngClockSelection = RCC_RNGCLKSOURCE_PLLSAI1;
	  PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_HSE;
	  PeriphClkInit.PLLSAI1.PLLSAI1M = 1;
	  PeriphClkInit.PLLSAI1.PLLSAI1N = 12;
	  PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV7;
	  PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
	  PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
	  PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_48M2CLK;
	  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
	  {
	    MCU_Error_Handler();
	  }

	/**Configure the main internal regulator output voltage
	*/
	if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
	{
		MCU_Error_Handler();
	}

	/**Configure the Systick interrupt time
	*/
	HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

	/**Configure the Systick
	*/
	HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

	/* SysTick_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(SysTick_IRQn, 15, 0);
}

/**
 *  \brief  Reconfigures the system clock after MCU wakes up from stop mode
 */
static void MCU_Systemclock_Reconfig( void )
{
    __HAL_RCC_PWR_CLK_ENABLE( );
    //__HAL_PWR_VOLTAGESCALING_CONFIG( PWR_REGULATOR_VOLTAGE_SCALE1 );
    HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);
#ifdef USE_HSE
    /* Enable HSE */
    __HAL_RCC_HSE_CONFIG( RCC_HSE_ON );
    /* Wait till HSE is ready */
    while( __HAL_RCC_GET_FLAG( RCC_FLAG_HSERDY ) == RESET )
    {
    }
#else
#ifdef USE_HSI
    __HAL_RCC_HSI_ENABLE();
    while( __HAL_RCC_GET_FLAG(RCC_FLAG_HSIRDY) == RESET) {
    	//nop
    }

#else
#error select clock source
#endif
#endif


    /* Enable PLL */
    __HAL_RCC_PLL_ENABLE( );

    /* Wait till PLL is ready */
    while( __HAL_RCC_GET_FLAG( RCC_FLAG_PLLRDY ) == RESET )
    {
    }

    /* Select PLL as system clock source */
    __HAL_RCC_SYSCLK_CONFIG ( RCC_SYSCLKSOURCE_PLLCLK );

    /* Wait till PLL is used as system clock source */
    while( __HAL_RCC_GET_SYSCLK_SOURCE( ) != RCC_SYSCLKSOURCE_STATUS_PLLCLK )
    {
    }

    if( (RCC->CR & RCC_CR_PLLSAI1ON) != RCC_CR_PLLSAI1ON){
    	RCC->CR |= RCC_CR_PLLSAI1ON;
    }
    while( (RCC->CR & RCC_CR_PLLSAI1RDY) != RCC_CR_PLLSAI1RDY)
    {
    }
}


/**
 *  \brief  Initializes unused IOs
 */
static void MCU_Unused_IO_Init( void )
{
#if defined( USE_DEBUGGER )
	HAL_DBGMCU_EnableDBGStopMode( );
	HAL_DBGMCU_EnableDBGSleepMode( );
	HAL_DBGMCU_EnableDBGStandbyMode( );
#else
	HAL_DBGMCU_DisableDBGSleepMode( );
	HAL_DBGMCU_DisableDBGStopMode( );
	HAL_DBGMCU_DisableDBGStandbyMode( );

//    GpioInit( &ioPin, SWDIO, PIN_ANALOGIC, PIN_PUSH_PULL, PIN_NO_PULL, 0 );
//    GpioInit( &ioPin, SWCLK, PIN_ANALOGIC, PIN_PUSH_PULL, PIN_NO_PULL, 0 );
#endif
}

