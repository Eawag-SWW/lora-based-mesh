# LoRaMesh Software
### Version 2.0.5


## Used Tools
-------------
- IDE: [Atollic True Studio for STM32](https://www.st.com/en/development-tools/truestudio.html)
- FreeRTOS V9.0.0
- stm32l4xx HAL drivers (V1.7.0) by STMicroelectronics
- CMSIS Cortex-M4 V4.30 by ARM
- iM880B Communication driver V0.2 by IMST
## Usage
1) Download, install and run Atollic True Studio for STM32.  
   Download path: https://atollic.com/truestudio/
2) Open this project using True Studio:  
   - File -> Open Projects from File System ... -> Click *Directory...*  
   - Navigate to the directory where you have extracted the archive  
     (e.g. C:/Software/LoRaMesh_Node)
   - Choose the folder *LoRaMesh_Node* and click *OK*
   - Click *Finish*
   - True Stuido will now import the project and you should see it in the *Project Explorer*
3) Set the configuration according to the descriptions in the following chapters
4) Check your Debug configuration (*Configure Debug*):
   - Make sure you have selected the correct debugger (STLink or JLINK), depending on your hardware setup.
5) Build and run the software on your connected hardware

## Device Configuration
-----------------------
The device configuration can be done in the file __/Inc/device_config.h__.
Detailed descriptions are given in the comments. Bascially, the following parameters have to be set correctly.

### Basic configuration

- Device behaviour as Repeater or Node
- Low power functionality enabled or disabled
- Timesource (for repeater devices):  
  None, GPS or DCF77
- Log-level on SD Card
  (None / Sensor / Debug / Sensor&Debug)
- Type of attached sensor (Node devices)  
  - [MB7389 - Ultrasonic](https://www.maxbotix.com/Ultrasonic_Sensors/MB7389.htm)
  - [MB7369 - Ultrasonic](https://www.maxbotix.com/Ultrasonic_Sensors/MB7369.htm)
  - [DEC5TE - Soil Moisture](https://envcoglobal.com/catalog/agriculture/irrigation/soil-moisture-monitoring/dedicated-soil-moisture-measurement/5-te)
  - [DS18B20 - Temperature](https://www.digitec.ch/de/s1/product/oem-ds18b20-sensor-elektronikmodul-8030174?dclid=CI2x0pnb0NsCFZpA4Aodd6QCpA&gclsrc=aw.ds&gclid=EAIaIQobChMI1NGbk9vQ2wIVSdwZCh2GWAGkEAQYASABEgJ0-fD_BwE)
- 



### LoRaWAN Parameters
The following paramaters have to be set accordingly to your LoRaWAN network configuration:
- Network Session Key (NWK_SESSION_KEY)  
- Application Session Key (APP_SESSION_KEY)  
- LoRaWAN device address (DEVICE_ADDR_LORAWAN)
- LoRaWAN Port (LORAWAN_MAC_DATA_PORT)
### LoRaMesh Parameters
The LoRaMesh device address has to be configured here:
- LoRaMesh Device address (DEVICE_ADDR_LORAMESH)

Additional LoRaMesh configuration can be found in:  
__/Src/LoRaMesh/loramesh_com.h__  
There, parameters for the LoRaMesh communication (e.g. used spreading factor, bandwidth, output power and channel can be found). Also LoRa packet settings are located in this file.

## Protocol Configuration
-------------------------
Currently, the protocol configuration also includes medium access and timing definitions. The confgiuration is done in the file __/Src/protocol_config.c__. There you'll find the function which initalizes the configuration struct (see __protocol_config.h__). To apply changes, vary the paramters directly in this function.
```C
File: /Src/protocol_conifig.c:218
static uint8_t ptkSetConfigTestSetup( void )
{
	ptkConfig.slot_duration_ms = 2000;
	ptkConfig.subslot_duration_ms = 400;

	ptkConfig.max_ul_timeout = 2;
	ptkConfig.max_join_timeout = 5;

	ptkConfig.N_sync_slots = 1;
	ptkConfig.N_jreq_slots = 1;
	ptkConfig.N_approve_slots = 1;
	ptkConfig.N_uplink_slots = 5;
	ptkConfig.N_downlink_slots = 5;
	ptkConfig.N_wan_slots = 2;
	ptkConfig.N_guard_slots = 135; //test :3

	ptkConfig.max_netw_nodes = 5;

    ...
}
 ```
For protocol description, please refer to the documentation (TBD)

## Notes
--------
- Timeouts:  
  Make sure that timeout (ex. receive timeouts) do not exceed the slot time.
  The system will crash if timeout is set bigger than the slot time.

## Known Problems
-----------------
### IMST Module problems
LoRaWAN allowes a maximum payload of 51 byte (when DR0, DR1 or DR2 are used).
When five sensor nodes are connected to one repeater node, the maximum payload
of 51 byte is reached. When the IMST module doesn't have to send additional MAC 
commands (which are piggibacked to the payload), transmission of this maximum 
payload is successful.

In case the IMST module has to send additional MAC commands, it doesn't accept 
the uplink transmission command with a payload of maximum size. And the data is
**not** sent to the gateway. The application software has to detect, when the 
transmission command is rejected and then send a shorter payload to the
gateway. By sending out the shortened payload, the IMST module is able to 
transmit the pending MAC command. From now on, it will again accept payloads 
with maximum number of bytes

![imst_workaround](/release_notes_pictures/imst_workaround.png)



